import type { PDFDocumentProxy, RenderTask } from "pdfjs-dist";
import type { Ann, EditorInit, PageState, Source } from "./types";
import { pageDims, uid } from "./types";

let pdfjsPromise: Promise<typeof import("pdfjs-dist")> | null = null;

export function getPdfjs() {
  if (!pdfjsPromise) {
    pdfjsPromise = import("pdfjs-dist/legacy/build/pdf.mjs" as string).then((m) => {
      const lib = m as typeof import("pdfjs-dist");
      lib.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
      return lib;
    });
  }
  return pdfjsPromise;
}

export async function loadSource(bytes: Uint8Array, name: string): Promise<Source> {
  const pdfjs = await getPdfjs();
  const doc: PDFDocumentProxy = await pdfjs.getDocument({ data: bytes.slice() }).promise;
  const dims: [number, number][] = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const p = await doc.getPage(i);
    const v = p.getViewport({ scale: 1 });
    dims.push([v.width, v.height]);
  }
  return { name, bytes, doc, dims };
}

export function editorInitFromSources(sources: Source[], name: string): EditorInit {
  const pages: PageState[] = [];
  sources.forEach((s, di) =>
    s.dims.forEach(([w, h], index) =>
      pages.push({ id: uid(), src: { doc: di, index }, rot: 0, bw: w, bh: h }),
    ),
  );
  return { name, sources, pages, anns: [] };
}

/** Renders a page into a canvas. Returns the task so the caller can cancel it. */
export async function renderPage(
  source: Source,
  index: number,
  rot: number,
  cssWidth: number,
  canvas: HTMLCanvasElement,
  onTask?: (t: RenderTask) => void,
): Promise<void> {
  const page = await source.doc.getPage(index + 1);
  const base = page.getViewport({ scale: 1, rotation: rot });
  const dpr = Math.min(typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1, 2);
  let scale = (cssWidth / base.width) * dpr;
  const maxPixels = 5_000_000;
  const px = base.width * scale * base.height * scale;
  if (px > maxPixels) scale *= Math.sqrt(maxPixels / px);
  const viewport = page.getViewport({ scale, rotation: rot });
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const task = page.render({ canvasContext: ctx, viewport, canvas } as never);
  onTask?.(task);
  await task.promise;
}

/* ------------------------------ export ------------------------------ */

const hexToRgb = (hex: string) => {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => v / 255) as [number, number, number];
};

export async function exportPdf(
  sources: Source[],
  pages: PageState[],
  anns: Ann[],
): Promise<Uint8Array> {
  const { PDFDocument, StandardFonts, rgb, degrees } = await import("pdf-lib");

  const out = await PDFDocument.create();
  const loaded = new Map<number, Awaited<ReturnType<typeof PDFDocument.load>>>();
  const getDoc = async (i: number) => {
    let d = loaded.get(i);
    if (!d) {
      d = await PDFDocument.load(sources[i].bytes, { ignoreEncryption: true });
      loaded.set(i, d);
    }
    return d;
  };

  const fonts = {
    "sans-false": await out.embedFont(StandardFonts.Helvetica),
    "sans-true": await out.embedFont(StandardFonts.HelveticaBold),
    "serif-false": await out.embedFont(StandardFonts.TimesRoman),
    "serif-true": await out.embedFont(StandardFonts.TimesRomanBold),
    "mono-false": await out.embedFont(StandardFonts.Courier),
    "mono-true": await out.embedFont(StandardFonts.CourierBold),
  } as const;
  const charSets = new Map<string, Set<number>>();
  const cs = (k: string, f: (typeof fonts)[keyof typeof fonts]) => {
    let s = charSets.get(k);
    if (!s) {
      s = new Set(f.getCharacterSet());
      charSets.set(k, s);
    }
    return s;
  };
  const clean = (text: string, k: string, f: (typeof fonts)[keyof typeof fonts]) => {
    const set = cs(k, f);
    return Array.from(text)
      .map((ch) => (set.has(ch.codePointAt(0)!) ? ch : ch === "\t" ? "    " : "?"))
      .join("");
  };

  for (const p of pages) {
    let page;
    let x0 = 0,
      y0 = 0,
      W: number,
      H: number,
      total: number;
    if (p.src) {
      const src = await getDoc(p.src.doc);
      const [copied] = await out.copyPages(src, [p.src.index]);
      page = out.addPage(copied);
      const box = page.getCropBox();
      x0 = box.x;
      y0 = box.y;
      W = box.width;
      H = box.height;
      const intrinsic = page.getRotation().angle;
      total = (((intrinsic + p.rot) % 360) + 360) % 360;
      page.setRotation(degrees(total));
    } else {
      page = out.addPage([p.bw, p.bh]);
      W = p.bw;
      H = p.bh;
      total = p.rot % 360;
      page.setRotation(degrees(total));
    }

    // displayed (top-left origin) -> unrotated user space
    const map = (dx: number, dy: number): { x: number; y: number } => {
      switch (total) {
        case 90:
          return { x: x0 + dy, y: y0 + dx };
        case 180:
          return { x: x0 + W - dx, y: y0 + dy };
        case 270:
          return { x: x0 + W - dy, y: y0 + H - dx };
        default:
          return { x: x0 + dx, y: y0 + H - dy };
      }
    };
    const rot = degrees(total);

    for (const a of anns.filter((x) => x.pageId === p.id)) {
      if (a.type === "rect") {
        const o = map(a.x, a.y + a.h);
        page.drawRectangle({
          x: o.x,
          y: o.y,
          width: a.w,
          height: a.h,
          rotate: rot,
          color: a.fill ? rgb(...hexToRgb(a.fill)) : undefined,
          opacity: a.fill ? a.opacity : undefined,
          borderColor: a.stroke ? rgb(...hexToRgb(a.stroke)) : undefined,
          borderWidth: a.stroke ? a.strokeWidth : 0,
        });
      } else if (a.type === "text") {
        const key = `${a.font}-${a.bold}` as keyof typeof fonts;
        const font = fonts[key];
        const lines = a.text.split("\n");
        lines.forEach((line, i) => {
          if (!line) return;
          const o = map(a.x, a.y + a.size * 0.95 + i * a.size * 1.2);
          page.drawText(clean(line, key, font), {
            x: o.x,
            y: o.y,
            size: a.size,
            font,
            color: rgb(...hexToRgb(a.color)),
            rotate: rot,
          });
        });
      } else if (a.type === "image") {
        const img = a.dataUrl.startsWith("data:image/png")
          ? await out.embedPng(a.dataUrl)
          : await out.embedJpg(a.dataUrl);
        const o = map(a.x, a.y + a.h);
        page.drawImage(img, { x: o.x, y: o.y, width: a.w, height: a.h, rotate: rot });
      } else if (a.type === "ink") {
        const c = rgb(...hexToRgb(a.color));
        const pts = a.points;
        if (pts.length === 1) pts.push([pts[0][0] + 0.1, pts[0][1]]);
        for (let i = 1; i < pts.length; i++) {
          const s = map(pts[i - 1][0], pts[i - 1][1]);
          const e = map(pts[i][0], pts[i][1]);
          page.drawLine({
            start: s,
            end: e,
            thickness: a.width,
            color: c,
            lineCap: 1,
          });
        }
      }
    }
  }

  out.setProducer("PDF Studio");
  out.setModificationDate(new Date());
  return out.save();
}

/* ------------------------------ summary ------------------------------ */

export function summarizeEdits(
  init: EditorInit,
  pages: PageState[],
  anns: Ann[],
): string[] {
  const out: string[] = [];
  if (init.templateName) out.push(`Created from the “${init.templateName}” template`);

  const origIds = new Set(init.pages.map((p) => p.id));
  const pageNo = (id: string) => pages.findIndex((p) => p.id === id) + 1;

  const groups = new Map<string, Set<number>>();
  const counts = new Map<string, number>();
  let filled = 0;
  const filledPages = new Set<number>();
  for (const a of anns) {
    const pn = pageNo(a.pageId);
    if (pn === 0) continue;
    if (a.tplText !== undefined) {
      if (a.type === "text" && a.text !== a.tplText) {
        filled++;
        filledPages.add(pn);
      }
      continue;
    }
    counts.set(a.label, (counts.get(a.label) ?? 0) + 1);
    if (!groups.has(a.label)) groups.set(a.label, new Set());
    groups.get(a.label)!.add(pn);
  }
  const pg = (s: Set<number>) =>
    ` (page${s.size > 1 ? "s" : ""} ${[...s].sort((a, b) => a - b).join(", ")})`;

  if (filled) out.push(`Filled in ${filled} template field${filled === 1 ? "" : "s"}${pg(filledPages)}`);
  const verbs: Record<string, string> = {
    Text: "text box",
    Drawing: "drawing",
    Highlight: "highlight",
    "White-out": "white-out area",
    Shape: "shape",
    Image: "image",
    Signature: "signature",
    Stamp: "stamp",
  };
  for (const [label, n] of counts) {
    out.push(`Added ${n} ${verbs[label]}${n === 1 ? "" : "s"}${pg(groups.get(label)!)}`);
  }

  const rotated = pages.filter((p) => origIds.has(p.id) && p.rot !== 0).length;
  if (rotated) out.push(`Rotated ${rotated} page${rotated === 1 ? "" : "s"}`);
  const deleted = init.pages.filter((p) => !pages.some((q) => q.id === p.id)).length;
  if (deleted) out.push(`Deleted ${deleted} page${deleted === 1 ? "" : "s"}`);
  const blanks = pages.filter((p) => !p.src && !origIds.has(p.id)).length;
  if (blanks) out.push(`Added ${blanks} blank page${blanks === 1 ? "" : "s"}`);
  const sourceCount = new Set(pages.filter((p) => p.src).map((p) => p.src!.doc)).size;
  if (sourceCount > init.sources.length || init.sources.length > 1)
    out.push(`Merged ${Math.max(sourceCount, init.sources.length)} PDF files`);
  const initOrder = init.pages.filter((p) => pages.some((q) => q.id === p.id)).map((p) => p.id);
  const nowOrder = pages.filter((p) => origIds.has(p.id)).map((p) => p.id);
  if (initOrder.join() !== nowOrder.join()) out.push("Reordered pages");

  if (!out.length) out.push("Saved a copy without changes");
  return out;
}
