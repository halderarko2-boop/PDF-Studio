import { PDFDocument, PDFFont, StandardFonts } from "pdf-lib";
import type { FontKey } from "./types";

const NAMES: Record<FontKey, StandardFonts[]> = {
  helv: [StandardFonts.Helvetica, StandardFonts.HelveticaBold, StandardFonts.HelveticaOblique, StandardFonts.HelveticaBoldOblique],
  times: [StandardFonts.TimesRoman, StandardFonts.TimesRomanBold, StandardFonts.TimesRomanItalic, StandardFonts.TimesRomanBoldItalic],
  cour: [StandardFonts.Courier, StandardFonts.CourierBold, StandardFonts.CourierOblique, StandardFonts.CourierBoldOblique],
};
export const stdName = (f: FontKey, bold?: boolean, italic?: boolean) => NAMES[f][(bold ? 1 : 0) + (italic ? 2 : 0)];

const metrics = new Map<string, PDFFont>();
let readyP: Promise<void> | undefined;
export function initFonts() {
  readyP ??= (async () => {
    const d = await PDFDocument.create();
    for (const list of Object.values(NAMES)) for (const n of list) metrics.set(n, await d.embedFont(n));
  })();
  return readyP;
}

const okCache = new Map<string, boolean>();
function canEncode(ch: string) {
  const c = okCache.get(ch);
  if (c !== undefined) return c;
  const font = metrics.get(StandardFonts.Helvetica);
  let r: boolean;
  if (!font) return ch.charCodeAt(0) < 256 || "•–—‘’“”…€™".includes(ch); // fonts not ready: don't cache
  else {
    try {
      font.widthOfTextAtSize(ch, 10);
      r = true;
    } catch {
      r = false;
    }
  }
  okCache.set(ch, r);
  return r;
}

/** Standard PDF fonts only know Latin characters – swap unknown ones for "?" */
export function sanitize(s: string) {
  return Array.from(s.replace(/\r/g, "").replace(/\t/g, "    "))
    .map((ch) => (ch === "\n" || canEncode(ch) ? ch : "?"))
    .join("");
}

export function widthOf(text: string, size: number, f: FontKey, bold?: boolean, italic?: boolean) {
  const font = metrics.get(stdName(f, bold, italic));
  if (!font) return text.length * size * (f === "cour" ? 0.6 : 0.5);
  try {
    return font.widthOfTextAtSize(text, size);
  } catch {
    return text.length * size * 0.5;
  }
}

export function wrapText(raw: string, size: number, f: FontKey, bold: boolean | undefined, italic: boolean | undefined, maxW: number) {
  const out: string[] = [];
  const w = (t: string) => widthOf(t, size, f, bold, italic);
  for (const para of sanitize(raw).split("\n")) {
    if (para === "") {
      out.push("");
      continue;
    }
    let line = "";
    for (const word of para.split(" ")) {
      const test = line ? line + " " + word : word;
      if (w(test) <= maxW || !line) {
        if (!line && w(word) > maxW) {
          // break very long words
          let chunk = "";
          for (const ch of word) {
            if (w(chunk + ch) > maxW && chunk) {
              out.push(chunk);
              chunk = ch;
            } else chunk += ch;
          }
          line = chunk;
        } else line = test;
      } else {
        out.push(line);
        line = word;
      }
    }
    out.push(line);
  }
  return out;
}

export const LINE_H = 1.2;
export function fitTextHeight(el: { text: string; size: number; font: FontKey; bold?: boolean; italic?: boolean; w: number }) {
  return Math.max(el.size * LINE_H, wrapText(el.text, el.size, el.font, el.bold, el.italic, el.w).length * el.size * LINE_H);
}
