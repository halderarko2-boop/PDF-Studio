"use client";

import { useEffect, useMemo, useState } from "react";
import type { HistoryEntry } from "@/lib/types";
import { clearHistory, getHistoryFile, listHistory, removeHistory } from "@/lib/history";
import { savePdf } from "@/lib/files";
import { Btn, Icon, Sheet } from "./ui";

const actionMeta: Record<HistoryEntry["action"], { label: string; icon: string; tone: string }> = {
  edited: { label: "Edited", icon: "edit", tone: "bg-indigo-100 text-indigo-600" },
  created: { label: "From template", icon: "file", tone: "bg-amber-100 text-amber-600" },
  scanned: { label: "Scanned", icon: "camera", tone: "bg-emerald-100 text-emerald-600" },
  merged: { label: "Merged", icon: "merge", tone: "bg-sky-100 text-sky-600" },
};

export const fmtTime = (ts: number) =>
  new Date(ts).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });

export function dayLabel(ts: number): string {
  const d = new Date(ts);
  const today = new Date();
  const y = new Date();
  y.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === y.toDateString()) return "Yesterday";
  return d.toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "long", year: d.getFullYear() === today.getFullYear() ? undefined : "numeric" });
}

const fmtSize = (n: number) => (n > 1_000_000 ? `${(n / 1_000_000).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1000))} KB`);

export function ActivityRow({ h, compact, onClick }: { h: HistoryEntry; compact?: boolean; onClick?: () => void }) {
  const m = actionMeta[h.action];
  return (
    <div
      onClick={onClick}
      className={`flex gap-3 rounded-2xl bg-white p-3.5 shadow-sm ring-1 ring-slate-100 ${onClick ? "active:bg-slate-50" : ""}`}
    >
      <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${m.tone}`}>
        <Icon name={m.icon} size={20} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <p className="truncate text-[15px] font-semibold text-slate-900">{h.name}</p>
          <span className="shrink-0 pt-0.5 text-xs text-slate-400">{compact ? `${dayLabel(h.ts)}, ` : ""}{fmtTime(h.ts)}</span>
        </div>
        <p className="text-xs text-slate-500">
          {m.label} · {h.pages} page{h.pages === 1 ? "" : "s"} · {fmtSize(h.size)}
        </p>
        {!compact && (
          <ul className="mt-2 space-y-1">
            {h.details.map((d, i) => (
              <li key={i} className="flex gap-2 text-[13px] text-slate-600">
                <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-indigo-400" />
                {d}
              </li>
            ))}
          </ul>
        )}
        {compact && <p className="mt-0.5 truncate text-[13px] text-slate-500">{h.details[0]}</p>}
      </div>
    </div>
  );
}

export default function History({
  onOpen,
  toast,
  refreshKey,
}: {
  onOpen: (bytes: Uint8Array, name: string) => void;
  toast: (m: string) => void;
  refreshKey: number;
}) {
  const [items, setItems] = useState<HistoryEntry[]>([]);
  const [q, setQ] = useState("");
  const [active, setActive] = useState<HistoryEntry | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  useEffect(() => {
    setItems(listHistory());
  }, [refreshKey]);

  const groups = useMemo(() => {
    const f = items.filter((h) => h.name.toLowerCase().includes(q.toLowerCase()));
    const m = new Map<string, HistoryEntry[]>();
    f.forEach((h) => {
      const k = dayLabel(h.ts);
      m.set(k, [...(m.get(k) ?? []), h]);
    });
    return [...m.entries()];
  }, [items, q]);

  const fileOf = async (h: HistoryEntry) => {
    const bytes = await getHistoryFile(h.id);
    if (!bytes) toast("The saved copy of this file is no longer on this device");
    return bytes;
  };

  return (
    <div className="px-5 pb-28 pt-[calc(1.25rem+env(safe-area-inset-top))]">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">History</h1>
          <p className="mt-1 text-sm text-slate-500">What was changed, on which PDF, and when.</p>
        </div>
        {items.length > 0 && (
          <button onClick={() => setConfirmClear(true)} className="rounded-xl px-3 py-2 text-sm font-medium text-rose-500 active:bg-rose-50">
            Clear
          </button>
        )}
      </div>

      {items.length > 0 && (
        <div className="mt-4 flex items-center gap-2 rounded-2xl bg-white px-4 shadow-sm ring-1 ring-slate-100">
          <Icon name="search" size={18} className="text-slate-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search by file name"
            className="w-full bg-transparent py-3 text-sm outline-none"
          />
        </div>
      )}

      {items.length === 0 ? (
        <div className="mt-16 text-center">
          <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-indigo-50 text-indigo-500">
            <Icon name="clock" size={36} />
          </div>
          <p className="mt-5 font-semibold">No activity yet</p>
          <p className="mx-auto mt-1 max-w-[16rem] text-sm text-slate-500">
            When you save an edited PDF or scan a document it will show up here.
          </p>
        </div>
      ) : (
        <div className="mt-5 space-y-6">
          {groups.length === 0 && <p className="py-10 text-center text-sm text-slate-400">No matches</p>}
          {groups.map(([day, list]) => (
            <section key={day}>
              <h2 className="mb-2 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400">{day}</h2>
              <div className="space-y-2.5">
                {list.map((h) => (
                  <ActivityRow key={h.id} h={h} onClick={() => setActive(h)} />
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      <Sheet open={!!active} onClose={() => setActive(null)} title={active?.name}>
        {active && (
          <div className="space-y-3">
            <p className="text-sm text-slate-500">
              {dayLabel(active.ts)} at {fmtTime(active.ts)}
            </p>
            <div className="grid grid-cols-2 gap-2.5">
              <Btn
                onClick={async () => {
                  const b = await fileOf(active);
                  if (b) {
                    setActive(null);
                    onOpen(b, active.name);
                  }
                }}
              >
                <Icon name="edit" size={18} /> Open
              </Btn>
              <Btn
                variant="soft"
                onClick={async () => {
                  const b = await fileOf(active);
                  if (b) {
                    const r = await savePdf(b, active.name);
                    toast(`Saved to ${r.where}`);
                  }
                }}
              >
                <Icon name="download" size={18} /> Download
              </Btn>
            </div>
            <Btn
              variant="danger"
              className="w-full"
              onClick={async () => {
                await removeHistory(active.id);
                setItems(listHistory());
                setActive(null);
              }}
            >
              <Icon name="trash" size={18} /> Remove from history
            </Btn>
          </div>
        )}
      </Sheet>

      <Sheet open={confirmClear} onClose={() => setConfirmClear(false)} title="Clear all history?">
        <p className="text-sm text-slate-500">This removes every entry and the saved copies stored on this device. Files you already downloaded are not affected.</p>
        <div className="mt-4 grid grid-cols-2 gap-2.5">
          <Btn variant="ghost" onClick={() => setConfirmClear(false)}>
            Cancel
          </Btn>
          <Btn
            variant="danger"
            onClick={async () => {
              await clearHistory();
              setItems([]);
              setConfirmClear(false);
            }}
          >
            Clear all
          </Btn>
        </div>
      </Sheet>
    </div>
  );
}
