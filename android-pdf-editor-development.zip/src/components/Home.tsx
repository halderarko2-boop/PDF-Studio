"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { templates, type Template } from "@/lib/templates";
import { listHistory } from "@/lib/history";
import type { Ann, HistoryEntry } from "@/lib/types";
import { Icon } from "./ui";
import { ActivityRow } from "./History";

function TemplatePreview({ t }: { t: Template }) {
  const anns: Ann[] = useMemo(() => t.build("preview"), [t]);
  return (
    <svg viewBox={`0 0 ${t.w} ${t.h}`} className="h-full w-full bg-white">
      {anns.map((a) => {
        if (a.type === "rect")
          return (
            <rect
              key={a.id}
              x={a.x}
              y={a.y}
              width={a.w}
              height={Math.max(a.h, 1.5)}
              fill={a.fill ?? "none"}
              stroke={a.stroke ?? "none"}
              strokeWidth={a.stroke ? 2 : 0}
            />
          );
        if (a.type === "text")
          return (
            <text key={a.id} fill={a.color} fontSize={a.size} fontWeight={a.bold ? 700 : 400} fontFamily="Helvetica, Arial, sans-serif">
              {a.text.split("\n").map((l, i) => (
                <tspan key={i} x={a.x} y={a.y + a.size * 0.95 + i * a.size * 1.2}>
                  {l}
                </tspan>
              ))}
            </text>
          );
        return null;
      })}
    </svg>
  );
}

export default function Home({
  onOpenFile,
  onMerge,
  onTemplate,
  onScan,
  onSeeHistory,
  refreshKey,
}: {
  onOpenFile: (f: File) => void;
  onMerge: (f: File[]) => void;
  onTemplate: (t: Template) => void;
  onScan: (mode: "camera" | "gallery") => void;
  onSeeHistory: () => void;
  refreshKey: number;
}) {
  const open = useRef<HTMLInputElement>(null);
  const merge = useRef<HTMLInputElement>(null);
  const [recent, setRecent] = useState<HistoryEntry[]>([]);
  useEffect(() => setRecent(listHistory().slice(0, 3)), [refreshKey]);

  return (
    <div className="px-5 pb-28 pt-[calc(1.25rem+env(safe-area-inset-top))]">
      {/* brand */}
      <div className="flex items-center gap-3">
        <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-lg shadow-indigo-500/30">
          <Icon name="file" size={22} />
        </div>
        <div>
          <h1 className="text-xl font-bold leading-tight tracking-tight">PDF Studio</h1>
          <p className="text-xs text-slate-500">Edit, sign & scan — free, no ads</p>
        </div>
      </div>

      {/* hero */}
      <div className="relative mt-6 overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-indigo-600 to-violet-600 p-6 text-white shadow-xl shadow-indigo-600/25">
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10" />
        <div className="absolute -bottom-12 right-10 h-32 w-32 rounded-full bg-white/10" />
        <h2 className="relative text-2xl font-bold leading-snug">
          Open a PDF
          <br />
          and make it yours
        </h2>
        <p className="relative mt-1.5 text-sm text-indigo-100">Add text, sign, highlight, white-out, reorder pages.</p>
        <button
          onClick={() => open.current?.click()}
          className="relative mt-5 inline-flex items-center gap-2 rounded-2xl bg-white px-5 py-3 text-sm font-bold text-indigo-700 shadow-md active:scale-95 transition"
        >
          <Icon name="file" size={18} /> Choose PDF
        </button>
      </div>

      {/* quick actions */}
      <div className="mt-4 grid grid-cols-3 gap-3">
        {[
          { icon: "camera", label: "Scan", sub: "Use camera", tone: "bg-rose-100 text-rose-600", fn: () => onScan("camera") },
          { icon: "image", label: "Photos", sub: "to PDF", tone: "bg-emerald-100 text-emerald-600", fn: () => onScan("gallery") },
          { icon: "merge", label: "Merge", sub: "Combine PDFs", tone: "bg-sky-100 text-sky-600", fn: () => merge.current?.click() },
        ].map((a) => (
          <button
            key={a.label}
            onClick={a.fn}
            className="flex flex-col items-center gap-1.5 rounded-2xl bg-white p-3.5 shadow-sm ring-1 ring-slate-100 active:scale-95 transition"
          >
            <span className={`grid h-11 w-11 place-items-center rounded-xl ${a.tone}`}>
              <Icon name={a.icon} size={22} />
            </span>
            <span className="text-sm font-semibold">{a.label}</span>
            <span className="-mt-1 text-[11px] text-slate-400">{a.sub}</span>
          </button>
        ))}
      </div>

      {/* templates */}
      <div className="mt-8 flex items-end justify-between">
        <h2 className="text-lg font-bold">Start from a template</h2>
      </div>
      <p className="text-sm text-slate-500">Tap any text on a template to fill it in.</p>
      <div className="no-scrollbar -mx-5 mt-3 flex gap-3.5 overflow-x-auto px-5 pb-2">
        {templates.map((t) => (
          <button key={t.id} onClick={() => onTemplate(t)} className="w-[132px] shrink-0 text-left active:scale-95 transition">
            <div
              className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${t.accent} p-2 shadow-md`}
              style={{ aspectRatio: "3 / 4" }}
            >
              <div className="h-full w-full overflow-hidden rounded-lg shadow">
                <TemplatePreview t={t} />
              </div>
            </div>
            <p className="mt-2 text-sm font-semibold">{t.name}</p>
            <p className="text-xs text-slate-400">{t.desc}</p>
          </button>
        ))}
      </div>

      {/* recent */}
      <div className="mt-8 flex items-center justify-between">
        <h2 className="text-lg font-bold">Recent activity</h2>
        {recent.length > 0 && (
          <button onClick={onSeeHistory} className="text-sm font-semibold text-indigo-600">
            See all
          </button>
        )}
      </div>
      {recent.length === 0 ? (
        <div className="mt-3 flex items-center gap-3 rounded-2xl bg-white p-4 text-sm text-slate-500 shadow-sm ring-1 ring-slate-100">
          <Icon name="clock" className="text-slate-300" />
          Your saved edits will appear here.
        </div>
      ) : (
        <div className="mt-3 space-y-2.5">
          {recent.map((h) => (
            <ActivityRow key={h.id} h={h} compact onClick={onSeeHistory} />
          ))}
        </div>
      )}

      <input
        ref={open}
        type="file"
        accept="application/pdf,.pdf"
        hidden
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onOpenFile(f);
          e.target.value = "";
        }}
      />
      <input
        ref={merge}
        type="file"
        accept="application/pdf,.pdf"
        multiple
        hidden
        onChange={(e) => {
          const f = Array.from(e.target.files ?? []);
          if (f.length) onMerge(f);
          e.target.value = "";
        }}
      />
    </div>
  );
}
