import { useMemo, useState } from "react";
import { Check, ImagePlus, Wand2 } from "lucide-react";
import { FitPage } from "../components/PageView";
import { ImagePicker } from "../components/ImagePicker";
import { Sheet } from "../components/ui";
import { CATEGORIES, CatKey, TEMPLATES, Template } from "../lib/templates";
import { CAT_ICON } from "./Home";
import type { ImageEl, LoadedImage, Page } from "../lib/types";

export function applyImages(page: Page, map: Record<string, LoadedImage>): Page {
  return {
    ...page,
    elements: page.elements.map((e) => {
      if (e.type !== "image" || !e.placeholder || !map[e.placeholder]) return e;
      const i = map[e.placeholder];
      return { ...e, src: i.src, ratio: i.h / i.w } as ImageEl;
    }),
  };
}

export function Thumb({ t }: { t: Template }) {
  const p = useMemo(() => t.build(), [t]);
  return <FitPage page={p} />;
}

function Preview({ t, onUse, onClose }: { t: Template; onUse: (page: Page, t: Template) => void; onClose: () => void }) {
  const base = useMemo(() => t.build(), [t]);
  const [imgs, setImgs] = useState<Record<string, LoadedImage>>({});
  const [slot, setSlot] = useState<string | null>(null);
  const page = useMemo(() => applyImages(base, imgs), [base, imgs]);
  return (
    <>
      <Sheet open onClose={onClose} title={t.name} tall>
        <div className="mx-auto rounded-xl overflow-hidden shadow-xl ring-1 ring-black/5 bg-white" style={{ maxWidth: t.w > t.h ? 460 : 300 }}>
          <FitPage page={page} />
        </div>
        {t.slots.length > 0 && (
          <div className="mt-5">
            <div className="text-sm font-semibold text-slate-800 mb-1">Add your pictures</div>
            <div className="text-xs text-slate-500 mb-3">Optional – you can also add or change them later inside the editor.</div>
            <div className="grid grid-cols-2 gap-3">
              {t.slots.map((s) => (
                <button key={s} onClick={() => setSlot(s)} className="flex items-center gap-3 p-2.5 rounded-2xl bg-slate-50 border border-slate-100 text-left active:scale-95 transition">
                  <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-500 flex items-center justify-center overflow-hidden shrink-0">
                    {imgs[s] ? <img src={imgs[s].src} alt="" className="w-full h-full object-cover" /> : <ImagePlus size={20} />}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold">{s}</div>
                    <div className="text-[11px] text-slate-400">{imgs[s] ? "Tap to change" : "Tap to add"}</div>
                  </div>
                  {imgs[s] && <Check size={16} className="text-emerald-500 ml-auto" />}
                </button>
              ))}
            </div>
          </div>
        )}
        <button onClick={() => onUse(page, t)} className="mt-6 w-full h-14 rounded-2xl grad text-white font-semibold flex items-center justify-center gap-2 shadow-lg shadow-indigo-200 active:scale-[.98]"><Wand2 size={20} /> Use this template</button>
      </Sheet>
      <ImagePicker open={!!slot} onClose={() => setSlot(null)} title={`Choose ${slot?.toLowerCase() ?? "picture"}`} onPick={(i) => { setImgs((m) => ({ ...m, [slot!]: i })); setSlot(null); }} />
    </>
  );
}

export default function TemplatesScreen({ cat, setCat, onUse }: { cat: CatKey; setCat: (c: CatKey) => void; onUse: (page: Page, t: Template) => void }) {
  const [open, setOpen] = useState<Template | null>(null);
  const list = TEMPLATES.filter((t) => t.cat === cat);
  const meta = CATEGORIES.find((c) => c.key === cat)!;
  return (
    <div className="px-5 pt-5 pb-32 max-w-xl mx-auto safe-top">
      <h1 className="text-2xl font-extrabold tracking-tight">Templates</h1>
      <p className="text-sm text-slate-500 mt-1">Pick a design, add your logo or photo, and edit every word.</p>
      <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-5 px-5 mt-5 pb-1">
        {CATEGORIES.map((c) => (
          <button key={c.key} onClick={() => setCat(c.key)} className={"h-10 px-4 rounded-full text-sm font-semibold flex items-center gap-1.5 shrink-0 transition " + (cat === c.key ? "bg-indigo-600 text-white shadow-md shadow-indigo-200" : "bg-white text-slate-600 shadow-sm")}>
            {CAT_ICON[c.key]} {c.label}
          </button>
        ))}
      </div>
      <div className="text-xs text-slate-400 mt-4 mb-3">{meta.blurb} · {list.length} templates</div>
      <div className="grid grid-cols-2 gap-4">
        {list.map((t) => (
          <button key={t.id} onClick={() => setOpen(t)} className="text-left bg-white rounded-3xl p-2.5 shadow-sm active:scale-[.97] transition">
            <div className="rounded-2xl overflow-hidden ring-1 ring-black/5 bg-slate-100"><Thumb t={t} /></div>
            <div className="px-1.5 pt-2.5 pb-1 text-sm font-semibold text-slate-800">{t.name}</div>
          </button>
        ))}
      </div>
      {open && <Preview t={open} onClose={() => setOpen(null)} onUse={onUse} />}
    </div>
  );
}
