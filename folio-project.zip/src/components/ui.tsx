import { ReactNode, useEffect, useState } from "react";
import { X } from "lucide-react";
import { useBack } from "../lib/nav";

type Listener = (m: { id: number; text: string }) => void;
let tl: Listener | null = null;
let tid = 0;
export const toast = (text: string) => tl?.({ id: ++tid, text });

export function Toaster() {
  const [m, setM] = useState<{ id: number; text: string } | null>(null);
  useEffect(() => {
    tl = setM;
    return () => void (tl = null);
  }, []);
  useEffect(() => {
    if (!m) return;
    const t = setTimeout(() => setM(null), 3200);
    return () => clearTimeout(t);
  }, [m]);
  if (!m) return null;
  return (
    <div className="fixed left-0 right-0 bottom-28 z-[100] flex justify-center px-4 pointer-events-none">
      <div key={m.id} className="pop bg-slate-900/95 text-white text-sm px-4 py-2.5 rounded-2xl shadow-xl max-w-sm text-center">{m.text}</div>
    </div>
  );
}

export function Sheet({ open, ...rest }: { open: boolean; onClose: () => void; title?: string; children: ReactNode; tall?: boolean }) {
  if (!open) return null;
  return <SheetInner {...rest} />;
}

function SheetInner({ onClose, title, children, tall }: { onClose: () => void; title?: string; children: ReactNode; tall?: boolean }) {
  useBack(onClose);
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center">
      <div className="absolute inset-0 bg-slate-900/50 fade" onClick={onClose} />
      <div className={"relative w-full max-w-xl bg-white rounded-t-[28px] shadow-2xl slide flex flex-col " + (tall ? "h-[90dvh]" : "max-h-[88dvh]")}>
        <div className="flex items-center justify-between px-5 pt-4 pb-2 shrink-0">
          <div className="w-10 h-1.5 rounded-full bg-slate-200 absolute left-1/2 -translate-x-1/2 top-2" />
          <h3 className="font-semibold text-lg text-slate-900 pt-1">{title}</h3>
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center active:scale-95"><X size={18} /></button>
        </div>
        <div className="overflow-y-auto px-5 pb-6 pt-1 flex-1">{children}</div>
      </div>
    </div>
  );
}

export const COLORS = ["#111827", "#ffffff", "#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4", "#3b82f6", "#4f46e5", "#a855f7", "#ec4899", "#6b7280"];

export function Swatches({ value, onChange, none }: { value: string | null; onChange: (c: string | null) => void; none?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      {none && (
        <button onClick={() => onChange(null)} className={"w-8 h-8 shrink-0 rounded-full border-2 relative overflow-hidden bg-white " + (value === null ? "border-indigo-500" : "border-slate-200")}>
          <span className="absolute inset-0 flex items-center justify-center"><span className="w-10 h-0.5 bg-red-500 rotate-45" /></span>
        </button>
      )}
      {COLORS.map((c) => (
        <button key={c} onClick={() => onChange(c)} style={{ background: c }} className={"w-8 h-8 shrink-0 rounded-full border-2 " + (value?.toLowerCase() === c ? "border-indigo-500 scale-110" : "border-slate-200")} />
      ))}
      <label className="w-8 h-8 shrink-0 rounded-full border-2 border-slate-200 overflow-hidden relative" style={{ background: "conic-gradient(red,yellow,lime,aqua,blue,magenta,red)" }}>
        <input type="color" value={value && value.startsWith("#") && value.length === 7 ? value : "#000000"} onChange={(e) => onChange(e.target.value)} className="opacity-0 absolute inset-0 w-full h-full" />
      </label>
    </div>
  );
}

export const fmtTime = (ts: number) => new Date(ts).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
export const fmtDay = (ts: number) => {
  const d = new Date(ts), t = new Date();
  const y = new Date();
  y.setDate(t.getDate() - 1);
  if (d.toDateString() === t.toDateString()) return "Today";
  if (d.toDateString() === y.toDateString()) return "Yesterday";
  return d.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric", year: d.getFullYear() === t.getFullYear() ? undefined : "numeric" });
};
