import { useEffect, useState } from "react";
import { App as CapApp } from "@capacitor/app";
import { Clock, Images, LayoutGrid, Loader2, ScanLine, House } from "lucide-react";
import Home from "./screens/Home";
import TemplatesScreen from "./screens/TemplatesScreen";
import ImagesScreen from "./screens/ImagesScreen";
import HistoryScreen from "./screens/HistoryScreen";
import GuideScreen from "./screens/GuideScreen";
import Editor from "./components/Editor";
import Scanner, { ScanOut } from "./components/Scanner";
import { Toaster, toast } from "./components/ui";
import { initFonts } from "./lib/fonts";
import { A4, blankPage, isNative, openPdfBytes, openPdfFile } from "./lib/pdf";
import { addHistory, Action } from "./lib/storage";
import { CATEGORIES, CatKey, Template } from "./lib/templates";
import { triggerBack, useBack } from "./lib/nav";
import { Page, Session, uid } from "./lib/types";

type View = "home" | "templates" | "images" | "history" | "guide";

export default function App() {
  const [ready, setReady] = useState(false);
  const [view, setView] = useState<View>("home");
  const [cat, setCat] = useState<CatKey>("resume");
  const [session, setSession] = useState<Session | null>(null);
  const [scanMode, setScanMode] = useState<null | "camera" | "gallery">(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    initFonts().then(() => setReady(true));
  }, []);

  useBack(view !== "home" ? () => setView("home") : null);
  useEffect(() => {
    if (!isNative()) return;
    const h = CapApp.addListener("backButton", () => {
      if (!triggerBack()) CapApp.exitApp();
    });
    return () => void h.then((x) => x.remove());
  }, []);

  const start = (s: Session, action: Action, details: string[]) => {
    addHistory({ doc: s.name + ".pdf", action, details, pages: s.pages.length });
    setSession(s);
  };

  const openPdf = async (f: File) => {
    setLoading(true);
    try {
      const s = await openPdfFile(f);
      start(s, "opened", [`Opened ${s.pages.length} page${s.pages.length > 1 ? "s" : ""}`]);
    } catch (e) {
      console.error(e);
      toast("Couldn't open that PDF. It may be damaged or password protected.");
    }
    setLoading(false);
  };

  const useTemplate = (page: Page, t: Template) => {
    const label = CATEGORIES.find((c) => c.key === t.cat)!.label;
    start({ id: uid(), name: `${label} - ${t.name}`, kind: "template", pages: [page], source: null }, "created", [`Template: ${t.name}`, `Category: ${label}`]);
  };

  const blank = () => start({ id: uid(), name: "Untitled", kind: "blank", pages: [blankPage(A4.w, A4.h)], source: null }, "created", ["Blank A4 page"]);

  const fromScan = (outs: ScanOut[], name: string) => {
    const pages: Page[] = outs.map((o) => {
      const long = 842;
      const [w, h] = o.w >= o.h ? [long, (long * o.h) / o.w] : [(long * o.w) / o.h, long];
      return { ...blankPage(w, h), elements: [{ id: uid(), type: "image", x: 0, y: 0, w, h, src: o.src, shape: "rect", opacity: 1, lockAspect: true, ratio: h / w, locked: true }] };
    });
    setScanMode(null);
    start({ id: uid(), name, kind: "scan", pages, source: null }, "scanned", [`${pages.length} page${pages.length > 1 ? "s" : ""} from pictures / camera`]);
  };

  const editBytes = async (bytes: Uint8Array, name: string) => {
    setLoading(true);
    try {
      const s = await openPdfBytes(bytes, name);
      start(s, "opened", ["Re-opened a saved copy from History"]);
    } catch {
      toast("Couldn't open that saved copy");
    }
    setLoading(false);
  };

  if (!ready) {
    return <div className="h-full flex items-center justify-center"><Loader2 className="animate-spin text-indigo-500" /></div>;
  }

  const tabs: { id: View | "scan"; label: string; icon: React.ReactNode }[] = [
    { id: "home", label: "Home", icon: <House size={22} /> },
    { id: "templates", label: "Templates", icon: <LayoutGrid size={22} /> },
    { id: "scan", label: "Scan", icon: <ScanLine size={26} /> },
    { id: "images", label: "Images", icon: <Images size={22} /> },
    { id: "history", label: "History", icon: <Clock size={22} /> },
  ];

  return (
    <div className="h-full relative">
      <div className="h-full overflow-y-auto">
        {view === "home" && <Home onOpenPdf={openPdf} onScan={setScanMode} onBlank={blank} onCategory={(c) => { setCat(c); setView("templates"); }} onGuide={() => setView("guide")} onHistory={() => setView("history")} />}
        {view === "templates" && <TemplatesScreen cat={cat} setCat={setCat} onUse={useTemplate} />}
        {view === "images" && <ImagesScreen />}
        {view === "history" && <HistoryScreen onEdit={editBytes} />}
        {view === "guide" && <GuideScreen onBack={() => setView("home")} />}
      </div>

      <nav className="fixed bottom-0 inset-x-0 z-30 bg-white/90 backdrop-blur-xl border-t border-slate-200/70 safe-bottom">
        <div className="max-w-xl mx-auto grid grid-cols-5 items-end px-2 h-[68px]">
          {tabs.map((t) =>
            t.id === "scan" ? (
              <button key={t.id} onClick={() => setScanMode("camera")} className="flex flex-col items-center -mt-5 text-[11px] font-semibold text-indigo-600">
                <span className="w-14 h-14 rounded-full grad text-white flex items-center justify-center shadow-lg shadow-indigo-300 ring-4 ring-white active:scale-95 transition">{t.icon}</span>
                <span className="mt-1">{t.label}</span>
              </button>
            ) : (
              <button key={t.id} onClick={() => setView(t.id as View)} className={"flex flex-col items-center justify-center gap-1 h-full text-[11px] font-semibold transition " + (view === t.id ? "text-indigo-600" : "text-slate-400")}>
                <span className={"px-4 py-1 rounded-full transition " + (view === t.id ? "bg-indigo-50" : "")}>{t.icon}</span>
                {t.label}
              </button>
            )
          )}
        </div>
      </nav>

      {scanMode && <Scanner startMode={scanMode} onClose={() => setScanMode(null)} onCreate={fromScan} />}
      {session && <Editor key={session.id} session={session} onClose={() => setSession(null)} />}
      {loading && (
        <div className="fixed inset-0 z-[90] bg-slate-900/40 flex items-center justify-center fade">
          <div className="bg-white rounded-3xl px-8 py-6 flex flex-col items-center gap-3 shadow-2xl"><Loader2 className="animate-spin text-indigo-500" /><span className="text-sm font-medium">Opening…</span></div>
        </div>
      )}
      <Toaster />
    </div>
  );
}
