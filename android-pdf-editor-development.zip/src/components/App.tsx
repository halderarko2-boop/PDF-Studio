"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import type { EditorInit } from "@/lib/types";
import { editorInitFromSources, loadSource } from "@/lib/pdf";
import { editorInitFromTemplate, type Template } from "@/lib/templates";
import { readFileBytes } from "@/lib/files";
import Home from "./Home";
import History from "./History";
import Scanner from "./Scanner";
import { Icon, Spinner } from "./ui";

const Editor = dynamic(() => import("./Editor"), { ssr: false });

type View = "home" | "scan" | "history" | "editor";

export default function App() {
  const [view, setView] = useState<View>("home");
  const [init, setInit] = useState<EditorInit | null>(null);
  const [editorKey, setEditorKey] = useState(0);
  const [loading, setLoading] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [scanVisited, setScanVisited] = useState(false);
  const [scanAuto, setScanAuto] = useState<{ mode: "camera" | "gallery"; n: number } | null>(null);
  const [refresh, setRefresh] = useState(0);

  const viewRef = useRef<View>("home");
  const dirty = useRef(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const toast = useCallback((m: string) => {
    setMsg(m);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setMsg(null), 3200);
  }, []);

  const show = (v: View) => {
    viewRef.current = v;
    setView(v);
    if (v === "scan") setScanVisited(true);
    if (v === "home" || v === "history") setRefresh((r) => r + 1);
  };

  const go = (v: View) => {
    if (v === viewRef.current) return;
    window.history.pushState({ v }, "");
    show(v);
  };

  useEffect(() => {
    window.history.replaceState({ v: "home" }, "");
    const onPop = (e: PopStateEvent) => {
      if (viewRef.current === "editor" && dirty.current) {
        if (!window.confirm("Discard your unsaved changes?")) {
          window.history.pushState({ v: "editor" }, "");
          return;
        }
        dirty.current = false;
      }
      const v = (e.state?.v as View | undefined) ?? "home";
      show(v === "editor" && !init ? "home" : v);
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [init]);

  // PWA service worker (web only)
  useEffect(() => {
    if ("serviceWorker" in navigator && location.protocol.startsWith("http") && location.hostname !== "localhost") {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
  }, []);

  const startEditor = (i: EditorInit) => {
    setInit(i);
    setEditorKey((k) => k + 1);
    dirty.current = false;
    go("editor");
  };

  const openBytes = async (bytes: Uint8Array, name: string) => {
    setLoading("Opening PDF…");
    try {
      const src = await loadSource(bytes, name);
      startEditor(editorInitFromSources([src], name));
    } catch (e) {
      console.error(e);
      toast("That file couldn't be opened. Is it a valid, unlocked PDF?");
    } finally {
      setLoading(null);
    }
  };

  const openFile = async (f: File) => openBytes(await readFileBytes(f), f.name);

  const mergeFiles = async (files: File[]) => {
    if (files.length < 2) {
      toast("Pick two or more PDFs to merge");
      return;
    }
    setLoading("Merging PDFs…");
    try {
      const sources = [];
      for (const f of files) sources.push(await loadSource(await readFileBytes(f), f.name));
      startEditor(editorInitFromSources(sources, "Merged"));
    } catch {
      toast("One of those files couldn't be opened");
    } finally {
      setLoading(null);
    }
  };

  const openTemplate = (t: Template) => startEditor(editorInitFromTemplate(t));

  const exitEditor = () => {
    window.history.back(); // popstate handler asks about unsaved changes
  };

  const onDirty = useCallback((d: boolean) => {
    dirty.current = d;
  }, []);

  // after leaving the editor, drop it
  useEffect(() => {
    if (view !== "editor" && init) {
      const t = setTimeout(() => setInit(null), 0);
      return () => clearTimeout(t);
    }
  }, [view, init]);

  const startScan = (mode: "camera" | "gallery") => {
    setScanAuto((p) => ({ mode, n: (p?.n ?? 0) + 1 }));
    go("scan");
  };

  const nav = [
    { id: "home" as const, icon: "home", label: "Home" },
    { id: "history" as const, icon: "clock", label: "History" },
  ];

  return (
    <div className="mx-auto min-h-dvh max-w-xl">
      <div className={view === "home" ? "" : "hidden"}>
        <Home
          onOpenFile={openFile}
          onMerge={mergeFiles}
          onTemplate={openTemplate}
          onScan={startScan}
          onSeeHistory={() => go("history")}
          refreshKey={refresh}
        />
      </div>
      {scanVisited && (
        <div className={view === "scan" ? "" : "hidden"}>
          <Scanner
            toast={toast}
            autoOpen={scanAuto}
            onEdit={(b, n) => openBytes(b, n)}
          />
        </div>
      )}
      <div className={view === "history" ? "" : "hidden"}>
        <History onOpen={openBytes} toast={toast} refreshKey={refresh} />
      </div>

      {view === "editor" && init && (
        <Editor key={editorKey} init={init} onExit={exitEditor} onDirty={onDirty} toast={toast} />
      )}

      {/* bottom nav */}
      {view !== "editor" && (
        <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200/70 bg-white/90 pb-safe backdrop-blur-lg">
          <div className="mx-auto flex max-w-xl items-center justify-around px-6 py-1.5">
            <NavBtn item={nav[0]} active={view === "home"} onClick={() => go("home")} />
            <button
              onClick={() => go("scan")}
              aria-label="Scan"
              className={`-mt-6 grid h-14 w-14 place-items-center rounded-full text-white shadow-lg ring-4 ring-white transition active:scale-95 ${view === "scan" ? "bg-violet-600 shadow-violet-600/40" : "bg-indigo-600 shadow-indigo-600/40"}`}
            >
              <Icon name="camera" size={26} />
            </button>
            <NavBtn item={nav[1]} active={view === "history"} onClick={() => go("history")} />
          </div>
        </nav>
      )}

      {loading && (
        <div className="fixed inset-0 z-[90] grid place-items-center bg-white/70 backdrop-blur-sm">
          <Spinner label={loading} />
        </div>
      )}

      {msg && (
        <div className="animate-pop fixed bottom-24 left-1/2 z-[100] max-w-[90vw] -translate-x-1/2 rounded-full bg-slate-900 px-5 py-3 text-sm font-medium text-white shadow-xl">
          {msg}
        </div>
      )}
    </div>
  );
}

function NavBtn({
  item,
  active,
  onClick,
}: {
  item: { icon: string; label: string };
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex w-20 flex-col items-center gap-0.5 rounded-xl py-1.5 text-[11px] font-semibold transition ${active ? "text-indigo-600" : "text-slate-400"}`}
    >
      <Icon name={item.icon} size={24} strokeWidth={active ? 2.2 : 1.8} />
      {item.label}
    </button>
  );
}
