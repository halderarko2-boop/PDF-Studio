# Folio PDF – make the Android APK from your phone (beginner guide)

You need: an Android phone, internet, and a free GitHub account. No computer needed.
The app works on **Android 8.0 and newer**.

## What you have
* `folio-project.zip` – the whole app (download it from the app: Home → **Get APK** → **Download project ZIP**).
* `.github/workflows/build-apk.yml` – the "build recipe" that tells GitHub to turn the app into an APK.
  (Also available from the same screen: **Copy build recipe**.)

## Steps

### 1. Create a GitHub account
1. Open https://github.com in Chrome → **Sign up**.
2. Verify your email.
3. In Chrome tap **⋮** → tick **Desktop site** (makes GitHub easier to use on a phone).

### 2. Create a repository
1. Tap **+** (top right) → **New repository**.
2. Name: `folio-pdf`. Choose **Public**. Tick **Add a README file**.
3. Tap **Create repository**.

### 3. Upload the ZIP (do NOT unzip it)
1. In the repository tap **Add file → Upload files**.
2. Tap **choose your files** → pick `folio-project.zip` from *Downloads*.
3. Wait for the upload, scroll down, tap **Commit changes**.

### 4. Add the build recipe
1. **Add file → Create new file**.
2. In the file-name box type: `.github/workflows/build-apk.yml`
   (each `/` creates a folder).
3. Paste the build recipe text (copied from the app, or open `build-apk.yml` from the ZIP).
4. Tap **Commit changes… → Commit changes**.

The build starts automatically.

### 5. Wait
Open the **Actions** tab → **Build Android APK**. It takes 6–12 minutes.
Green tick = done. Red cross = open it and read the failing step (see troubleshooting).

### 6. Download the APK
* Repository main page → **Releases** → newest release → tap **Folio-PDF.apk**.
* Or: Actions → the finished run → **Artifacts** → `Folio-PDF-apk` (zip containing the APK).

### 7. Install
1. Open the downloaded `Folio-PDF.apk`.
2. If Android blocks it: **Settings → Allow from this source** → back → **Install**.
3. If Play Protect warns: **More details → Install anyway** (it is your own app).
4. Open **Folio PDF**, allow the camera when asked.

PDFs you save go to **Documents/Folio**. If Android doesn't allow that, a share sheet appears so you can choose a location (Drive, Files, WhatsApp…).

## Troubleshooting
| Problem | Fix |
|---|---|
| Nothing builds | Actions tab → enable workflows → *Build Android APK* → **Run workflow** |
| "Resource not accessible by integration" | Settings → Actions → General → Workflow permissions → **Read and write** → Save → re-run the job |
| "package.json not found" | The ZIP must be in the main folder next to README.md. Upload it again |
| No "Releases" section | Build must be green; use Artifacts instead |
| Want to update the app | Upload a new ZIP with the same name (replaces the old one) and commit. A new APK is built |

## Optional: build on a computer instead
```bash
npm install
npm run build
npx cap add android
# edit android/variables.gradle -> minSdkVersion = 26
# add the CAMERA permission to android/app/src/main/AndroidManifest.xml
npx cap sync android
cd android && ./gradlew assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
```
Requires Node 22 and Java 21.

## Supported picture formats (25)
JPG, JPEG, JPE, JIF, JFIF, JFI, PJPEG, PJP, PNG, APNG, GIF, WEBP, AVIF, AVIFS, BMP, DIB, ICO, CUR, SVG, SVGZ, TIF, TIFF, HEIC, HEIF, HIF.
