import { useRef, useState } from "react";
import { Camera, Images, Loader2, Trash2, Upload } from "lucide-react";
import { Sheet, toast } from "./ui";
import { IMAGE_ACCEPT, IMAGE_FORMATS, loadImageFiles } from "../lib/images";
import { addToLibrary, removeFromLibrary, useLibrary } from "../lib/storage";
import type { LoadedImage } from "../lib/types";

export function useImageImport() {
  const [busy, setBusy] = useState(false);
  const run = async (files: FileList | null, save = true) => {
    if (!files || !files.length) return [];
    setBusy(true);
    const { out, failed } = await loadImageFiles(files);
    if (save) for (const i of out) await addToLibrary(i);
    setBusy(false);
    if (failed.length) toast(`Couldn't read: ${failed.join(", ")}`);
    return out;
  };
  return { busy, run };
}

export function ImagePicker({ open, onClose, onPick, title = "Add a picture" }: { open: boolean; onClose: () => void; onPick: (i: LoadedImage) => void; title?: string }) {
  const lib = useLibrary();
  const { busy, run } = useImageImport();
  const file = useRef<HTMLInputElement>(null);
  const cam = useRef<HTMLInputElement>(null);
  const pickFrom = async (files: FileList | null) => {
    const out = await run(files);
    if (out[0]) onPick(out[0]);
  };
  return (
    <Sheet open={open} onClose={onClose} title={title}>
      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => file.current?.click()} className="rounded-2xl bg-indigo-50 text-indigo-700 py-4 flex flex-col items-center gap-1 font-medium active:scale-95">
          {busy ? <Loader2 className="animate-spin" /> : <Upload />} Upload picture
        </button>
        <button onClick={() => cam.current?.click()} className="rounded-2xl bg-violet-50 text-violet-700 py-4 flex flex-col items-center gap-1 font-medium active:scale-95">
          <Camera /> Take photo
        </button>
      </div>
      <input ref={file} type="file" accept={IMAGE_ACCEPT} className="hidden" multiple onChange={(e) => { pickFrom(e.target.files); e.target.value = ""; }} />
      <input ref={cam} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => { pickFrom(e.target.files); e.target.value = ""; }} />
      <p className="text-[11px] text-slate-400 mt-3 leading-relaxed">Works with {IMAGE_FORMATS.length} formats: {IMAGE_FORMATS.join(", ")}.</p>
      <div className="flex items-center gap-2 mt-5 mb-2 text-sm font-semibold text-slate-700"><Images size={16} /> My images <span className="text-slate-400 font-normal">(logos, clients, signatures)</span></div>
      {lib.length === 0 ? (
        <div className="text-sm text-slate-400 bg-slate-50 rounded-2xl p-5 text-center">Pictures you upload are saved here so you can reuse them anytime.</div>
      ) : (
        <div className="grid grid-cols-3 gap-2.5">
          {lib.map((i) => (
            <div key={i.id} className="relative aspect-square rounded-2xl overflow-hidden bg-[repeating-conic-gradient(#f1f5f9_0%_25%,#fff_0%_50%)] bg-[length:16px_16px] border border-slate-200">
              <button className="w-full h-full" onClick={() => onPick(i)}><img src={i.src} alt={i.name} className="w-full h-full object-contain" /></button>
              <button onClick={() => removeFromLibrary(i.id)} className="absolute top-1 right-1 w-7 h-7 rounded-full bg-white/90 text-slate-500 flex items-center justify-center"><Trash2 size={13} /></button>
            </div>
          ))}
        </div>
      )}
    </Sheet>
  );
}
