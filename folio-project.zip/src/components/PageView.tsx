import { memo, useEffect, useMemo, useRef, useState } from "react";
import { ImagePlus } from "lucide-react";
import { LINE_H, wrapText } from "../lib/fonts";
import type { DocSource, DrawEl, El, Page } from "../lib/types";

export type Tool = "select" | "text" | "rect" | "ellipse" | "line" | "highlight" | "whiteout" | "draw";

const FAMILY = { helv: "Helvetica, Arial, Roboto, sans-serif", times: "'Times New Roman', Times, 'Noto Serif', serif", cour: "'Courier New', Courier, 'Droid Sans Mono', monospace" };

function PdfCanvas({ source, index, w, h, s, visible }: { source: DocSource; index: number; w: number; h: number; s: number; visible: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!visible) return;
    let task: { cancel: () => void; promise: Promise<unknown> } | null = null;
    let dead = false;
    const t = setTimeout(async () => {
      try {
        const page = await source.pdf.getPage(index + 1);
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const k = Math.min(s * dpr, 3600 / Math.max(w, h));
        const vp = page.getViewport({ scale: k });
        const off = document.createElement("canvas");
        off.width = Math.floor(vp.width);
        off.height = Math.floor(vp.height);
        task = page.render({ canvasContext: off.getContext("2d")!, viewport: vp });
        await task.promise;
        if (dead || !ref.current) return;
        ref.current.width = off.width;
        ref.current.height = off.height;
        ref.current.getContext("2d")!.drawImage(off, 0, 0);
      } catch {
        /* cancelled */
      }
    }, 100);
    return () => {
      dead = true;
      clearTimeout(t);
      task?.cancel();
    };
  }, [visible, s, index, source, w, h]);
  return <canvas ref={ref} className="absolute inset-0 pointer-events-none" style={{ width: w * s, height: h * s, background: "#fff" }} />;
}

interface ElProps {
  el: El;
  s: number;
  selected: boolean;
  interactive: boolean;
  tool: Tool;
  onSelect: (id: string) => void;
  onLive: (id: string, patch: Partial<El>) => void;
  onCommit: (label: string) => void;
  onPlaceholder: (id: string) => void;
}

const ElView = memo(function ElView({ el, s, selected, interactive, tool, onSelect, onLive, onCommit, onPlaceholder }: ElProps) {
  const drag = useRef<{ sx: number; sy: number; ox: number; oy: number; moved: boolean } | null>(null);
  const rs = useRef<{ sx: number; sy: number; ow: number; oh: number } | null>(null);
  const canTouch = interactive && tool === "select" && !el.locked;

  const lines = useMemo(
    () => (el.type === "text" ? wrapText(el.text, el.size, el.font, el.bold, el.italic, el.w) : []),
    [el.type === "text" && el.text, el.type === "text" && el.size, el.type === "text" && el.font, el.type === "text" && el.bold, el.type === "text" && el.italic, el.w] // eslint-disable-line
  );

  const style: React.CSSProperties = {
    position: "absolute", left: el.x * s, top: el.y * s, width: el.w * s, height: el.h * s,
    pointerEvents: canTouch ? "auto" : "none",
    touchAction: selected ? "none" : "auto",
    outline: selected ? "2px solid #6366f1" : undefined, outlineOffset: 2,
    cursor: selected ? "move" : "pointer",
  };

  let inner: React.ReactNode = null;
  if (el.type === "text") {
    inner = (
      <div style={{ width: "100%", fontSize: el.size * s, lineHeight: LINE_H, color: el.color, fontFamily: FAMILY[el.font], fontWeight: el.bold ? 700 : 400, fontStyle: el.italic ? "italic" : "normal", textAlign: el.align, whiteSpace: "pre", opacity: el.opacity ?? 1, userSelect: "none" }}>
        {lines.map((l, i) => <div key={i} style={{ minHeight: el.size * s * LINE_H }}>{l}</div>)}
      </div>
    );
  } else if (el.type === "rect" || el.type === "ellipse") {
    inner = <div style={{ width: "100%", height: "100%", background: el.fill ?? "transparent", border: el.stroke ? `${Math.max(0.5, el.strokeW * s)}px solid ${el.stroke}` : undefined, boxSizing: "border-box", borderRadius: el.type === "ellipse" ? "50%" : 0, opacity: el.opacity }} />;
  } else if (el.type === "image") {
    const rad = el.shape === "circle" ? "50%" : 0;
    inner = el.src ? (
      <img src={el.src} alt="" draggable={false} style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: rad, opacity: el.opacity, display: "block" }} />
    ) : (
      <div style={{ width: "100%", height: "100%", borderRadius: rad, background: "#eef2ff", border: "1.5px dashed #818cf8", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#6366f1", gap: 2, overflow: "hidden" }}>
        <ImagePlus size={Math.max(10, Math.min(el.w, el.h) * s * 0.25)} />
        <span style={{ fontSize: Math.max(7, Math.min(el.w, el.h) * s * 0.13), fontWeight: 600 }}>{interactive ? "Tap to add " : ""}{el.placeholder || "image"}</span>
      </div>
    );
  } else if (el.type === "draw") {
    const d = el as DrawEl;
    inner = (
      <svg width="100%" height="100%" viewBox="0 0 1 1" preserveAspectRatio="none" style={{ overflow: "visible", opacity: d.opacity }}>
        <polyline points={d.points.map((p) => p.join(",")).join(" ")} fill="none" stroke={d.color} strokeWidth={d.width * s} strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
      </svg>
    );
  }

  return (
    <div
      style={style}
      onClick={(e) => {
        if (!interactive) return;
        e.stopPropagation();
        if (!selected) onSelect(el.id);
        if (el.type === "image" && !el.src) onPlaceholder(el.id);
      }}
      onPointerDown={(e) => {
        if (!selected || !canTouch) return;
        e.currentTarget.setPointerCapture(e.pointerId);
        drag.current = { sx: e.clientX, sy: e.clientY, ox: el.x, oy: el.y, moved: false };
      }}
      onPointerMove={(e) => {
        const d = drag.current;
        if (!d) return;
        const dx = e.clientX - d.sx, dy = e.clientY - d.sy;
        if (!d.moved && Math.hypot(dx, dy) < 4) return;
        d.moved = true;
        onLive(el.id, { x: d.ox + dx / s, y: d.oy + dy / s });
      }}
      onPointerUp={() => {
        if (drag.current?.moved) onCommit("Moved / aligned");
        drag.current = null;
      }}
      onPointerCancel={() => {
        if (drag.current?.moved) onCommit("Moved / aligned");
        drag.current = null;
      }}
    >
      {inner}
      {selected && canTouch && (
        <div
          style={{ position: "absolute", right: -16, bottom: -16, width: 32, height: 32, touchAction: "none", display: "flex", alignItems: "center", justifyContent: "center" }}
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => {
            e.stopPropagation();
            e.currentTarget.setPointerCapture(e.pointerId);
            rs.current = { sx: e.clientX, sy: e.clientY, ow: el.w, oh: el.h };
          }}
          onPointerMove={(e) => {
            const r = rs.current;
            if (!r) return;
            const nw = Math.max(10, r.ow + (e.clientX - r.sx) / s);
            if (el.type === "text") onLive(el.id, { w: nw });
            else if (el.type === "image" && el.lockAspect && el.ratio) onLive(el.id, { w: nw, h: nw * el.ratio });
            else onLive(el.id, { w: nw, h: Math.max(2, r.oh + (e.clientY - r.sy) / s) });
          }}
          onPointerUp={() => {
            if (rs.current) onCommit("Resized");
            rs.current = null;
          }}
        >
          <div style={{ width: 18, height: 18, borderRadius: 9, background: "#fff", border: "3px solid #6366f1", boxShadow: "0 1px 4px rgba(0,0,0,.3)" }} />
        </div>
      )}
    </div>
  );
});

export interface PageViewProps {
  page: Page;
  scale: number;
  source: DocSource | null;
  interactive?: boolean;
  lazy?: boolean;
  selectedId?: string | null;
  tool?: Tool;
  drawColor?: string;
  drawWidth?: number;
  onSelect?: (id: string | null) => void;
  onLive?: (pageId: string, id: string, patch: Partial<El>) => void;
  onCommit?: (label: string) => void;
  onTap?: (pageId: string, x: number, y: number) => void;
  onDraw?: (pageId: string, pts: [number, number][]) => void;
  onPlaceholder?: (pageId: string, id: string) => void;
  onActive?: (pageId: string) => void;
}

const noop = () => {};

export const PageView = memo(function PageView(p: PageViewProps) {
  const { page, scale: s, source, interactive = false, lazy = false, selectedId = null, tool = "select" } = p;
  const ref = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(!lazy);
  const [path, setPath] = useState<[number, number][] | null>(null);
  const pts = useRef<[number, number][] | null>(null);

  useEffect(() => {
    if (!lazy || !ref.current) return;
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && setVis(true)), { rootMargin: "800px 0px" });
    io.observe(ref.current);
    let io2: IntersectionObserver | null = null;
    if (p.onActive) {
      io2 = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && p.onActive!(page.id)), { rootMargin: "-45% 0px -45% 0px" });
      io2.observe(ref.current);
    }
    return () => {
      io.disconnect();
      io2?.disconnect();
    };
  }, [lazy, page.id]); // eslint-disable-line

  const toPt = (e: React.PointerEvent | React.MouseEvent): [number, number] => {
    const r = ref.current!.getBoundingClientRect();
    return [(e.clientX - r.left) / s, (e.clientY - r.top) / s];
  };

  return (
    <div
      ref={ref}
      data-page={page.id}
      onClick={(e) => {
        if (!interactive || e.target !== e.currentTarget) return;
        const [x, y] = toPt(e);
        if (tool === "select") p.onSelect?.(null);
        else p.onTap?.(page.id, x, y);
      }}
      style={{ position: "relative", width: page.width * s, height: page.height * s, background: page.srcIndex === null ? page.bg : "#fff", overflow: interactive ? "visible" : "hidden", flexShrink: 0 }}
    >
      {page.srcIndex !== null && source && <PdfCanvas source={source} index={page.srcIndex} w={page.width} h={page.height} s={s} visible={vis} />}
      {page.elements.map((el) => (
        <ElView
          key={el.id}
          el={el}
          s={s}
          selected={selectedId === el.id}
          interactive={interactive}
          tool={tool}
          onSelect={(id) => p.onSelect?.(id)}
          onLive={(id, patch) => p.onLive?.(page.id, id, patch)}
          onCommit={p.onCommit ?? noop}
          onPlaceholder={(id) => p.onPlaceholder?.(page.id, id)}
        />
      ))}
      {interactive && tool === "draw" && (
        <svg
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", touchAction: "none", cursor: "crosshair" }}
          onPointerDown={(e) => {
            e.currentTarget.setPointerCapture(e.pointerId);
            pts.current = [toPt(e)];
            setPath([...pts.current]);
          }}
          onPointerMove={(e) => {
            if (!pts.current) return;
            pts.current.push(toPt(e));
            setPath([...pts.current]);
          }}
          onPointerUp={() => {
            if (pts.current && pts.current.length) p.onDraw?.(page.id, pts.current);
            pts.current = null;
            setPath(null);
          }}
        >
          {path && <polyline points={path.map((q) => `${q[0] * s},${q[1] * s}`).join(" ")} fill="none" stroke={p.drawColor} strokeWidth={(p.drawWidth ?? 3) * s} strokeLinecap="round" strokeLinejoin="round" />}
        </svg>
      )}
    </div>
  );
});

/** Renders a page scaled to the width of its container (for thumbnails & previews) */
export function FitPage({ page, source = null, className = "" }: { page: Page; source?: DocSource | null; className?: string }) {
  const box = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(0);
  useEffect(() => {
    const ro = new ResizeObserver(() => box.current && setW(box.current.clientWidth));
    ro.observe(box.current!);
    setW(box.current!.clientWidth);
    return () => ro.disconnect();
  }, []);
  const k = w / page.width || 0.3;
  return (
    <div ref={box} className={"relative w-full overflow-hidden " + className} style={{ height: page.height * k }}>
      <div style={{ transform: `scale(${k})`, transformOrigin: "top left", width: page.width, height: page.height, position: "absolute", left: 0, top: 0 }}>
        <PageView page={page} scale={1} source={source} lazy={!!source} />
      </div>
    </div>
  );
}
