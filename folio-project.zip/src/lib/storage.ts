import { useEffect, useState } from "react";
import { del, get, set } from "idb-keyval";
import { uid } from "./types";

/* ---------------- history ---------------- */
export type Action = "opened" | "created" | "scanned" | "edited" | "exported";
export interface HistoryItem {
  id: string;
  ts: number;
  doc: string;
  action: Action;
  details: string[];
  fileKey?: string;
  pages?: number;
}
const HK = "folio.history.v1";
const subs = new Set<() => void>();
const notify = () => subs.forEach((f) => f());

export function getHistory(): HistoryItem[] {
  try {
    return JSON.parse(localStorage.getItem(HK) || "[]");
  } catch {
    return [];
  }
}
function saveHistory(items: HistoryItem[]) {
  try {
    localStorage.setItem(HK, JSON.stringify(items.slice(0, 300)));
  } catch {
    /* storage full */
  }
  notify();
}
export function addHistory(h: Omit<HistoryItem, "id" | "ts">) {
  const item: HistoryItem = { ...h, id: uid(), ts: Date.now() };
  saveHistory([item, ...getHistory()]);
  // keep the 15 newest saved files only
  const withFiles = getHistory().filter((i) => i.fileKey);
  withFiles.slice(15).forEach((i) => del(i.fileKey!).catch(() => {}));
  if (withFiles.length > 15) {
    const drop = new Set(withFiles.slice(15).map((i) => i.id));
    saveHistory(getHistory().map((i) => (drop.has(i.id) ? { ...i, fileKey: undefined } : i)));
  }
  return item;
}
export function removeHistory(id: string) {
  const it = getHistory().find((i) => i.id === id);
  if (it?.fileKey) del(it.fileKey).catch(() => {});
  saveHistory(getHistory().filter((i) => i.id !== id));
}
export function clearHistory() {
  getHistory().forEach((i) => i.fileKey && del(i.fileKey).catch(() => {}));
  saveHistory([]);
}
export const storeFile = (key: string, bytes: Uint8Array) => set(key, bytes);
export const loadFile = (key: string) => get<Uint8Array>(key);

export function useHistory() {
  const [items, setItems] = useState<HistoryItem[]>(getHistory);
  useEffect(() => {
    const f = () => setItems(getHistory());
    subs.add(f);
    return () => void subs.delete(f);
  }, []);
  return items;
}

/* ---------------- image library (logos, client pictures…) ---------------- */
export interface LibImage {
  id: string;
  name: string;
  src: string;
  w: number;
  h: number;
  ts: number;
}
const LK = "folio.library.v1";
let lib: LibImage[] = [];
let libLoaded = false;
const libSubs = new Set<() => void>();
const loadLib = async () => {
  if (libLoaded) return;
  libLoaded = true;
  lib = (await get<LibImage[]>(LK)) || [];
  libSubs.forEach((f) => f());
};
export async function addToLibrary(img: { name: string; src: string; w: number; h: number }) {
  await loadLib();
  const item = { ...img, id: uid(), ts: Date.now() };
  lib = [item, ...lib].slice(0, 60);
  libSubs.forEach((f) => f());
  await set(LK, lib);
  return item;
}
export async function removeFromLibrary(id: string) {
  lib = lib.filter((i) => i.id !== id);
  libSubs.forEach((f) => f());
  await set(LK, lib);
}
export function useLibrary() {
  const [items, setItems] = useState<LibImage[]>(lib);
  useEffect(() => {
    const f = () => setItems([...lib]);
    libSubs.add(f);
    loadLib();
    return () => void libSubs.delete(f);
  }, []);
  return items;
}
