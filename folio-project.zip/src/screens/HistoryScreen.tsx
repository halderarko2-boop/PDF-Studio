import { useState } from "react";
import { Clock, Download, FileText, Pencil, Share2, Trash2 } from "lucide-react";
import { ACTION_META } from "./Home";
import { fmtDay, fmtTime, Sheet, toast } from "../components/ui";
import { clearHistory, HistoryItem, loadFile, removeHistory, useHistory } from "../lib/storage";
import { saveBytes, shareBytes } from "../lib/pdf";

export default function HistoryScreen({ onEdit }: { onEdit: (bytes: Uint8Array, name: string) => void }) {
  const items = useHistory();
  const [confirm, setConfirm] = useState(false);

  const withFile = async (h: HistoryItem, fn: (b: Uint8Array) => Promise<unknown> | unknown) => {
    const b = h.fileKey ? await loadFile(h.fileKey) : undefined;
    if (!b) return toast("That saved copy is no longer stored on this device");
    try {
      await fn(b);
    } catch {
      /* cancelled */
    }
  };

  const groups: { day: string; list: HistoryItem[] }[] = [];
  items.forEach((i) => {
    const d = fmtDay(i.ts);
    const g = groups.find((x) => x.day === d);
    if (g) g.list.push(i);
    else groups.push({ day: d, list: [i] });
  });

  return (
    <div className="px-5 pt-5 pb-32 max-w-xl mx-auto safe-top">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">History</h1>
          <p className="text-sm text-slate-500 mt-1">What was done, to which PDF, and when.</p>
        </div>
        {items.length > 0 && <button onClick={() => setConfirm(true)} className="text-sm font-semibold text-red-500 px-2 py-1">Clear</button>}
      </div>

      {items.length === 0 ? (
        <div className="mt-10 bg-white rounded-3xl p-10 text-center shadow-sm flex flex-col items-center gap-3">
          <div className="w-16 h-16 rounded-3xl bg-indigo-50 text-indigo-400 flex items-center justify-center"><Clock size={28} /></div>
          <div className="font-semibold">No history yet</div>
          <div className="text-sm text-slate-400">Open, scan or create a PDF and every step will be listed here.</div>
        </div>
      ) : (
        groups.map((g) => (
          <div key={g.day} className="mt-6">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5 px-1">{g.day}</div>
            <div className="relative pl-5 space-y-3">
              <div className="absolute left-[7px] top-2 bottom-2 w-0.5 bg-slate-200" />
              {g.list.map((h) => (
                <div key={h.id} className="relative bg-white rounded-2xl p-4 shadow-sm">
                  <div className="absolute -left-[18px] top-5 w-3.5 h-3.5 rounded-full bg-white border-[3px] border-indigo-400" />
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center shrink-0"><FileText size={18} /></div>
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-[15px] break-words">{h.doc}</div>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className={"text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-md " + ACTION_META[h.action].color}>{ACTION_META[h.action].label}</span>
                        <span className="text-xs text-slate-400">{fmtTime(h.ts)}{h.pages ? ` · ${h.pages} page${h.pages > 1 ? "s" : ""}` : ""}</span>
                      </div>
                    </div>
                    <button onClick={() => removeHistory(h.id)} className="w-8 h-8 text-slate-300 hover:text-red-500 flex items-center justify-center"><Trash2 size={16} /></button>
                  </div>
                  {h.details.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-3">
                      {h.details.map((d, i) => <span key={i} className="text-xs bg-slate-100 text-slate-600 rounded-lg px-2 py-1">{d}</span>)}
                    </div>
                  )}
                  {h.fileKey && (
                    <div className="grid grid-cols-3 gap-2 mt-3">
                      <button onClick={() => withFile(h, async (b) => toast("Saved to " + (await saveBytes(b, h.doc))))} className="h-10 rounded-xl bg-indigo-50 text-indigo-700 text-xs font-semibold flex items-center justify-center gap-1.5"><Download size={14} /> Download</button>
                      <button onClick={() => withFile(h, (b) => shareBytes(b, h.doc))} className="h-10 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5"><Share2 size={14} /> Share</button>
                      <button onClick={() => withFile(h, (b) => onEdit(b, h.doc.replace(/\.pdf$/i, "")))} className="h-10 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5"><Pencil size={14} /> Edit</button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))
      )}

      <Sheet open={confirm} onClose={() => setConfirm(false)} title="Clear all history?">
        <p className="text-sm text-slate-500">This removes the activity list and the saved copies kept inside the app. PDFs you already saved to your phone are not touched.</p>
        <div className="grid grid-cols-2 gap-3 mt-5">
          <button onClick={() => setConfirm(false)} className="h-12 rounded-2xl bg-slate-100 font-semibold">Cancel</button>
          <button onClick={() => { clearHistory(); setConfirm(false); }} className="h-12 rounded-2xl bg-red-500 text-white font-semibold">Clear</button>
        </div>
      </Sheet>
    </div>
  );
}
