import { Capacitor } from "@capacitor/core";

export const isNative = () => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

function toBase64(bytes: Uint8Array): string {
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

export function safeName(name: string): string {
  const base = name.replace(/\.pdf$/i, "").replace(/[\\/:*?"<>|]+/g, "-").trim() || "document";
  return base + ".pdf";
}

export type SaveResult = { where: string };

/** Saves a PDF. In the browser it downloads; in the Android app it writes to
 *  Documents/PDF Studio and opens the share sheet. */
export async function savePdf(bytes: Uint8Array, rawName: string): Promise<SaveResult> {
  const name = safeName(rawName);

  if (isNative()) {
    const { Filesystem, Directory } = await import("@capacitor/filesystem");
    const { Share } = await import("@capacitor/share");
    const data = toBase64(bytes);
    let uri = "";
    let where = "Documents/PDF Studio";
    try {
      try {
        await Filesystem.requestPermissions();
      } catch {
        /* not needed on newer Android */
      }
      const res = await Filesystem.writeFile({
        path: `PDF Studio/${name}`,
        data,
        directory: Directory.Documents,
        recursive: true,
      });
      uri = res.uri;
    } catch {
      const res = await Filesystem.writeFile({
        path: name,
        data,
        directory: Directory.Cache,
      });
      uri = res.uri;
      where = "the share sheet";
    }
    try {
      await Share.share({ title: name, url: uri, dialogTitle: "Save or share PDF" });
    } catch {
      /* user dismissed the sheet */
    }
    return { where };
  }

  const blob = new Blob([bytes as BlobPart], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  return { where: "your Downloads folder" };
}

export function readFileBytes(file: File): Promise<Uint8Array> {
  return file.arrayBuffer().then((b) => new Uint8Array(b));
}
