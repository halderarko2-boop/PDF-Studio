"use client";

import type { ReactNode } from "react";
import { useEffect } from "react";

const paths: Record<string, ReactNode> = {
  home: <path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10" />,
  camera: (
    <>
      <path d="M4 8h3l2-3h6l2 3h3v11H4z" />
      <circle cx="12" cy="13" r="3.5" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  back: <path d="M15 5l-7 7 7 7" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  undo: <path d="M9 14L4 9l5-5M4 9h10a6 6 0 010 12h-3" />,
  check: <path d="M5 12.5l4.5 4.5L19 7" />,
  download: <path d="M12 4v11m0 0l-4-4m4 4l4-4M5 20h14" />,
  file: (
    <>
      <path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z" />
      <path d="M14 3v5h5" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  trash: <path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" />,
  copy: (
    <>
      <rect x="8" y="8" width="12" height="12" rx="2" />
      <path d="M16 8V5a1 1 0 00-1-1H5a1 1 0 00-1 1v10a1 1 0 001 1h3" />
    </>
  ),
  select: <path d="M5 3l14 8-6 2-2 6z" />,
  text: <path d="M5 6V4h14v2M12 4v16M9 20h6" />,
  pen: <path d="M4 20l1-4L16 5l3 3L8 19zM14 7l3 3" />,
  highlight: (
    <>
      <path d="M9 14l6-6 3 3-6 6H9z" />
      <path d="M4 20h8" />
    </>
  ),
  whiteout: (
    <>
      <path d="M8 20h12M5 15l8-8 5 5-5 5H8z" />
    </>
  ),
  shape: <rect x="4" y="5" width="16" height="14" rx="2" />,
  image: (
    <>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <circle cx="9" cy="10" r="1.5" />
      <path d="M21 16l-5-5-9 9" />
    </>
  ),
  sign: <path d="M3 17c3-6 5-9 6-9s0 6 2 6 3-4 4-4 1 3 3 3M3 21h18" />,
  stamp: (
    <>
      <path d="M9 3h6v6l3 4H6l3-4z" />
      <path d="M5 17h14v3H5z" />
    </>
  ),
  pages: (
    <>
      <rect x="6" y="3" width="12" height="15" rx="1.5" />
      <path d="M4 7v13h11" />
    </>
  ),
  rotate: <path d="M20 12a8 8 0 11-3-6.2M20 4v5h-5" />,
  up: <path d="M6 14l6-6 6 6" />,
  down: <path d="M6 10l6 6 6-6" />,
  merge: <path d="M6 4v6a6 6 0 006 6h0a6 6 0 006-6V4M12 16v5" />,
  share: (
    <>
      <circle cx="6" cy="12" r="2.5" />
      <circle cx="18" cy="6" r="2.5" />
      <circle cx="18" cy="18" r="2.5" />
      <path d="M8.2 11l7.6-4M8.2 13l7.6 4" />
    </>
  ),
  edit: <path d="M4 20h4L19 9l-4-4L4 16z" />,
  scan: <path d="M4 8V5a1 1 0 011-1h3M16 4h3a1 1 0 011 1v3M20 16v3a1 1 0 01-1 1h-3M8 20H5a1 1 0 01-1-1v-3M4 12h16" />,
  crop: <path d="M6 2v16h16M2 6h16v16" />,
  wand: <path d="M5 19L16 8l-1-1L4 18zM15 3v3M19 7h-3M5 5v2M6 6H4" />,
  flip: <path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4" />,
  search: (
    <>
      <circle cx="11" cy="11" r="6" />
      <path d="M20 20l-4-4" />
    </>
  ),
  bolt: <path d="M13 3L5 14h6l-1 7 8-11h-6z" />,
  zoomin: (
    <>
      <circle cx="11" cy="11" r="6" />
      <path d="M20 20l-4-4M11 8v6M8 11h6" />
    </>
  ),
  zoomout: (
    <>
      <circle cx="11" cy="11" r="6" />
      <path d="M20 20l-4-4M8 11h6" />
    </>
  ),
};

export function Icon({
  name,
  size = 22,
  className = "",
  strokeWidth = 1.8,
}: {
  name: keyof typeof paths | string;
  size?: number;
  className?: string;
  strokeWidth?: number;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      {paths[name]}
    </svg>
  );
}

export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-[1px] animate-fade" onClick={onClose} />
      <div className="relative w-full max-w-xl rounded-t-3xl bg-white p-5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] shadow-2xl animate-sheet max-h-[85dvh] overflow-y-auto">
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-slate-200" />
        {title && (
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
            <button onClick={onClose} className="rounded-full p-1.5 text-slate-500 active:bg-slate-100" aria-label="Close">
              <Icon name="close" size={20} />
            </button>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

export function Btn({
  children,
  onClick,
  variant = "primary",
  className = "",
  disabled,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "soft" | "ghost" | "danger";
  className?: string;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  const styles = {
    primary: "bg-indigo-600 text-white shadow-md shadow-indigo-600/25 active:bg-indigo-700",
    soft: "bg-indigo-50 text-indigo-700 active:bg-indigo-100",
    ghost: "bg-slate-100 text-slate-700 active:bg-slate-200",
    danger: "bg-rose-50 text-rose-600 active:bg-rose-100",
  }[variant];
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold transition disabled:opacity-50 ${styles} ${className}`}
    >
      {children}
    </button>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center gap-3 py-10 text-slate-500">
      <div className="h-8 w-8 animate-spin rounded-full border-[3px] border-indigo-200 border-t-indigo-600" />
      {label && <span className="text-sm">{label}</span>}
    </div>
  );
}
