"use client";

import { useEffect, useRef, useState } from "react";
import type { PageState, Source } from "@/lib/types";
import { pageDims } from "@/lib/types";
import { Btn, Icon, Sheet } from "./ui";
import { Thumb } from "./PageView";

/* ------------------------------ Signature ------------------------------ */

const SIG_KEY = "pdfstudio.signatures.v1";

function loadSigs(): string[] {
  try {
    return JSON.parse(localStorage.getItem(SIG_KEY) || "[]") as string[];
  } catch {
    return [];
  }
}

export function SignatureSheet({
  open,
  onClose,
  onUse,
}: {
  open: boolean;
  onClose: () => void;
  onUse: (dataUrl: string, w: number, h: number) => void;
}) {
  const cvs = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const bounds = useRef({ x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 });
  const [color, setColor] = useState("#111827");
  const [empty, setEmpty] = useState(true);
  const [saved, setSaved] = useState<string[]>([]);

  useEffect(() => {
    if (open) {
      setSaved(loadSigs());
      setEmpty(true);
      bounds.current = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 };
    }
  }, [open]);

  const pos = (e: React.PointerEvent) => {
    const c = cvs.current!;
    const r = c.getBoundingClientRect();
    return [((e.clientX - r.left) / r.width) * c.width, ((e.clientY - r.top) / r.height) * c.height];
  };
  const start = (e: React.PointerEvent) => {
    const c = cvs.current!;
    c.setPointerCapture(e.pointerId);
    drawing.current = true;
    const [x, y] = pos(e);
    const ctx = c.getContext("2d")!;
    ctx.strokeStyle = color;
    ctx.lineWidth = 5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + 0.1, y);
    ctx.stroke();
    setEmpty(false);
    upd(x, y);
  };
  const upd = (x: number, y: number) => {
    const b = bounds.current;
    b.x0 = Math.min(b.x0, x);
    b.y0 = Math.min(b.y0, y);
    b.x1 = Math.max(b.x1, x);
    b.y1 = Math.max(b.y1, y);
  };
  const mv = (e: React.PointerEvent) => {
    if (!drawing.current) return;
    const [x, y] = pos(e);
    const ctx = cvs.current!.getContext("2d")!;
    ctx.lineTo(x, y);
    ctx.stroke();
    upd(x, y);
  };
  const clear = () => {
    const c = cvs.current!;
    c.getContext("2d")!.clearRect(0, 0, c.width, c.height);
    setEmpty(true);
    bounds.current = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 };
  };
  const use = () => {
    const c = cvs.current!;
    const b = bounds.current;
    const pad = 8;
    const x = Math.max(0, b.x0 - pad);
    const y = Math.max(0, b.y0 - pad);
    const w = Math.min(c.width - x, b.x1 - b.x0 + pad * 2);
    const h = Math.min(c.height - y, b.y1 - b.y0 + pad * 2);
    const out = document.createElement("canvas");
    out.width = w;
    out.height = h;
    out.getContext("2d")!.drawImage(c, x, y, w, h, 0, 0, w, h);
    const url = out.toDataURL("image/png");
    const list = [url, ...loadSigs()].slice(0, 4);
    try {
      localStorage.setItem(SIG_KEY, JSON.stringify(list));
    } catch {
      /* ignore */
    }
    onUse(url, w, h);
  };

  return (
    <Sheet open={open} onClose={onClose} title="Your signature">
      <div className="relative overflow-hidden rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50">
        <canvas
          ref={cvs}
          width={900}
          height={380}
          className="block w-full"
          style={{ touchAction: "none", aspectRatio: "900/380" }}
          onPointerDown={start}
          onPointerMove={mv}
          onPointerUp={() => (drawing.current = false)}
          onPointerCancel={() => (drawing.current = false)}
        />
        {empty && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center text-sm text-slate-400">
            Sign here with your finger
          </div>
        )}
      </div>
      <div className="mt-3 flex items-center gap-2">
        {["#111827", "#1d4ed8"].map((c) => (
          <button
            key={c}
            onClick={() => setColor(c)}
            className={`h-8 w-8 rounded-full border-2 ${color === c ? "border-indigo-500" : "border-white shadow"}`}
            style={{ background: c }}
            aria-label="Ink colour"
          />
        ))}
        <button onClick={clear} className="ml-auto rounded-xl px-3 py-2 text-sm font-medium text-slate-500 active:bg-slate-100">
          Clear
        </button>
        <Btn onClick={use} disabled={empty}>
          <Icon name="check" size={18} /> Use
        </Btn>
      </div>
      {saved.length > 0 && (
        <div className="mt-4">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Saved signatures</p>
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {saved.map((s, i) => (
              <button
                key={i}
                onClick={() => {
                  const img = new Image();
                  img.onload = () => onUse(s, img.naturalWidth, img.naturalHeight);
                  img.src = s;
                }}
                className="h-16 w-28 shrink-0 rounded-xl border border-slate-200 bg-white p-1 active:bg-slate-50"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={s} alt="Saved signature" className="h-full w-full object-contain" />
              </button>
            ))}
          </div>
        </div>
      )}
    </Sheet>
  );
}

/* ------------------------------ Stamps ------------------------------ */

export type StampChoice =
  | { kind: "text"; text: string; color: string }
  | { kind: "ink"; shape: "check" | "cross"; color: string };

const textStamps: { text: string; color: string }[] = [
  { text: "APPROVED", color: "#16a34a" },
  { text: "PAID", color: "#16a34a" },
  { text: "DRAFT", color: "#d97706" },
  { text: "CONFIDENTIAL", color: "#dc2626" },
  { text: "REJECTED", color: "#dc2626" },
  { text: "COPY", color: "#2563eb" },
];

export function StampSheet({
  open,
  onClose,
  onPick,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (s: StampChoice) => void;
}) {
  const today = new Date().toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" });
  return (
    <Sheet open={open} onClose={onClose} title="Stamps">
      <div className="grid grid-cols-2 gap-2.5">
        {textStamps.map((s) => (
          <button
            key={s.text}
            onClick={() => onPick({ kind: "text", ...s })}
            className="rounded-2xl border-2 px-3 py-3.5 text-center text-sm font-extrabold tracking-wider active:scale-95"
            style={{ color: s.color, borderColor: s.color + "55", background: s.color + "0f" }}
          >
            {s.text}
          </button>
        ))}
        <button
          onClick={() => onPick({ kind: "text", text: today, color: "#111827" })}
          className="col-span-2 rounded-2xl border-2 border-slate-200 bg-slate-50 px-3 py-3.5 text-sm font-semibold text-slate-700 active:scale-95"
        >
          Today’s date · {today}
        </button>
        <button
          onClick={() => onPick({ kind: "ink", shape: "check", color: "#16a34a" })}
          className="grid place-items-center rounded-2xl border-2 border-emerald-200 bg-emerald-50 py-3 text-emerald-600 active:scale-95"
        >
          <Icon name="check" size={28} strokeWidth={2.6} />
        </button>
        <button
          onClick={() => onPick({ kind: "ink", shape: "cross", color: "#dc2626" })}
          className="grid place-items-center rounded-2xl border-2 border-rose-200 bg-rose-50 py-3 text-rose-600 active:scale-95"
        >
          <Icon name="close" size={28} strokeWidth={2.6} />
        </button>
      </div>
    </Sheet>
  );
}

/* ------------------------------ Pages ------------------------------ */

export function PagesSheet({
  open,
  onClose,
  pages,
  sources,
  onRotate,
  onMove,
  onDelete,
  onAddBlank,
  onAddPdf,
  onGoto,
}: {
  open: boolean;
  onClose: () => void;
  pages: PageState[];
  sources: Source[];
  onRotate: (i: number) => void;
  onMove: (i: number, dir: -1 | 1) => void;
  onDelete: (i: number) => void;
  onAddBlank: () => void;
  onAddPdf: () => void;
  onGoto: (i: number) => void;
}) {
  return (
    <Sheet open={open} onClose={onClose} title={`Pages (${pages.length})`}>
      <div className="space-y-2">
        {pages.map((p, i) => {
          const [w, h] = pageDims(p);
          return (
            <div key={p.id} className="flex items-center gap-3 rounded-2xl bg-slate-50 p-2.5">
              <button onClick={() => (onGoto(i), onClose())} className="shrink-0">
                <Thumb source={p.src ? sources[p.src.doc] : null} index={p.src?.index ?? 0} rot={p.rot} w={w} h={h} />
              </button>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-slate-800">Page {i + 1}</p>
                <p className="truncate text-xs text-slate-400">
                  {p.src ? sources[p.src.doc]?.name : "Blank page"}
                </p>
              </div>
              <div className="flex shrink-0 items-center">
                {[
                  { icon: "rotate", fn: () => onRotate(i), dis: false, label: "Rotate" },
                  { icon: "up", fn: () => onMove(i, -1), dis: i === 0, label: "Move up" },
                  { icon: "down", fn: () => onMove(i, 1), dis: i === pages.length - 1, label: "Move down" },
                  { icon: "trash", fn: () => onDelete(i), dis: pages.length === 1, label: "Delete" },
                ].map((b) => (
                  <button
                    key={b.icon}
                    onClick={b.fn}
                    disabled={b.dis}
                    aria-label={b.label}
                    className={`rounded-xl p-2 active:bg-slate-200 disabled:opacity-25 ${b.icon === "trash" ? "text-rose-500" : "text-slate-600"}`}
                  >
                    <Icon name={b.icon} size={19} />
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2.5">
        <Btn variant="soft" onClick={onAddBlank}>
          <Icon name="plus" size={18} /> Blank page
        </Btn>
        <Btn variant="soft" onClick={onAddPdf}>
          <Icon name="merge" size={18} /> Merge PDF
        </Btn>
      </div>
    </Sheet>
  );
}

/* ------------------------------ Export ------------------------------ */

export function ExportSheet({
  open,
  onClose,
  initialName,
  busy,
  onSave,
}: {
  open: boolean;
  onClose: () => void;
  initialName: string;
  busy: boolean;
  onSave: (name: string) => void;
}) {
  const [name, setName] = useState(initialName);
  useEffect(() => {
    if (open) setName(initialName);
  }, [open, initialName]);
  return (
    <Sheet open={open} onClose={busy ? () => {} : onClose} title="Save PDF">
      <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-400">File name</label>
      <div className="flex items-center rounded-2xl border border-slate-200 bg-slate-50 px-4 focus-within:border-indigo-400 focus-within:ring-4 focus-within:ring-indigo-100">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full bg-transparent py-3.5 text-base outline-none"
          placeholder="document"
          autoCapitalize="off"
        />
        <span className="text-sm text-slate-400">.pdf</span>
      </div>
      <p className="mt-2 text-xs text-slate-400">
        The edit is added to your History so you can see what changed and download it again later.
      </p>
      <Btn className="mt-4 w-full" onClick={() => onSave(name.trim() || "document")} disabled={busy}>
        <Icon name="download" size={18} /> {busy ? "Preparing…" : "Download PDF"}
      </Btn>
    </Sheet>
  );
}
