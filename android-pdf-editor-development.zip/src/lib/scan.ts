export type ScanFilter = "original" | "enhance" | "gray" | "bw";

export type ScanPage = {
  id: string;
  url: string; // object URL of the (downscaled) original
  w: number;
  h: number;
  rot: number;
  crop: { x: number; y: number; w: number; h: number }; // fractions of the rotated image
  filter: ScanFilter;
};

const MAX_SIDE = 2200;

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not read image"));
    img.src = src;
  });
}

/** Downscale a picked/captured image and return an object URL. */
export async function prepareImage(blob: Blob): Promise<{ url: string; w: number; h: number }> {
  const tmp = URL.createObjectURL(blob);
  try {
    const img = await loadImage(tmp);
    const k = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.round(img.naturalWidth * k);
    const h = Math.round(img.naturalHeight * k);
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    c.getContext("2d")!.drawImage(img, 0, 0, w, h);
    const out: Blob = await new Promise((res, rej) =>
      c.toBlob((b) => (b ? res(b) : rej(new Error("encode failed"))), "image/jpeg", 0.92),
    );
    return { url: URL.createObjectURL(out), w, h };
  } finally {
    URL.revokeObjectURL(tmp);
  }
}

/** Rotated (not cropped, no filter) canvas of the page. */
export async function rotatedCanvas(p: ScanPage, maxSide = MAX_SIDE): Promise<HTMLCanvasElement> {
  const img = await loadImage(p.url);
  const swap = p.rot % 180 !== 0;
  const k = Math.min(1, maxSide / Math.max(p.w, p.h));
  const w = Math.round(p.w * k);
  const h = Math.round(p.h * k);
  const c = document.createElement("canvas");
  c.width = swap ? h : w;
  c.height = swap ? w : h;
  const ctx = c.getContext("2d")!;
  ctx.translate(c.width / 2, c.height / 2);
  ctx.rotate((p.rot * Math.PI) / 180);
  ctx.drawImage(img, -w / 2, -h / 2, w, h);
  return c;
}

function applyFilter(c: HTMLCanvasElement, f: ScanFilter) {
  if (f === "original") return;
  const ctx = c.getContext("2d")!;
  const d = ctx.getImageData(0, 0, c.width, c.height);
  const px = d.data;
  if (f === "enhance") {
    for (let i = 0; i < px.length; i += 4) {
      for (let j = 0; j < 3; j++) {
        px[i + j] = Math.max(0, Math.min(255, (px[i + j] - 128) * 1.25 + 128 + 14));
      }
    }
  } else {
    const bw = f === "bw";
    for (let i = 0; i < px.length; i += 4) {
      const g = px[i] * 0.299 + px[i + 1] * 0.587 + px[i + 2] * 0.114;
      const v = bw ? (g - 128) * 2.4 + 128 + 40 : (g - 128) * 1.2 + 128 + 10;
      const o = Math.max(0, Math.min(255, v));
      px[i] = px[i + 1] = px[i + 2] = o;
    }
  }
  ctx.putImageData(d, 0, 0);
}

/** Final processed canvas: rotate -> crop -> filter. */
export async function processPage(p: ScanPage, maxSide = MAX_SIDE): Promise<HTMLCanvasElement> {
  const src = await rotatedCanvas(p, maxSide);
  const sx = Math.round(p.crop.x * src.width);
  const sy = Math.round(p.crop.y * src.height);
  const sw = Math.max(8, Math.round(p.crop.w * src.width));
  const sh = Math.max(8, Math.round(p.crop.h * src.height));
  const out = document.createElement("canvas");
  out.width = sw;
  out.height = sh;
  const ctx = out.getContext("2d")!;
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, sw, sh);
  ctx.drawImage(src, sx, sy, sw, sh, 0, 0, sw, sh);
  applyFilter(out, p.filter);
  return out;
}

export async function thumbUrl(p: ScanPage): Promise<string> {
  const c = await processPage(p, 360);
  return c.toDataURL("image/jpeg", 0.7);
}

export type PageFit = "a4" | "fit";

export async function scansToPdf(pages: ScanPage[], fit: PageFit): Promise<Uint8Array> {
  const { PDFDocument } = await import("pdf-lib");
  const doc = await PDFDocument.create();
  for (const p of pages) {
    const c = await processPage(p);
    const blob: Blob = await new Promise((res, rej) =>
      c.toBlob((b) => (b ? res(b) : rej(new Error("encode failed"))), "image/jpeg", 0.85),
    );
    const img = await doc.embedJpg(new Uint8Array(await blob.arrayBuffer()));
    if (fit === "fit") {
      const k = 595 / c.width;
      const page = doc.addPage([595, c.height * k]);
      page.drawImage(img, { x: 0, y: 0, width: 595, height: c.height * k });
    } else {
      const landscape = c.width > c.height;
      const [pw, ph] = landscape ? [842, 595] : [595, 842];
      const m = 18;
      const k = Math.min((pw - m * 2) / c.width, (ph - m * 2) / c.height);
      const w = c.width * k;
      const h = c.height * k;
      const page = doc.addPage([pw, ph]);
      page.drawImage(img, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h });
    }
  }
  doc.setProducer("PDF Studio");
  return doc.save();
}
