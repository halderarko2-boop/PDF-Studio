import * as pdfjs from "pdfjs-dist";
// @ts-ignore – raw worker source, turned into a blob so it also works inside a single-file build
import workerCode from "pdfjs-dist/build/pdf.worker.min.js?raw";
import { PDFDocument, PDFFont, LineCapStyle, rgb } from "pdf-lib";
import { Capacitor } from "@capacitor/core";
import { Filesystem, Directory } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import { LINE_H, sanitize, stdName, wrapText, widthOf } from "./fonts";
import { loadImgEl } from "./images";
import { DocSource, El, ImageEl, Page, Session, uid } from "./types";

pdfjs.GlobalWorkerOptions.workerSrc = URL.createObjectURL(new Blob([workerCode as string], { type: "text/javascript" }));

export const A4 = { w: 595, h: 842 };

export const blankPage = (w = A4.w, h = A4.h): Page => ({ id: uid(), srcIndex: null, width: w, height: h, bg: "#ffffff", elements: [] });

export async function openPdfFile(file: File): Promise<Session> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const pdf = await pdfjs.getDocument({ data: bytes.slice() }).promise;
  const pages: Page[] = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const vp = (await pdf.getPage(i)).getViewport({ scale: 1 });
    pages.push({ id: uid(), srcIndex: i - 1, width: vp.width, height: vp.height, bg: "#ffffff", elements: [] });
  }
  const source: DocSource = { bytes, pdf };
  return { id: uid(), name: file.name.replace(/\.pdf$/i, ""), kind: "pdf", pages, source };
}

export async function openPdfBytes(bytes: Uint8Array, name: string): Promise<Session> {
  return openPdfFile(new File([bytes as BlobPart], name + ".pdf", { type: "application/pdf" }));
}

/* ---------------- export ---------------- */
const hex = (c: string | null | undefined) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(c || "") || /^#?([0-9a-f]{3})$/i.exec(c || "");
  let h = m ? m[1] : "000000";
  if (h.length === 3) h = h.split("").map((x) => x + x).join("");
  return rgb(parseInt(h.slice(0, 2), 16) / 255, parseInt(h.slice(2, 4), 16) / 255, parseInt(h.slice(4, 6), 16) / 255);
};

async function imageBytes(el: ImageEl): Promise<{ bytes: Uint8Array; png: boolean } | null> {
  if (!el.src) return null;
  const img = await loadImgEl(el.src);
  const isPng = el.src.startsWith("data:image/png");
  const nativeRatio = img.naturalHeight / img.naturalWidth;
  if (el.shape === "rect" && Math.abs(nativeRatio - el.h / el.w) < 0.01) {
    const b64 = el.src.split(",")[1];
    const bin = atob(b64);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return { bytes: u, png: isPng };
  }
  const k = Math.max(1, Math.min(3, img.naturalWidth / el.w));
  const cw = Math.max(2, Math.round(el.w * k)), ch = Math.max(2, Math.round(el.h * k));
  const c = document.createElement("canvas");
  c.width = cw;
  c.height = ch;
  const ctx = c.getContext("2d")!;
  const png = isPng || el.shape === "circle";
  if (!png) {
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, cw, ch);
  }
  if (el.shape === "circle") {
    ctx.beginPath();
    ctx.ellipse(cw / 2, ch / 2, cw / 2, ch / 2, 0, 0, Math.PI * 2);
    ctx.clip();
  }
  const s = Math.max(cw / img.naturalWidth, ch / img.naturalHeight);
  const dw = img.naturalWidth * s, dh = img.naturalHeight * s;
  ctx.drawImage(img, (cw - dw) / 2, (ch - dh) / 2, dw, dh);
  const url = png ? c.toDataURL("image/png") : c.toDataURL("image/jpeg", 0.92);
  const bin = atob(url.split(",")[1]);
  const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return { bytes: u, png };
}

export async function exportPdf(name: string, pages: Page[], source: DocSource | null): Promise<Uint8Array> {
  const out = await PDFDocument.create();
  const src = source ? await PDFDocument.load(source.bytes, { ignoreEncryption: true }) : null;
  const fonts = new Map<string, PDFFont>();
  const font = async (f: El & { type: "text" }) => {
    const n = stdName(f.font, f.bold, f.italic);
    if (!fonts.has(n)) fonts.set(n, await out.embedFont(n));
    return fonts.get(n)!;
  };
  for (const pg of pages) {
    let p;
    if (pg.srcIndex !== null && src) {
      const [cp] = await out.copyPages(src, [pg.srcIndex]);
      p = out.addPage(cp);
    } else {
      p = out.addPage([pg.width, pg.height]);
      if (pg.bg && pg.bg.toLowerCase() !== "#ffffff") p.drawRectangle({ x: 0, y: 0, width: pg.width, height: pg.height, color: hex(pg.bg) });
    }
    const H = p.getHeight();
    for (const el of pg.elements) {
      const y = H - el.y - el.h;
      if (el.type === "rect") {
        p.drawRectangle({
          x: el.x, y, width: el.w, height: el.h,
          color: el.fill ? hex(el.fill) : undefined,
          opacity: el.opacity,
          borderColor: el.stroke ? hex(el.stroke) : undefined,
          borderWidth: el.stroke ? el.strokeW : 0,
          borderOpacity: el.opacity,
        });
      } else if (el.type === "ellipse") {
        p.drawEllipse({
          x: el.x + el.w / 2, y: y + el.h / 2, xScale: el.w / 2, yScale: el.h / 2,
          color: el.fill ? hex(el.fill) : undefined,
          opacity: el.opacity,
          borderColor: el.stroke ? hex(el.stroke) : undefined,
          borderWidth: el.stroke ? el.strokeW : 0,
          borderOpacity: el.opacity,
        });
      } else if (el.type === "text") {
        const f = await font(el);
        const lines = wrapText(el.text, el.size, el.font, el.bold, el.italic, el.w);
        lines.forEach((ln, i) => {
          if (!ln.trim()) return;
          const lw = f.widthOfTextAtSize(sanitize(ln), el.size);
          const x = el.align === "center" ? el.x + (el.w - lw) / 2 : el.align === "right" ? el.x + el.w - lw : el.x;
          p.drawText(sanitize(ln), { x, y: H - el.y - el.size * 0.95 - i * el.size * LINE_H, size: el.size, font: f, color: hex(el.color), opacity: el.opacity ?? 1 });
        });
      } else if (el.type === "image") {
        const ib = await imageBytes(el);
        if (!ib) continue;
        const emb = ib.png ? await out.embedPng(ib.bytes) : await out.embedJpg(ib.bytes);
        p.drawImage(emb, { x: el.x, y, width: el.w, height: el.h, opacity: el.opacity });
      } else if (el.type === "draw") {
        const pts = el.points.map(([a, b]) => [el.x + a * el.w, H - (el.y + b * el.h)] as const);
        for (let i = 1; i < pts.length; i++)
          p.drawLine({ start: { x: pts[i - 1][0], y: pts[i - 1][1] }, end: { x: pts[i][0], y: pts[i][1] }, thickness: el.width, color: hex(el.color), opacity: el.opacity, lineCap: LineCapStyle.Round });
        if (pts.length === 1) p.drawCircle({ x: pts[0][0], y: pts[0][1], size: el.width / 2, color: hex(el.color), opacity: el.opacity });
      }
    }
  }
  out.setTitle(name);
  out.setProducer("Folio PDF Editor");
  out.setCreator("Folio PDF Editor");
  return out.save();
}

/* ---------------- saving / sharing ---------------- */
export const isNative = () => Capacitor.isNativePlatform();

function toBase64(bytes: Uint8Array) {
  let s = "";
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode(...bytes.subarray(i, i + CH));
  return btoa(s);
}

export const safeName = (n: string) => (n.trim().replace(/[\\/:*?"<>|]+/g, "-").replace(/\.pdf$/i, "") || "document") + ".pdf";

function browserDownload(bytes: Uint8Array, filename: string, mime: string) {
  const url = URL.createObjectURL(new Blob([bytes as BlobPart], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

export async function shareBytes(bytes: Uint8Array, filename: string, mime = "application/pdf") {
  if (isNative()) {
    const r = await Filesystem.writeFile({ path: filename, data: toBase64(bytes), directory: Directory.Cache });
    await Share.share({ title: filename, url: r.uri, dialogTitle: "Save or share" });
    return;
  }
  const file = new File([bytes as BlobPart], filename, { type: mime });
  const nav = navigator as Navigator & { canShare?: (d: any) => boolean };
  if (nav.canShare?.({ files: [file] })) await nav.share({ files: [file], title: filename });
  else browserDownload(bytes, filename, mime);
}

/** Saves a file: Documents/Folio on the phone, a normal download in the browser */
export async function saveBytes(bytes: Uint8Array, filename: string, mime = "application/pdf"): Promise<string> {
  if (isNative()) {
    try {
      try {
        await Filesystem.requestPermissions();
      } catch {
        /* newer Android versions don't need it */
      }
      await Filesystem.writeFile({ path: `Folio/${filename}`, data: toBase64(bytes), directory: Directory.Documents, recursive: true });
      return "Documents/Folio/" + filename;
    } catch {
      await shareBytes(bytes, filename, mime);
      return "your chosen location";
    }
  }
  browserDownload(bytes, filename, mime);
  return "your Downloads folder";
}

export { widthOf };
