import type { LoadedImage } from "./types";

/** The 25 picture formats Folio can read */
export const IMAGE_FORMATS = [
  "JPG", "JPEG", "JPE", "JIF", "JFIF", "JFI", "PJPEG", "PJP", "PNG", "APNG", "GIF", "WEBP", "AVIF",
  "AVIFS", "BMP", "DIB", "ICO", "CUR", "SVG", "SVGZ", "TIF", "TIFF", "HEIC", "HEIF", "HIF",
];
export const IMAGE_ACCEPT = "image/*," + IMAGE_FORMATS.map((f) => "." + f.toLowerCase()).join(",");

export function loadImgEl(src: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => res(img);
    img.onerror = () => rej(new Error("Could not decode image"));
    img.src = src;
  });
}

const blobUrl = <T extends Blob>(b: T) => URL.createObjectURL(b);

export async function loadImageFile(file: File | Blob, maxDim = 2000): Promise<LoadedImage> {
  const name = (file as File).name || "image";
  const ext = name.split(".").pop()?.toLowerCase() || "";
  const type = file.type || "";
  let blob: Blob = file;
  let canvasSrc: HTMLCanvasElement | HTMLImageElement | null = null;
  let isSvg = false;

  if (["heic", "heif", "hif"].includes(ext) || /hei[cf]/.test(type)) {
    const { default: heic2any } = await import("heic2any");
    const r = await heic2any({ blob: file, toType: "image/jpeg", quality: 0.92 });
    blob = Array.isArray(r) ? r[0] : r;
  } else if (ext === "svgz") {
    const buf = await new Response((file as File).stream().pipeThrough(new DecompressionStream("gzip"))).arrayBuffer();
    blob = new Blob([buf], { type: "image/svg+xml" });
    isSvg = true;
  } else if (ext === "svg" || type === "image/svg+xml") {
    blob = new Blob([await file.arrayBuffer()], { type: "image/svg+xml" });
    isSvg = true;
  } else if (ext === "avifs") {
    blob = new Blob([file], { type: "image/avif" });
  } else if (ext === "tif" || ext === "tiff" || type === "image/tiff") {
    const m: any = await import("utif");
    const UTIF = m.default ?? m;
    const buf = await file.arrayBuffer();
    const ifds = UTIF.decode(buf);
    UTIF.decodeImage(buf, ifds[0]);
    const rgba = UTIF.toRGBA8(ifds[0]);
    const c = document.createElement("canvas");
    c.width = ifds[0].width;
    c.height = ifds[0].height;
    c.getContext("2d")!.putImageData(new ImageData(new Uint8ClampedArray(rgba), c.width, c.height), 0, 0);
    canvasSrc = c;
  }

  let nw: number, nh: number;
  let drawable: CanvasImageSource;
  if (canvasSrc) {
    drawable = canvasSrc;
    nw = (canvasSrc as HTMLCanvasElement).width;
    nh = (canvasSrc as HTMLCanvasElement).height;
  } else {
    const url = blobUrl(blob);
    try {
      const img = await loadImgEl(url);
      drawable = img;
      nw = img.naturalWidth || 1000;
      nh = img.naturalHeight || 1000;
    } finally {
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    }
  }
  let scale = Math.min(1, maxDim / Math.max(nw, nh));
  if (isSvg) scale = 1200 / Math.max(nw, nh);
  const w = Math.max(1, Math.round(nw * scale));
  const h = Math.max(1, Math.round(nh * scale));
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d", { willReadFrequently: true })!;
  ctx.drawImage(drawable, 0, 0, w, h);
  let alpha = false;
  const d = ctx.getImageData(0, 0, w, h).data;
  for (let i = 3; i < d.length; i += 16) if (d[i] < 250) { alpha = true; break; }
  const src = alpha ? c.toDataURL("image/png") : c.toDataURL("image/jpeg", 0.9);
  return { src, w, h, name: name.replace(/\.[^.]+$/, "") };
}

export async function loadImageFiles(files: FileList | File[], maxDim = 2000) {
  const out: LoadedImage[] = [];
  const failed: string[] = [];
  for (const f of Array.from(files)) {
    try {
      out.push(await loadImageFile(f, maxDim));
    } catch {
      failed.push(f.name);
    }
  }
  return { out, failed };
}

/* ---------------- scanner processing ---------------- */
export type Filter = "original" | "enhanced" | "gray" | "bw";
export interface Crop { x: number; y: number; w: number; h: number }

function applyFilter(ctx: CanvasRenderingContext2D, w: number, h: number, f: Filter) {
  if (f === "original") return;
  const img = ctx.getImageData(0, 0, w, h);
  const a = img.data;
  if (f === "enhanced") {
    for (let i = 0; i < a.length; i += 4) {
      for (let k = 0; k < 3; k++) a[i + k] = Math.max(0, Math.min(255, (a[i + k] - 128) * 1.3 + 128 + 12));
    }
  } else if (f === "gray") {
    for (let i = 0; i < a.length; i += 4) {
      const l = a[i] * 0.299 + a[i + 1] * 0.587 + a[i + 2] * 0.114;
      const v = Math.max(0, Math.min(255, (l - 128) * 1.2 + 128 + 8));
      a[i] = a[i + 1] = a[i + 2] = v;
    }
  } else {
    // adaptive threshold using an integral image
    const g = new Float32Array(w * h);
    for (let i = 0, p = 0; i < a.length; i += 4, p++) g[p] = a[i] * 0.299 + a[i + 1] * 0.587 + a[i + 2] * 0.114;
    const W = w + 1;
    const integ = new Float64Array(W * (h + 1));
    for (let y = 1; y <= h; y++) {
      let row = 0;
      for (let x = 1; x <= w; x++) {
        row += g[(y - 1) * w + (x - 1)];
        integ[y * W + x] = integ[(y - 1) * W + x] + row;
      }
    }
    const r = Math.max(8, Math.round(Math.min(w, h) / 24));
    for (let y = 0; y < h; y++) {
      const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
      for (let x = 0; x < w; x++) {
        const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
        const sum = integ[y1 * W + x1] - integ[y0 * W + x1] - integ[y1 * W + x0] + integ[y0 * W + x0];
        const mean = sum / ((x1 - x0) * (y1 - y0));
        const v = g[y * w + x] < mean * 0.88 ? 0 : 255;
        const i = (y * w + x) * 4;
        a[i] = a[i + 1] = a[i + 2] = v;
      }
    }
  }
  ctx.putImageData(img, 0, 0);
}

export async function processScan(src: string, o: { rot: number; crop: Crop | null; filter: Filter; maxDim?: number }) {
  const img = await loadImgEl(src);
  const r = ((o.rot % 360) + 360) % 360;
  const swap = r % 180 !== 0;
  let sw = swap ? img.naturalHeight : img.naturalWidth;
  let sh = swap ? img.naturalWidth : img.naturalHeight;
  const k = Math.min(1, (o.maxDim ?? 2200) / Math.max(sw, sh));
  sw = Math.round(sw * k);
  sh = Math.round(sh * k);
  const c1 = document.createElement("canvas");
  c1.width = sw;
  c1.height = sh;
  const x1 = c1.getContext("2d")!;
  x1.fillStyle = "#fff";
  x1.fillRect(0, 0, sw, sh);
  x1.translate(sw / 2, sh / 2);
  x1.rotate((r * Math.PI) / 180);
  const dw = (swap ? sh : sw), dh = (swap ? sw : sh);
  x1.drawImage(img, -dw / 2, -dh / 2, dw, dh);
  let out = c1;
  if (o.crop) {
    const cx = Math.round(o.crop.x * sw), cy = Math.round(o.crop.y * sh);
    const cw = Math.max(10, Math.round(o.crop.w * sw)), ch = Math.max(10, Math.round(o.crop.h * sh));
    const c2 = document.createElement("canvas");
    c2.width = cw;
    c2.height = ch;
    c2.getContext("2d")!.drawImage(c1, cx, cy, cw, ch, 0, 0, cw, ch);
    out = c2;
  }
  const ctx = out.getContext("2d", { willReadFrequently: true })!;
  applyFilter(ctx, out.width, out.height, o.filter);
  return { src: out.toDataURL("image/jpeg", 0.88), w: out.width, h: out.height };
}
