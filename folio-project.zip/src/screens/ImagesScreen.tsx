import { useRef } from "react";
import { Camera, Images, Loader2, Trash2, Upload } from "lucide-react";
import { useImageImport } from "../components/ImagePicker";
import { IMAGE_ACCEPT, IMAGE_FORMATS } from "../lib/images";
import { removeFromLibrary, useLibrary } from "../lib/storage";

export default function ImagesScreen() {
  const lib = useLibrary();
  const { busy, run } = useImageImport();
  const file = useRef<HTMLInputElement>(null);
  const cam = useRef<HTMLInputElement>(null);
  return (
    <div className="px-5 pt-5 pb-32 max-w-xl mx-auto safe-top">
      <h1 className="text-2xl font-extrabold tracking-tight">My images</h1>
      <p className="text-sm text-slate-500 mt-1">Save logos, client photos and signatures once, then drop them into any template or PDF.</p>
      <input ref={file} type="file" multiple accept={IMAGE_ACCEPT} className="hidden" onChange={(e) => { run(e.target.files); e.target.value = ""; }} />
      <input ref={cam} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => { run(e.target.files); e.target.value = ""; }} />
      <div className="grid grid-cols-2 gap-3 mt-5">
        <button onClick={() => file.current?.click()} className="h-16 rounded-2xl grad text-white font-semibold flex items-center justify-center gap-2 shadow-lg shadow-indigo-200 active:scale-95">{busy ? <Loader2 className="animate-spin" size={18} /> : <Upload size={18} />} Upload</button>
        <button onClick={() => cam.current?.click()} className="h-16 rounded-2xl bg-white text-indigo-600 font-semibold flex items-center justify-center gap-2 shadow-sm active:scale-95"><Camera size={18} /> Take photo</button>
      </div>
      <p className="text-[11px] text-slate-400 mt-3 leading-relaxed">Supported formats ({IMAGE_FORMATS.length}): {IMAGE_FORMATS.join(" · ")}</p>
      <div className="mt-6">
        {lib.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center shadow-sm text-slate-400 text-sm flex flex-col items-center gap-2"><Images size={30} className="text-slate-300" />No pictures yet. Upload your first logo or photo.</div>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            {lib.map((i) => (
              <div key={i.id} className="relative aspect-square rounded-2xl overflow-hidden bg-[repeating-conic-gradient(#f1f5f9_0%_25%,#fff_0%_50%)] bg-[length:16px_16px] shadow-sm ring-1 ring-black/5">
                <img src={i.src} alt={i.name} className="w-full h-full object-contain" />
                <button onClick={() => removeFromLibrary(i.id)} className="absolute top-1.5 right-1.5 w-8 h-8 rounded-full bg-white/95 text-red-500 flex items-center justify-center shadow"><Trash2 size={14} /></button>
                <div className="absolute bottom-0 inset-x-0 bg-slate-900/60 text-white text-[10px] px-2 py-0.5 truncate">{i.name}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
