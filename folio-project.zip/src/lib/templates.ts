import { fitTextHeight } from "./fonts";
import { El, FontKey, ImageEl, Page, ShapeEl, TextEl, uid } from "./types";

/* ============ palettes & element helpers ============ */
export interface Pal { name: string; primary: string; dark: string; accent: string; soft: string; ink: string; muted: string }
const pal = (name: string, primary: string, dark: string, accent: string, soft: string): Pal => ({ name, primary, dark, accent, soft, ink: "#1f2937", muted: "#6b7280" });
const PALS = {
  ocean: pal("Ocean", "#4338ca", "#1e1b4b", "#a5b4fc", "#eef2ff"),
  ember: pal("Ember", "#ea580c", "#431407", "#fdba74", "#fff7ed"),
  forest: pal("Forest", "#15803d", "#052e16", "#86efac", "#f0fdf4"),
  plum: pal("Plum", "#9333ea", "#3b0764", "#d8b4fe", "#faf5ff"),
  slate: pal("Slate", "#334155", "#0f172a", "#cbd5e1", "#f1f5f9"),
  teal: pal("Teal", "#0f766e", "#042f2e", "#5eead4", "#f0fdfa"),
  rose: pal("Rose", "#e11d48", "#4c0519", "#fda4af", "#fff1f2"),
  gold: pal("Gold", "#b45309", "#1c1917", "#fcd34d", "#fffbeb"),
};
type PK = keyof typeof PALS;

type TO = { color?: string; bold?: boolean; italic?: boolean; align?: "left" | "center" | "right"; font?: FontKey; opacity?: number };
const tx = (x: number, y: number, w: number, text: string, size: number, o: TO = {}): TextEl => {
  const e: TextEl = { id: uid(), type: "text", x, y, w, h: 0, text, size, color: o.color ?? "#1f2937", font: o.font ?? "helv", bold: o.bold, italic: o.italic, align: o.align ?? "left", opacity: o.opacity };
  e.h = fitTextHeight(e);
  return e;
};
type SO = { stroke?: string; sw?: number; op?: number };
const rc = (x: number, y: number, w: number, h: number, fill: string | null, o: SO = {}): ShapeEl => ({ id: uid(), type: "rect", x, y, w, h, fill, stroke: o.stroke ?? null, strokeW: o.sw ?? 1, opacity: o.op ?? 1 });
const el = (x: number, y: number, w: number, h: number, fill: string | null, o: SO = {}): ShapeEl => ({ ...rc(x, y, w, h, fill, o), type: "ellipse" });
const im = (x: number, y: number, w: number, h: number, label: string, shape: "rect" | "circle" = "rect"): ImageEl => ({ id: uid(), type: "image", x, y, w, h, placeholder: label, shape, opacity: 1 });

class Flow {
  constructor(public y: number, public els: El[]) {}
  t(x: number, w: number, text: string, size: number, o: TO = {}, gap = 4) {
    const e = tx(x, this.y, w, text, size, o);
    this.els.push(e);
    this.y += e.h + gap;
    return e;
  }
  skip(n: number) { this.y += n; }
}

interface Built { els: El[]; bg?: string }
type Layout = (p: Pal, hf: FontKey) => Built;

/* ============ RESUME ============ */
const RES = {
  name: "Alex Morgan", title: "Senior Product Designer",
  contact: ["alex.morgan@email.com", "+1 (555) 014-2398", "San Francisco, CA", "linkedin.com/in/alexmorgan"],
  summary: "Creative product designer with 8+ years of experience crafting intuitive mobile and web experiences. Skilled at turning complex problems into simple, beautiful interfaces.",
  jobs: [
    ["Senior Product Designer", "Brightline Studio  |  2020 - Present", "• Led the redesign of the core app, lifting retention by 24%\n• Built and maintained a company-wide design system"],
    ["UX Designer", "Northwind Labs  |  2016 - 2020", "• Designed onboarding flows used by over 1M people\n• Ran user research and usability testing"],
    ["Junior Designer", "Paper & Pixel  |  2014 - 2016", "• Produced branding and marketing material for 30+ clients"],
  ],
  edu: ["B.A. Interaction Design", "State University  |  2010 - 2014"],
  skills: ["Figma & Prototyping", "User Research", "Design Systems", "HTML & CSS", "Brand Identity"],
  langs: ["English - Native", "Spanish - Fluent"],
};
function head(f: Flow, x: number, w: number, t: string, p: Pal, style: "bar" | "rule", color?: string) {
  f.skip(6);
  if (style === "bar") {
    f.els.push(rc(x, f.y + 1, 4, 15, p.primary));
    f.t(x + 12, w - 12, t.toUpperCase(), 12, { bold: true, color: p.ink }, 7);
  } else {
    f.t(x, w, t.toUpperCase(), 11, { bold: true, color: color ?? p.primary }, 3);
    f.els.push(rc(x, f.y, w, 1.2, p.accent));
    f.skip(8);
  }
}
function resumeMain(f: Flow, x: number, w: number, p: Pal, style: "bar" | "rule", withEdu = true) {
  head(f, x, w, "Profile", p, style);
  f.t(x, w, RES.summary, 10, { color: p.ink }, 6);
  head(f, x, w, "Experience", p, style);
  RES.jobs.forEach((j) => {
    f.t(x, w, j[0], 11.5, { bold: true, color: p.ink }, 1);
    f.t(x, w, j[1], 9, { bold: true, color: p.primary }, 3);
    f.t(x, w, j[2], 9.5, { color: p.muted }, 10);
  });
  if (withEdu) {
    head(f, x, w, "Education", p, style);
    f.t(x, w, RES.edu[0], 11.5, { bold: true, color: p.ink }, 1);
    f.t(x, w, RES.edu[1], 9, { color: p.primary, bold: true }, 4);
  }
}
const R0: Layout = (p, hf) => {
  const els: El[] = [rc(0, 0, 200, 842, p.primary), im(45, 40, 110, 110, "Photo", "circle")];
  const s = new Flow(176, els);
  s.t(24, 152, "CONTACT", 10.5, { color: p.accent, bold: true }, 5);
  RES.contact.forEach((c) => s.t(24, 152, c, 9, { color: "#fff" }, 6));
  s.skip(14);
  s.t(24, 152, "SKILLS", 10.5, { color: p.accent, bold: true }, 5);
  RES.skills.forEach((c) => s.t(24, 152, "• " + c, 9.5, { color: "#fff" }, 5));
  s.skip(14);
  s.t(24, 152, "LANGUAGES", 10.5, { color: p.accent, bold: true }, 5);
  RES.langs.forEach((c) => s.t(24, 152, c, 9.5, { color: "#fff" }, 5));
  const m = new Flow(48, els);
  m.t(228, 337, RES.name, 30, { bold: true, font: hf, color: p.ink }, 2);
  m.t(228, 337, RES.title, 13, { color: p.primary, bold: true }, 8);
  resumeMain(m, 228, 337, p, "rule");
  return { els };
};
const R1: Layout = (p, hf) => {
  const els: El[] = [rc(0, 0, 595, 150, p.primary), im(459, 27, 96, 96, "Photo", "circle"), rc(405, 150, 190, 692, p.soft)];
  els.push(tx(40, 40, 400, RES.name, 34, { color: "#fff", bold: true, font: hf }), tx(40, 88, 400, RES.title, 14, { color: p.accent, bold: true }));
  const m = new Flow(170, els);
  resumeMain(m, 40, 340, p, "bar", false);
  const s = new Flow(172, els);
  head(s, 422, 156, "Contact", p, "rule");
  RES.contact.forEach((c) => s.t(422, 156, c, 9, { color: p.ink }, 6));
  head(s, 422, 156, "Skills", p, "rule");
  RES.skills.forEach((c) => s.t(422, 156, "• " + c, 9.5, { color: p.ink }, 5));
  head(s, 422, 156, "Education", p, "rule");
  s.t(422, 156, RES.edu[0], 10.5, { bold: true, color: p.ink }, 1);
  s.t(422, 156, RES.edu[1], 9, { color: p.muted }, 6);
  head(s, 422, 156, "Languages", p, "rule");
  RES.langs.forEach((c) => s.t(422, 156, c, 9.5, { color: p.ink }, 5));
  return { els };
};
const R2: Layout = (p, hf) => {
  const els: El[] = [im(262, 34, 72, 72, "Photo", "circle")];
  const f = new Flow(116, els);
  f.t(40, 515, RES.name, 30, { bold: true, font: hf, align: "center", color: p.ink }, 2);
  f.t(40, 515, RES.title.toUpperCase(), 11, { color: p.primary, align: "center", bold: true }, 5);
  f.t(40, 515, RES.contact.join("   |   "), 8.5, { color: p.muted, align: "center" }, 8);
  els.push(rc(40, f.y, 515, 2, p.primary));
  f.skip(6);
  resumeMain(f, 40, 515, p, "rule", false);
  head(f, 40, 515, "Education", p, "rule");
  f.t(40, 515, RES.edu[0] + "  -  " + RES.edu[1], 10, { color: p.ink }, 4);
  head(f, 40, 515, "Skills", p, "rule");
  f.t(40, 515, RES.skills.join("   •   "), 10, { color: p.ink }, 4);
  return { els };
};
const R3: Layout = (p, hf) => {
  const els: El[] = [rc(0, 0, 595, 12, p.primary), im(455, 38, 100, 100, "Photo"), rc(405, 160, 190, 682, p.soft)];
  const h = new Flow(40, els);
  h.t(40, 400, RES.name, 32, { bold: true, font: hf, color: p.ink }, 2);
  h.t(40, 400, RES.title, 14, { color: p.primary, bold: true }, 8);
  els.push(rc(40, h.y, 60, 4, p.primary));
  h.skip(14);
  h.t(40, 400, RES.contact.slice(0, 3).join("   |   "), 8.5, { color: p.muted }, 4);
  const m = new Flow(180, els);
  head(m, 40, 340, "Profile", p, "rule");
  m.t(40, 340, RES.summary, 10, { color: p.ink }, 6);
  head(m, 40, 340, "Experience", p, "rule");
  const at = els.length, y0 = m.y;
  RES.jobs.forEach((j) => {
    els.push(el(40, m.y + 2, 11, 11, p.primary));
    m.t(64, 316, j[0], 11.5, { bold: true, color: p.ink }, 1);
    m.t(64, 316, j[1], 9, { bold: true, color: p.primary }, 3);
    m.t(64, 316, j[2], 9.5, { color: p.muted }, 12);
  });
  els.splice(at, 0, rc(44.5, y0, 2, m.y - y0 - 14, p.accent));
  const s = new Flow(182, els);
  head(s, 422, 156, "Skills", p, "rule");
  [0.9, 0.85, 0.8, 0.7, 0.75].forEach((v, i) => {
    s.t(422, 156, RES.skills[i], 9.5, { color: p.ink }, 3);
    els.push(rc(422, s.y, 156, 5, p.accent), rc(422, s.y, 156 * v, 5, p.primary));
    s.skip(13);
  });
  head(s, 422, 156, "Education", p, "rule");
  s.t(422, 156, RES.edu[0], 10.5, { bold: true, color: p.ink }, 1);
  s.t(422, 156, RES.edu[1], 9, { color: p.muted }, 6);
  head(s, 422, 156, "Contact", p, "rule");
  s.t(422, 156, RES.contact[3], 9, { color: p.ink }, 4);
  return { els };
};

/* ============ CERTIFICATE (landscape) ============ */
const CERT = { desc: "in recognition of outstanding performance, dedication and commitment to excellence throughout the program.", name: "Jordan Ellis", org: "Brightline Academy" };
function sigs(els: El[], x1: number, x2: number, y: number, line: string, label: string, p: Pal) {
  els.push(rc(x1, y, 200, 1, line), rc(x2, y, 200, 1, line));
  els.push(tx(x1, y + 5, 200, "Authorized Signature", 9.5, { align: "center", color: label }), tx(x2, y + 5, 200, "Date", 9.5, { align: "center", color: label }));
  els.push(tx(x2, y - 20, 200, "June 12, 2026", 12, { align: "center", color: p.ink === label ? p.ink : label }));
}
const C0: Layout = (p, hf) => {
  const els: El[] = [rc(20, 20, 802, 555, null, { stroke: p.primary, sw: 4 }), rc(32, 32, 778, 531, null, { stroke: p.accent, sw: 1.5 }), im(371, 46, 100, 60, "Logo")];
  els.push(tx(60, 112, 722, "CERTIFICATE", 46, { align: "center", bold: true, font: "times", color: p.primary }));
  els.push(tx(60, 168, 722, "OF ACHIEVEMENT", 16, { align: "center", color: p.ink, bold: true }));
  els.push(tx(60, 204, 722, "This certificate is proudly presented to", 13, { align: "center", italic: true, color: p.muted, font: hf }));
  els.push(tx(60, 232, 722, CERT.name, 46, { align: "center", italic: true, bold: true, font: "times", color: p.ink }));
  els.push(rc(231, 296, 380, 1.5, p.primary));
  els.push(tx(171, 312, 500, CERT.desc, 12, { align: "center", color: p.muted }));
  sigs(els, 110, 532, 486, p.ink, p.muted, p);
  els.push(el(381, 430, 80, 80, p.primary), el(388, 437, 66, 66, null, { stroke: p.accent, sw: 1.5 }), tx(381, 466, 80, "AWARD", 11, { align: "center", bold: true, color: "#fff" }));
  return { els, bg: "#fffdf7" };
};
const C1: Layout = (p, hf) => {
  const els: El[] = [rc(0, 0, 230, 595, p.primary), im(60, 70, 110, 110, "Logo", "circle"), rc(0, 575, 842, 20, p.accent)];
  els.push(tx(20, 205, 190, CERT.org, 17, { align: "center", bold: true, color: "#fff", font: hf }), tx(20, 262, 190, "Excellence in education since 1998", 10, { align: "center", color: p.accent }));
  els.push(tx(270, 70, 520, "CERTIFICATE", 42, { bold: true, font: hf, color: p.primary }), tx(270, 122, 520, "OF COMPLETION", 15, { color: p.muted, bold: true }));
  els.push(tx(270, 190, 520, "Proudly presented to", 12, { italic: true, color: p.muted }), tx(270, 212, 520, CERT.name, 40, { bold: true, font: hf, color: p.ink }));
  els.push(rc(270, 268, 300, 2.5, p.primary), tx(270, 288, 500, CERT.desc, 12, { color: p.muted }));
  sigs(els, 270, 520, 470, p.ink, p.muted, p);
  els.push(el(716, 400, 80, 80, p.accent), tx(716, 432, 80, "BEST", 13, { align: "center", bold: true, color: p.primary }));
  return { els };
};
const C2: Layout = (p, hf) => {
  const els: El[] = [rc(60, 56, 722, 3, p.primary), rc(60, 536, 722, 3, p.primary), im(381, 78, 80, 44, "Logo")];
  els.push(tx(60, 140, 722, "Certificate of Appreciation", 36, { align: "center", font: hf, bold: true, color: p.ink }));
  els.push(tx(60, 196, 722, "THIS AWARD IS GIVEN TO", 11, { align: "center", color: p.muted, bold: true }));
  els.push(tx(60, 226, 722, CERT.name, 52, { align: "center", italic: true, font: "times", color: p.primary }));
  els.push(rc(321, 300, 200, 1, p.muted), tx(171, 316, 500, CERT.desc, 12, { align: "center", color: p.muted }));
  sigs(els, 130, 512, 470, p.muted, p.muted, p);
  return { els, bg: "#ffffff" };
};
const C3: Layout = (p, hf) => {
  const els: El[] = [rc(24, 24, 794, 547, null, { stroke: p.accent, sw: 2 }), rc(34, 34, 774, 527, null, { stroke: p.accent, sw: 0.8 }), im(371, 50, 100, 56, "Logo")];
  els.push(tx(60, 116, 722, "CERTIFICATE", 44, { align: "center", bold: true, font: hf, color: p.accent }), tx(60, 168, 722, "OF EXCELLENCE", 15, { align: "center", color: "#fff", bold: true }));
  els.push(tx(60, 206, 722, "Awarded with pride to", 13, { align: "center", italic: true, color: "#cbd5e1" }), tx(60, 234, 722, CERT.name, 46, { align: "center", italic: true, bold: true, font: "times", color: "#fff" }));
  els.push(rc(231, 298, 380, 1.5, p.accent), tx(171, 314, 500, CERT.desc, 12, { align: "center", color: "#cbd5e1" }));
  sigs(els, 110, 532, 486, p.accent, "#cbd5e1", p);
  els.push(el(381, 430, 80, 80, p.accent), el(388, 437, 66, 66, null, { stroke: p.dark, sw: 1.5 }), tx(381, 466, 80, "BEST", 12, { align: "center", bold: true, color: p.dark }));
  els.forEach((e) => { if (e.type === "text" && e.color === p.ink) e.color = "#e5e7eb"; });
  return { els, bg: p.dark };
};

/* ============ INVOICE ============ */
const INV = {
  from: ["Brightline Co.", "24 Market Street, Austin TX", "billing@brightline.co"],
  to: ["Northwind Studio", "88 Harbor Road, Seattle WA", "accounts@northwind.studio"],
  rows: [["Brand identity design", "1", "1,200.00", "1,200.00"], ["Website design (5 pages)", "1", "1,800.00", "1,800.00"], ["Social media kit", "2", "250.00", "500.00"], ["Revision rounds", "3", "90.00", "270.00"]],
};
function invTable(els: El[], x: number, y: number, w: number, p: Pal, o: { headFill: string | null; headColor: string; zebra?: string; line?: string }) {
  const cols = [0.5, 0.12, 0.18, 0.2];
  const cx = (i: number) => x + w * cols.slice(0, i).reduce((a, b) => a + b, 0);
  const heads = ["DESCRIPTION", "QTY", "RATE", "AMOUNT"];
  if (o.headFill) els.push(rc(x, y, w, 26, o.headFill));
  heads.forEach((h, i) => els.push(tx(cx(i) + (i === 0 ? 10 : 0), y + 8, w * cols[i] - (i === 0 ? 10 : 10), h, 9, { bold: true, color: o.headColor, align: i === 0 ? "left" : "right" })));
  if (o.line) els.push(rc(x, y + 26, w, 1.5, o.line));
  INV.rows.forEach((r, ri) => {
    const ry = y + 26 + ri * 30;
    if (o.zebra && ri % 2 === 0) els.push(rc(x, ry, w, 30, o.zebra));
    r.forEach((c, i) => els.push(tx(cx(i) + (i === 0 ? 10 : 0), ry + 9, w * cols[i] - 10, c, 10, { color: p.ink, align: i === 0 ? "left" : "right" })));
    if (!o.zebra) els.push(rc(x, ry + 30, w, 0.6, "#e5e7eb"));
  });
  return y + 26 + INV.rows.length * 30;
}
function invTotals(els: El[], x: number, y: number, w: number, p: Pal, boxFill: string | null, boxText: string) {
  const lx = x + w - 220;
  const line = (yy: number, a: string, b: string) => els.push(tx(lx, yy, 110, a, 10, { color: p.muted }), tx(lx + 110, yy, 110, b, 10, { color: p.ink, align: "right" }));
  line(y, "Subtotal", "$3,770.00");
  line(y + 20, "Tax (8%)", "$301.60");
  if (boxFill) els.push(rc(lx - 10, y + 46, 230, 38, boxFill));
  else els.push(rc(lx, y + 44, 220, 1.5, p.primary));
  els.push(tx(lx, y + 58, 110, "TOTAL DUE", 11, { bold: true, color: boxText }), tx(lx + 110, y + 55, 110, "$4,071.60", 15, { bold: true, color: boxText, align: "right" }));
  return y + 90;
}
function invFoot(els: El[], p: Pal, x = 40, w = 515) {
  els.push(tx(x, 690, w, "NOTES & PAYMENT TERMS", 9.5, { bold: true, color: p.primary }), tx(x, 706, w, "Payment is due within 14 days. Bank transfer: IBAN GB00 0000 0000 0000 00. Please include the invoice number as reference.", 9.5, { color: p.muted }));
  els.push(tx(x, 780, w, "Thank you for your business!", 13, { bold: true, color: p.ink, align: "center" }));
}
function invMeta(els: El[], p: Pal, x: number, y: number, label = "BILL TO") {
  const f = new Flow(y, els);
  f.t(x, 230, label, 9.5, { bold: true, color: p.primary }, 4);
  INV.to.forEach((l, i) => f.t(x, 230, l, i ? 10 : 12, { bold: !i, color: i ? p.muted : p.ink }, 3));
}
const I0: Layout = (p) => {
  const els: El[] = [rc(0, 0, 595, 120, p.primary), im(40, 28, 64, 64, "Logo"), tx(280, 30, 275, "INVOICE", 34, { bold: true, color: "#fff", align: "right" }), tx(280, 78, 275, "No. INV-2026-0042", 11, { color: p.accent, align: "right" })];
  invMeta(els, p, 40, 150);
  els.push(tx(340, 150, 215, "FROM", 9.5, { bold: true, color: p.primary }));
  INV.from.forEach((l, i) => els.push(tx(340, 166 + i * 15, 215, l, i ? 10 : 12, { bold: !i, color: i ? p.muted : p.ink })));
  els.push(tx(40, 240, 515, "Issue date: June 12, 2026        Due date: June 26, 2026", 10, { color: p.ink }));
  const y = invTable(els, 40, 280, 515, p, { headFill: p.primary, headColor: "#fff" });
  invTotals(els, 40, y + 20, 515, p, p.soft, p.primary);
  invFoot(els, p);
  return { els };
};
const I1: Layout = (p, hf) => {
  const els: El[] = [tx(40, 40, 300, "Invoice", 40, { font: hf, color: p.ink }), tx(40, 92, 300, "INV-2026-0042  |  June 12, 2026", 10, { color: p.muted }), im(455, 36, 100, 56, "Logo"), rc(40, 128, 515, 1.5, p.primary)];
  invMeta(els, p, 40, 150, "BILLED TO");
  els.push(tx(340, 150, 215, "FROM", 9.5, { bold: true, color: p.primary }));
  INV.from.forEach((l, i) => els.push(tx(340, 166 + i * 15, 215, l, 10, { bold: !i, color: i ? p.muted : p.ink })));
  const y = invTable(els, 40, 270, 515, p, { headFill: null, headColor: p.primary, line: p.primary });
  invTotals(els, 40, y + 20, 515, p, null, p.primary);
  invFoot(els, p);
  return { els };
};
const I2: Layout = (p) => {
  const els: El[] = [rc(0, 0, 16, 842, p.primary), im(50, 36, 70, 70, "Logo"), tx(130, 44, 250, INV.from[0], 18, { bold: true, color: p.ink }), tx(130, 68, 250, INV.from[1] + "\n" + INV.from[2], 9.5, { color: p.muted })];
  els.push(rc(380, 36, 175, 70, p.soft), tx(390, 46, 155, "INVOICE", 22, { bold: true, color: p.primary, align: "right" }), tx(390, 76, 155, "INV-2026-0042", 10, { color: p.ink, align: "right" }), tx(390, 90, 155, "Due: June 26, 2026", 9, { color: p.muted, align: "right" }));
  invMeta(els, p, 50, 150);
  const y = invTable(els, 50, 250, 505, p, { headFill: p.dark, headColor: "#fff", zebra: p.soft });
  invTotals(els, 50, y + 20, 505, p, p.dark, "#fff");
  invFoot(els, p, 50, 505);
  return { els };
};
const I3: Layout = (p, hf) => {
  const els: El[] = [rc(0, 0, 595, 220, p.dark), tx(40, 40, 400, "INVOICE", 50, { bold: true, color: "#fff", font: hf }), tx(40, 100, 400, "No. INV-2026-0042   |   June 12, 2026", 11, { color: p.accent }), im(475, 34, 80, 80, "Logo", "circle")];
  els.push(tx(40, 150, 300, INV.from.join("\n"), 10, { color: "#e5e7eb" }), rc(0, 220, 595, 6, p.primary));
  invMeta(els, p, 40, 256);
  els.push(tx(340, 256, 215, "DUE DATE", 9.5, { bold: true, color: p.primary }), tx(340, 272, 215, "June 26, 2026", 12, { bold: true, color: p.ink }));
  const y = invTable(els, 40, 350, 515, p, { headFill: p.primary, headColor: "#fff", zebra: p.soft });
  invTotals(els, 40, y + 16, 515, p, p.primary, "#fff");
  invFoot(els, p);
  return { els };
};

/* ============ LETTER ============ */
const LET = {
  name: "Alex Morgan", contact: "12 Orchard Lane, Portland, OR  |  alex.morgan@email.com  |  +1 (555) 014-2398",
  paras: [
    "I am writing to express my interest in the Senior Designer position at Horizon Media. With more than eight years of experience in product and brand design, I am confident I can help your team deliver outstanding work.",
    "In my current role at Brightline Studio I lead a team of five designers, and our latest redesign increased customer retention by 24%. I enjoy collaborating with engineers and marketers to turn ideas into polished products.",
    "Thank you for taking the time to consider my application. I would welcome the chance to discuss how my skills can support Horizon Media, and I look forward to hearing from you.",
  ],
};
function letterBody(els: El[], x: number, y: number, w: number, p: Pal, bf: FontKey = "helv") {
  const f = new Flow(y, els);
  const o: TO = { color: p.ink, font: bf };
  f.t(x, w, "June 12, 2026", 10.5, o, 16);
  f.t(x, w, "Ms. Sarah Carter\nHiring Manager, Horizon Media\n450 Main Street, Chicago, IL", 10.5, o, 16);
  f.t(x, w, "Re: Application for Senior Designer", 10.5, { ...o, bold: true }, 14);
  f.t(x, w, "Dear Ms. Carter,", 10.5, o, 10);
  LET.paras.forEach((t) => f.t(x, w, t, 10.5, o, 10));
  f.t(x, w, "Sincerely,", 10.5, o, 34);
  f.t(x, w, LET.name, 12, { ...o, bold: true }, 2);
  f.t(x, w, "Senior Product Designer", 9.5, { color: p.muted, font: bf });
}
const L0: Layout = (p, hf) => {
  const els: El[] = [im(40, 36, 58, 58, "Logo"), tx(112, 42, 440, LET.name, 22, { bold: true, font: hf, color: p.ink }), tx(112, 72, 443, LET.contact, 8.5, { color: p.muted }), rc(40, 108, 515, 2.5, p.primary)];
  letterBody(els, 40, 140, 515, p);
  return { els };
};
const L1: Layout = (p, hf) => {
  const els: El[] = [im(268, 30, 60, 60, "Logo", "circle"), tx(40, 100, 515, LET.name.toUpperCase(), 18, { align: "center", font: hf, color: p.ink, bold: true }), tx(40, 126, 515, LET.contact, 8.5, { align: "center", color: p.muted }), rc(257, 150, 80, 2.5, p.primary)];
  letterBody(els, 60, 180, 475, p, hf === "times" ? "times" : "helv");
  return { els };
};
const L2: Layout = (p, hf) => {
  const els: El[] = [rc(0, 0, 18, 842, p.primary), rc(18, 796, 577, 46, p.soft), im(480, 34, 75, 52, "Logo"), tx(52, 40, 400, LET.name, 26, { bold: true, font: hf, color: p.primary }), tx(52, 74, 400, "Senior Product Designer", 11, { color: p.muted }), tx(40, 811, 515, LET.contact, 8.5, { align: "center", color: p.muted })];
  letterBody(els, 52, 130, 503, p);
  return { els };
};
const L3: Layout = (p, hf) => {
  const els: El[] = [rc(0, 0, 595, 90, p.primary), tx(40, 24, 420, LET.name, 26, { bold: true, color: "#fff", font: hf }), tx(40, 58, 440, "Senior Product Designer", 11, { color: p.accent }), im(490, 15, 60, 60, "Logo", "circle")];
  els.push(rc(40, 790, 515, 1, p.accent), tx(40, 802, 515, LET.contact, 8.5, { align: "center", color: p.muted }));
  letterBody(els, 40, 125, 515, p);
  return { els };
};

/* ============ FLYER ============ */
const FL = {
  title: "SUMMER MUSIC FESTIVAL", sub: "Three days of live music, food and fun", date: "JULY 18-20, 2026", where: "6 PM onwards  |  Riverside Park, Austin",
  desc: "Join us for the biggest open-air celebration of the summer with 20+ local bands, food trucks and family activities for everyone.",
  cta: "FREE ENTRY  •  LIVE MUSIC  •  FOOD TRUCKS", contact: "www.summerfest.example  |  +1 (555) 010-7788",
};
const F0: Layout = (p, hf) => {
  const els: El[] = [im(0, 0, 595, 360, "Photo"), im(470, 22, 90, 52, "Logo")];
  els.push(rc(0, 360, 595, 6, p.primary), tx(40, 392, 515, FL.title, 40, { bold: true, font: hf, align: "center", color: p.primary }), tx(40, 496, 515, FL.sub, 14, { align: "center", color: p.muted, italic: true }));
  els.push(rc(150, 534, 295, 40, p.primary), tx(150, 545, 295, FL.date, 18, { bold: true, color: "#fff", align: "center" }), tx(40, 592, 515, FL.where, 12, { align: "center", color: p.ink, bold: true }), tx(80, 628, 435, FL.desc, 11.5, { align: "center", color: p.muted }));
  els.push(rc(0, 740, 595, 102, p.dark), tx(40, 762, 515, FL.cta, 15, { bold: true, color: "#fff", align: "center" }), tx(40, 796, 515, FL.contact, 10, { color: p.accent, align: "center" }));
  return { els };
};
const F1: Layout = (p, hf) => {
  const els: El[] = [rc(0, 770, 595, 72, p.dark), el(300, 330, 260, 260, p.accent), im(310, 340, 240, 240, "Photo", "circle"), im(40, 778, 70, 56, "Logo")];
  els.push(tx(40, 60, 515, FL.title, 52, { bold: true, color: "#fff", font: hf }), rc(40, 250, 90, 6, p.accent), tx(40, 272, 300, FL.sub, 14, { color: p.accent, italic: true }));
  els.push(tx(40, 350, 240, FL.date, 24, { bold: true, color: "#fff" }), tx(40, 420, 240, FL.where.replace("  |  ", "\n"), 12, { color: "#fff", bold: true }), tx(40, 480, 240, FL.desc, 11, { color: p.accent }));
  els.push(tx(40, 620, 515, FL.cta, 15, { bold: true, color: "#fff" }), tx(120, 794, 435, FL.contact, 10.5, { color: p.accent, align: "right" }));
  return { els, bg: p.primary };
};
const F2: Layout = (p, hf) => {
  const els: El[] = [rc(30, 30, 535, 782, null, { stroke: p.primary, sw: 3 }), im(262, 56, 70, 50, "Logo")];
  els.push(tx(60, 126, 475, FL.title, 38, { bold: true, font: hf, color: p.primary, align: "center" }), rc(257, 240, 80, 3, p.primary), im(97, 270, 400, 260, "Photo"));
  els.push(tx(60, 556, 475, FL.date, 24, { bold: true, color: p.ink, align: "center" }), tx(60, 592, 475, FL.where, 12, { color: p.primary, bold: true, align: "center" }), tx(100, 630, 395, FL.desc, 11.5, { color: p.muted, align: "center" }));
  els.push(rc(97, 710, 400, 44, p.primary), tx(97, 724, 400, FL.cta, 12, { bold: true, color: "#fff", align: "center" }), tx(60, 772, 475, FL.contact, 10, { color: p.muted, align: "center" }));
  return { els, bg: p.soft };
};
const F3: Layout = (p, hf) => {
  const els: El[] = [rc(0, 0, 215, 842, p.dark), tx(24, 60, 170, "18-20", 58, { bold: true, color: p.accent, font: hf }), tx(24, 130, 170, "JULY 2026", 18, { bold: true, color: "#fff" }), rc(24, 170, 50, 4, p.accent), tx(24, 190, 170, "6 PM onwards\nRiverside Park\nAustin, Texas", 12, { color: "#e5e7eb" }), im(40, 700, 135, 90, "Logo")];
  els.push(im(245, 40, 310, 300, "Photo"), tx(245, 366, 310, FL.title, 34, { bold: true, font: hf, color: p.primary }), tx(245, 466, 310, FL.sub, 13, { italic: true, color: p.muted }), tx(245, 510, 310, FL.desc, 11.5, { color: p.ink }));
  els.push(rc(245, 640, 310, 56, p.primary), tx(255, 656, 290, "FREE ENTRY • LIVE MUSIC\nFOOD TRUCKS", 13, { bold: true, color: "#fff", align: "center" }), tx(245, 730, 310, FL.contact, 10, { color: p.muted }));
  return { els };
};

/* ============ REPORT COVER ============ */
const RP = { title: "Annual Business Report", sub: "Performance, growth and outlook for fiscal year 2026", by: "Prepared by Alex Morgan", org: "Brightline Co.", date: "June 2026" };
const P0: Layout = (p, hf) => {
  const els: El[] = [rc(0, 0, 40, 842, p.primary), rc(40, 0, 8, 842, p.accent), im(90, 70, 110, 60, "Logo")];
  els.push(tx(90, 300, 430, RP.title, 46, { bold: true, font: hf, color: p.ink }), rc(90, 450, 80, 5, p.primary), tx(90, 472, 400, RP.sub, 15, { color: p.muted }));
  els.push(tx(90, 700, 300, RP.by, 12, { bold: true, color: p.ink }), tx(90, 720, 300, RP.org, 11, { color: p.muted }), tx(90, 738, 300, RP.date, 11, { color: p.primary, bold: true }));
  return { els };
};
const P1: Layout = (p, hf) => {
  const els: El[] = [im(50, 50, 110, 60, "Logo"), rc(0, 520, 595, 322, p.primary), el(420, 70, 150, 150, p.accent, { op: 0.5 }), el(380, 150, 90, 90, p.soft)];
  els.push(tx(50, 566, 495, RP.title, 42, { bold: true, color: "#fff", font: hf }), tx(50, 668, 420, RP.sub, 14, { color: p.accent }), rc(50, 740, 60, 4, p.accent));
  els.push(tx(50, 760, 300, RP.by + "  |  " + RP.org, 11, { color: "#fff" }), tx(50, 780, 300, RP.date, 11, { color: p.accent, bold: true }));
  return { els };
};
const P2: Layout = (p, hf) => {
  const els: El[] = [rc(70, 120, 455, 3, p.primary), tx(70, 90, 455, RP.org.toUpperCase(), 11, { bold: true, color: p.muted }), im(425, 60, 100, 44, "Logo")];
  els.push(tx(70, 320, 455, RP.title, 40, { font: hf, bold: true, color: p.ink }), tx(70, 420, 420, RP.sub, 14, { color: p.muted, font: hf, italic: true }));
  els.push(rc(70, 700, 455, 1, p.muted), tx(70, 714, 220, RP.by, 11, { bold: true, color: p.ink }), tx(305, 714, 220, RP.date, 11, { color: p.primary, bold: true, align: "right" }));
  return { els };
};
const P3: Layout = (p, hf) => {
  const els: El[] = [im(0, 0, 595, 430, "Photo"), rc(50, 340, 495, 8, p.primary), rc(50, 348, 495, 240, "#ffffff"), im(465, 20, 90, 50, "Logo")];
  els.push(tx(76, 376, 445, RP.title, 36, { bold: true, font: hf, color: p.ink }), tx(76, 466, 430, RP.sub, 13, { color: p.muted }), rc(76, 540, 50, 4, p.primary));
  els.push(tx(50, 650, 300, RP.by, 12, { bold: true, color: p.ink }), tx(50, 670, 300, RP.org + "  |  " + RP.date, 11, { color: p.muted }));
  return { els };
};

/* ============ registry ============ */
export type CatKey = "resume" | "certificate" | "invoice" | "letter" | "flyer" | "report";
export const CATEGORIES: { key: CatKey; label: string; blurb: string }[] = [
  { key: "resume", label: "Resume", blurb: "Land the interview" },
  { key: "certificate", label: "Certificate", blurb: "Award & recognise" },
  { key: "invoice", label: "Invoice", blurb: "Get paid faster" },
  { key: "letter", label: "Letter", blurb: "Formal & cover letters" },
  { key: "flyer", label: "Flyer", blurb: "Events & promos" },
  { key: "report", label: "Report Cover", blurb: "Look professional" },
];

export interface Template {
  id: string;
  cat: CatKey;
  name: string;
  w: number;
  h: number;
  build: () => Page;
  slots: string[];
}
type Def = [CatKey, string, Layout, [PK, FontKey][], number, number];
const PORT: [number, number] = [595, 842];
const LAND: [number, number] = [842, 595];
const defs: Def[] = [
  ["resume", "Sidebar", R0, [["ocean", "helv"], ["ember", "times"]], ...PORT],
  ["resume", "Banner", R1, [["forest", "helv"], ["plum", "times"]], ...PORT],
  ["resume", "Minimal", R2, [["slate", "times"], ["teal", "helv"]], ...PORT],
  ["resume", "Timeline", R3, [["rose", "helv"], ["gold", "times"]], ...PORT],
  ["certificate", "Classic", C0, [["gold", "times"], ["ocean", "times"]], ...LAND],
  ["certificate", "Ribbon", C1, [["teal", "helv"], ["rose", "times"]], ...LAND],
  ["certificate", "Minimal", C2, [["slate", "times"], ["forest", "helv"]], ...LAND],
  ["certificate", "Elegant", C3, [["plum", "times"], ["gold", "times"]], ...LAND],
  ["invoice", "Classic", I0, [["ocean", "helv"], ["teal", "helv"]], ...PORT],
  ["invoice", "Clean", I1, [["slate", "times"], ["rose", "helv"]], ...PORT],
  ["invoice", "Accent", I2, [["forest", "helv"], ["ember", "helv"]], ...PORT],
  ["invoice", "Bold", I3, [["plum", "helv"], ["gold", "helv"]], ...PORT],
  ["letter", "Letterhead", L0, [["ocean", "helv"], ["forest", "times"]], ...PORT],
  ["letter", "Centered", L1, [["slate", "times"], ["rose", "times"]], ...PORT],
  ["letter", "Side Bar", L2, [["teal", "helv"], ["ember", "helv"]], ...PORT],
  ["letter", "Header Band", L3, [["plum", "helv"], ["gold", "times"]], ...PORT],
  ["flyer", "Hero Photo", F0, [["ember", "helv"], ["ocean", "helv"]], ...PORT],
  ["flyer", "Color Block", F1, [["plum", "helv"], ["teal", "helv"]], ...PORT],
  ["flyer", "Framed", F2, [["rose", "times"], ["forest", "times"]], ...PORT],
  ["flyer", "Split", F3, [["ocean", "helv"], ["gold", "helv"]], ...PORT],
  ["report", "Side Bar", P0, [["ocean", "helv"], ["slate", "times"]], ...PORT],
  ["report", "Big Block", P1, [["teal", "helv"], ["rose", "helv"]], ...PORT],
  ["report", "Classic", P2, [["gold", "times"], ["forest", "times"]], ...PORT],
  ["report", "Photo Hero", P3, [["plum", "helv"], ["ember", "helv"]], ...PORT],
];

export const TEMPLATES: Template[] = defs.flatMap(([cat, lname, layout, variants, w, h]) =>
  variants.map(([pk, hf]) => {
    const p = PALS[pk];
    const build = (): Page => {
      const b = layout(p, hf);
      return { id: uid(), srcIndex: null, width: w, height: h, bg: b.bg ?? "#ffffff", elements: b.els };
    };
    return { id: `${cat}-${lname}-${pk}`.toLowerCase().replace(/\s+/g, "-"), cat, name: `${p.name} ${lname}`, w, h, build, slots: [] as string[] };
  })
);
TEMPLATES.forEach((t) => {
  const labels = t.build().elements.filter((e): e is ImageEl => e.type === "image" && !!e.placeholder).map((e) => e.placeholder!);
  t.slots = Array.from(new Set(labels));
});
