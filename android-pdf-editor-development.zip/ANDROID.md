# PDF Studio – Android APK & Play Store guide

The app is a Next.js web app packaged for Android with Capacitor.
Everything (editing, scanning, history) runs **on the phone, offline** – no server, no ads, no tracking.

- Package id: `app.pdfstudio.editor` (change in `capacitor.config.json` **and** `android/app/build.gradle` before publishing if you want your own)
- Minimum Android: **8.0 (API 26)** · Target: Android 16 (API 36)
- Camera permission is requested the first time you open the scanner.

> The APK can't be compiled inside the online editor (it needs the Android SDK + Java), so use one of the two options below.

---

## Option A – Get the APK with no setup (GitHub Actions, ~5 min)

1. Create a free GitHub repo and push this project to it (`git init`, `git add .`, `git commit`, `git push`).
2. Open the repo → **Actions** → **Build Android APK** → it runs automatically on every push (or press *Run workflow*).
3. When it finishes, open the run and download the artifact **PDF-Studio-debug-apk** → unzip → `app-debug.apk`.
4. Copy it to your phone, tap it, allow "Install unknown apps" once. Done.

The debug APK is perfect for your own use. For the Play Store you need the signed release below.

## Option B – Build on your computer

Requirements: Node 22, Java 21, Android Studio (or just the Android SDK).

```bash
npm install
bash scripts/build-static.sh      # builds ./out (the offline web bundle)
npx cap sync android
cd android
./gradlew assembleDebug           # APK -> android/app/build/outputs/apk/debug/app-debug.apk
```

Or run `npx cap open android` and use *Build → Build APK(s)* in Android Studio.

---

## Publishing on Google Play

### 1. Create your signing key (once – keep it safe, you can never replace it)

```bash
keytool -genkeypair -v -keystore release.jks -alias pdfstudio -keyalg RSA -keysize 2048 -validity 10000
```

### 2. Build the signed bundle (.aab)

**On GitHub:** add these repository secrets (*Settings → Secrets and variables → Actions*):

| Secret | Value |
| --- | --- |
| `KEYSTORE_BASE64` | output of `base64 -w0 release.jks` |
| `KEYSTORE_PASSWORD` | your keystore password |
| `KEY_ALIAS` | `pdfstudio` |
| `KEY_PASSWORD` | your key password |

Re-run the workflow – it now also uploads **PDF-Studio-release** containing a signed `.apk` and the `.aab` for Play.

**Locally:**

```bash
export KEYSTORE_FILE=/full/path/release.jks KEYSTORE_PASSWORD=... KEY_ALIAS=pdfstudio KEY_PASSWORD=...
cd android && ./gradlew bundleRelease   # -> app/build/outputs/bundle/release/app-release.aab
```

### 3. Play Console checklist

1. Create a developer account (one-time US$25 fee) and a new app.
2. Upload the `.aab` to a Production (or Internal testing) release. Enrol in **Play App Signing** when asked.
3. Store listing: name, short + full description, 512×512 icon (`public/icons/icon-512.png`), a feature graphic (1024×500) and at least 2 phone screenshots.
4. **Data safety:** the app collects/shares **no data** – everything stays on the device.
5. **Privacy policy:** required even for offline apps – a one-paragraph page saying "PDF Studio processes files only on your device and sends nothing anywhere" is enough. Camera is used only to scan documents.
6. Content rating questionnaire + target audience → submit for review.

### Releasing updates
Increase `versionCode` (and `versionName`) in `android/app/build.gradle` for every upload.

---

## Developing the web app

```bash
npm run dev          # http://localhost:3000 (also installable as a PWA when hosted over https)
```
After changing the UI, rebuild the Android bundle with `bash scripts/build-static.sh && npx cap sync android`.
