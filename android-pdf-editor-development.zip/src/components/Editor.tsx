"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Ann, EditorInit, ImageAnn, InkAnn, PageState, RectAnn, Source, TextAnn, Tool } from "@/lib/types";
import { pageDims, uid } from "@/lib/types";
import { PageView, type RectStyle } from "./PageView";
import { ExportSheet, PagesSheet, SignatureSheet, StampSheet, type StampChoice } from "./EditorSheets";
import { Icon } from "./ui";
import { exportPdf, loadSource, summarizeEdits } from "@/lib/pdf";
import { savePdf, readFileBytes } from "@/lib/files";
import { addHistory } from "@/lib/history";
import { loadImage } from "@/lib/scan";

const COLORS = ["#111827", "#2563eb", "#dc2626", "#16a34a", "#f59e0b", "#7c3aed", "#ffffff"];
const EMPTY: Ann[] = [];

type Snap = { pages: PageState[]; anns: Ann[] };

async function imageFileToDataUrl(file: File, max = 1400): Promise<{ url: string; w: number; h: number }> {
  const tmp = URL.createObjectURL(file);
  try {
    const img = await loadImage(tmp);
    const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.round(img.naturalWidth * k);
    const h = Math.round(img.naturalHeight * k);
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    const ctx = c.getContext("2d")!;
    const png = file.type === "image/png";
    if (!png) {
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, w, h);
    }
    ctx.drawImage(img, 0, 0, w, h);
    return { url: c.toDataURL(png ? "image/png" : "image/jpeg", 0.9), w, h };
  } finally {
    URL.revokeObjectURL(tmp);
  }
}

const rotatePoint = (x: number, y: number, dhOld: number): [number, number] => [dhOld - y, x];

function rotateAnnsCW(anns: Ann[], pageId: string, dhOld: number): Ann[] {
  return anns.map((a) => {
    if (a.pageId !== pageId) return a;
    if (a.type === "ink") return { ...a, points: a.points.map(([x, y]) => rotatePoint(x, y, dhOld)) };
    if (a.type === "rect") {
      const [cx, cy] = rotatePoint(a.x + a.w / 2, a.y + a.h / 2, dhOld);
      return { ...a, w: a.h, h: a.w, x: cx - a.h / 2, y: cy - a.w / 2 };
    }
    if (a.type === "image") {
      const [cx, cy] = rotatePoint(a.x + a.w / 2, a.y + a.h / 2, dhOld);
      return { ...a, x: cx - a.w / 2, y: cy - a.h / 2 };
    }
    const lines = a.text.split("\n");
    const w = Math.max(...lines.map((l) => l.length), 1) * a.size * 0.5;
    const h = lines.length * a.size * 1.2;
    const [cx, cy] = rotatePoint(a.x + w / 2, a.y + h / 2, dhOld);
    return { ...a, x: cx - w / 2, y: cy - h / 2 };
  });
}

const tools: { id: Tool | "image" | "sign" | "stamp" | "pages"; icon: string; label: string }[] = [
  { id: "select", icon: "select", label: "Select" },
  { id: "text", icon: "text", label: "Text" },
  { id: "draw", icon: "pen", label: "Draw" },
  { id: "highlight", icon: "highlight", label: "Highlight" },
  { id: "whiteout", icon: "whiteout", label: "White-out" },
  { id: "shape", icon: "shape", label: "Box" },
  { id: "sign", icon: "sign", label: "Sign" },
  { id: "image", icon: "image", label: "Image" },
  { id: "stamp", icon: "stamp", label: "Stamp" },
  { id: "pages", icon: "pages", label: "Pages" },
];

export default function Editor({
  init,
  onExit,
  onDirty,
  toast,
}: {
  init: EditorInit;
  onExit: () => void;
  onDirty: (d: boolean) => void;
  toast: (msg: string) => void;
}) {
  const [sources, setSources] = useState<Source[]>(init.sources);
  const [pages, setPages] = useState<PageState[]>(init.pages);
  const [anns, setAnns] = useState<Ann[]>(init.anns);
  const [tool, setTool] = useState<Tool>("select");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [color, setColor] = useState(COLORS[0]);
  const [inkWidth, setInkWidth] = useState(3);
  const [zoom, setZoom] = useState(1);
  const [cur, setCur] = useState(0);
  const [sheet, setSheet] = useState<null | "sign" | "stamp" | "pages" | "export">(null);
  const [saving, setSaving] = useState(false);
  const [boxW, setBoxW] = useState(360);
  const [undoN, setUndoN] = useState(0);

  const scroller = useRef<HTMLDivElement>(null);
  const past = useRef<Snap[]>([]);
  const live = useRef<Snap>({ pages, anns });
  live.current = { pages, anns };
  const dirty = useRef(false);
  const imgInput = useRef<HTMLInputElement>(null);
  const pdfInput = useRef<HTMLInputElement>(null);
  const textRef = useRef<HTMLTextAreaElement>(null);
  const focusNew = useRef<string | null>(null);

  const markDirty = useCallback(() => {
    if (!dirty.current) {
      dirty.current = true;
      onDirty(true);
    }
  }, [onDirty]);

  const begin = useCallback(() => {
    past.current.push({ pages: live.current.pages, anns: live.current.anns });
    if (past.current.length > 60) past.current.shift();
    setUndoN(past.current.length);
    markDirty();
  }, [markDirty]);

  const undo = () => {
    const s = past.current.pop();
    if (!s) return;
    setPages(s.pages);
    setAnns(s.anns);
    setUndoN(past.current.length);
    setSelectedId(null);
  };

  useEffect(() => {
    onDirty(false);
    return () => onDirty(false);
  }, [onDirty]);

  /* measure container */
  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setBoxW(el.clientWidth));
    ro.observe(el);
    setBoxW(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const fitW = Math.min(boxW - 24, 820);

  /* current page tracking */
  const onScroll = useRef<number | null>(null);
  const handleScroll = () => {
    if (onScroll.current) return;
    onScroll.current = requestAnimationFrame(() => {
      onScroll.current = null;
      const el = scroller.current;
      if (!el) return;
      const mid = el.getBoundingClientRect().top + el.clientHeight / 2;
      const nodes = el.querySelectorAll<HTMLElement>("[data-page]");
      let idx = 0;
      nodes.forEach((n, i) => {
        if (n.getBoundingClientRect().top <= mid) idx = i;
      });
      setCur(idx);
    });
  };

  /* annotations grouped per page, keeping array identity so pages don't re-render needlessly */
  const cache = useRef(new Map<string, Ann[]>());
  const byPage = useMemo(() => {
    const m = new Map<string, Ann[]>();
    for (const a of anns) {
      const l = m.get(a.pageId);
      if (l) l.push(a);
      else m.set(a.pageId, [a]);
    }
    for (const [id, arr] of m) {
      const prev = cache.current.get(id);
      if (prev && prev.length === arr.length && prev.every((x, i) => x === arr[i])) m.set(id, prev);
      else cache.current.set(id, arr);
    }
    return m;
  }, [anns]);

  /* ----------------- annotation actions ----------------- */
  const selected = anns.find((a) => a.id === selectedId) ?? null;

  const patch = useCallback((id: string, p: Partial<Ann>) => {
    setAnns((cur) => cur.map((a) => (a.id === id ? ({ ...a, ...p } as Ann) : a)));
  }, []);

  const add = (a: Ann, select = true) => {
    begin();
    setAnns((cur) => [...cur, a]);
    if (select) setSelectedId(a.id);
  };

  const remove = (id: string) => {
    begin();
    setAnns((cur) => cur.filter((a) => a.id !== id));
    setSelectedId(null);
  };

  const duplicate = (a: Ann) => {
    const copy = { ...a, id: uid() } as Ann;
    if (copy.type === "ink") copy.points = copy.points.map(([x, y]) => [x + 14, y + 14]);
    else {
      (copy as TextAnn).x += 14;
      (copy as TextAnn).y += 14;
    }
    delete copy.tplText;
    add(copy);
  };

  const onTextAt = useCallback(
    (pageId: string, x: number, y: number) => {
      const a: TextAnn = {
        id: uid(),
        pageId,
        type: "text",
        label: "Text",
        x,
        y: y - 8,
        text: "Text",
        size: 16,
        color: color === "#ffffff" ? "#111827" : color,
        bold: false,
        font: "sans",
      };
      focusNew.current = a.id;
      setAnns((c) => [...c, a]);
      past.current.push({ pages: live.current.pages, anns: live.current.anns });
      setUndoN(past.current.length);
      markDirty();
      setSelectedId(a.id);
      setTool("select");
    },
    [color, markDirty],
  );

  const onRectDone = useCallback(
    (pageId: string, x: number, y: number, w: number, h: number) => {
      let style: Pick<RectAnn, "fill" | "stroke" | "opacity" | "label">;
      if (tool === "highlight") style = { fill: "#facc15", stroke: null, opacity: 0.4, label: "Highlight" };
      else if (tool === "whiteout") style = { fill: "#ffffff", stroke: null, opacity: 1, label: "White-out" };
      else style = { fill: null, stroke: color, opacity: 1, label: "Shape" };
      const a: RectAnn = { id: uid(), pageId, type: "rect", x, y, w, h, strokeWidth: 2, ...style };
      begin();
      setAnns((c) => [...c, a]);
    },
    [tool, color, begin],
  );

  const onInkDone = useCallback(
    (pageId: string, pts: [number, number][]) => {
      const a: InkAnn = {
        id: uid(),
        pageId,
        type: "ink",
        label: "Drawing",
        points: pts,
        color: color,
        width: inkWidth,
      };
      begin();
      setAnns((c) => [...c, a]);
    },
    [color, inkWidth, begin],
  );

  /* where to drop new items: the middle of the visible part of the current page */
  const dropPoint = (): { pageId: string; x: number; y: number; dw: number; dh: number } => {
    const page = pages[Math.min(cur, pages.length - 1)];
    const [dw, dh] = pageDims(page);
    const el = scroller.current?.querySelector<HTMLElement>(`[data-page="${page.id}"]`);
    let y = dh / 2;
    if (el && scroller.current) {
      const r = el.getBoundingClientRect();
      const mid = scroller.current.getBoundingClientRect().top + scroller.current.clientHeight / 2;
      y = Math.min(dh - 30, Math.max(30, ((mid - r.top) / r.height) * dh));
    }
    return { pageId: page.id, x: dw / 2, y, dw, dh };
  };

  const addImage = async (file: File) => {
    try {
      const { url, w, h } = await imageFileToDataUrl(file);
      const d = dropPoint();
      const iw = Math.min(d.dw * 0.5, 240);
      const ih = (iw * h) / w;
      const a: ImageAnn = {
        id: uid(),
        pageId: d.pageId,
        type: "image",
        label: "Image",
        x: d.x - iw / 2,
        y: Math.max(0, d.y - ih / 2),
        w: iw,
        h: ih,
        dataUrl: url,
      };
      add(a);
      setTool("select");
    } catch {
      toast("Couldn't open that image");
    }
  };

  const addSignature = (url: string, w: number, h: number) => {
    const d = dropPoint();
    const iw = Math.min(d.dw * 0.38, 190);
    const ih = (iw * h) / w;
    add({
      id: uid(),
      pageId: d.pageId,
      type: "image",
      label: "Signature",
      x: d.x - iw / 2,
      y: Math.max(0, d.y - ih / 2),
      w: iw,
      h: ih,
      dataUrl: url,
    });
    setTool("select");
    setSheet(null);
  };

  const addStamp = (s: StampChoice) => {
    const d = dropPoint();
    if (s.kind === "text") {
      add({
        id: uid(),
        pageId: d.pageId,
        type: "text",
        label: "Stamp",
        x: Math.max(10, d.x - s.text.length * 8),
        y: d.y - 14,
        text: s.text,
        size: 26,
        color: s.color,
        bold: true,
        font: "sans",
      });
    } else {
      const raw: [number, number][] =
        s.shape === "check"
          ? [
              [0, 14],
              [10, 24],
              [30, 2],
            ]
          : [
              [0, 0],
              [26, 26],
              [13, 13],
              [26, 0],
              [0, 26],
            ];
      add({
        id: uid(),
        pageId: d.pageId,
        type: "ink",
        label: "Stamp",
        color: s.color,
        width: 4,
        points: raw.map(([x, y]) => [x + d.x - 14, y + d.y - 14]),
      });
    }
    setTool("select");
    setSheet(null);
  };

  /* ----------------- page actions ----------------- */
  const scrollToPage = (i: number) => {
    const id = pages[i]?.id;
    requestAnimationFrame(() =>
      scroller.current
        ?.querySelector<HTMLElement>(`[data-page="${id}"]`)
        ?.scrollIntoView({ behavior: "smooth", block: "start" }),
    );
  };

  const rotatePage = (i: number) => {
    begin();
    const p = pages[i];
    const [, dh] = pageDims(p);
    setPages((cur) => cur.map((x, k) => (k === i ? { ...x, rot: (x.rot + 90) % 360 } : x)));
    setAnns((cur) => rotateAnnsCW(cur, p.id, dh));
  };
  const movePage = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= pages.length) return;
    begin();
    setPages((cur) => {
      const n = [...cur];
      [n[i], n[j]] = [n[j], n[i]];
      return n;
    });
  };
  const deletePage = (i: number) => {
    if (pages.length <= 1) return;
    begin();
    const id = pages[i].id;
    setPages((cur) => cur.filter((_, k) => k !== i));
    setAnns((cur) => cur.filter((a) => a.pageId !== id));
    setSelectedId(null);
  };
  const addBlank = () => {
    begin();
    const ref = pages[Math.min(cur, pages.length - 1)];
    const [w, h] = ref ? [ref.bw, ref.bh] : [595, 842];
    setPages((c) => [...c, { id: uid(), src: null, rot: 0, bw: w, bh: h }]);
    toast("Blank page added at the end");
  };
  const mergePdfs = async (files: FileList | null) => {
    if (!files?.length) return;
    try {
      let srcs = sources;
      const newPages: PageState[] = [];
      for (const f of Array.from(files)) {
        const s = await loadSource(await readFileBytes(f), f.name);
        srcs = [...srcs, s];
        const di = srcs.length - 1;
        s.dims.forEach(([w, h], index) => newPages.push({ id: uid(), src: { doc: di, index }, rot: 0, bw: w, bh: h }));
      }
      begin();
      setSources(srcs);
      setPages((c) => [...c, ...newPages]);
      toast(`Added ${newPages.length} page${newPages.length === 1 ? "" : "s"}`);
    } catch {
      toast("That PDF couldn't be opened");
    }
  };

  /* ----------------- export ----------------- */
  const doSave = async (name: string) => {
    setSaving(true);
    try {
      const bytes = await exportPdf(sources, pages, anns);
      const details = summarizeEdits(init, pages, anns);
      const merged = details.some((d) => d.startsWith("Merged"));
      const res = await savePdf(bytes, name);
      await addHistory(
        {
          name: name.replace(/\.pdf$/i, "") + ".pdf",
          action: init.templateName ? "created" : merged ? "merged" : "edited",
          details,
          pages: pages.length,
        },
        bytes,
      );
      dirty.current = false;
      onDirty(false);
      setSheet(null);
      toast(`Saved to ${res.where}`);
    } catch (e) {
      console.error(e);
      toast("Couldn't save the PDF. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const baseName = init.name.replace(/\.pdf$/i, "");
  const defaultName = init.templateName || init.sources.length === 0 ? baseName : `${baseName}-edited`;

  /* focus the textarea for freshly-created text */
  useEffect(() => {
    if (selected && focusNew.current === selected.id && textRef.current) {
      textRef.current.focus();
      textRef.current.select();
      focusNew.current = null;
    }
  }, [selected]);

  const rectPreview: RectStyle =
    tool === "highlight"
      ? { fill: "#facc15", stroke: null, opacity: 0.4 }
      : tool === "whiteout"
        ? { fill: "#ffffff", stroke: "#94a3b8", opacity: 1 }
        : { fill: null, stroke: color, opacity: 1 };

  const pickTool = (id: (typeof tools)[number]["id"]) => {
    if (id === "image") return imgInput.current?.click();
    if (id === "sign") return setSheet("sign");
    if (id === "stamp") return setSheet("stamp");
    if (id === "pages") return setSheet("pages");
    setSelectedId(null);
    setTool(id);
  };

  const hint: Record<Tool, string> = {
    select: "Tap anything on the page to edit, move or delete it",
    text: "Tap on the page where you want to type",
    draw: "Draw with your finger",
    highlight: "Drag over text to highlight it",
    whiteout: "Drag over anything to cover it up",
    shape: "Drag to draw a box",
  };

  const Swatches = ({ value, onPick }: { value: string; onPick: (c: string) => void }) => (
    <div className="flex items-center gap-2">
      {COLORS.map((c) => (
        <button
          key={c}
          onClick={() => onPick(c)}
          aria-label={`Colour ${c}`}
          className={`h-7 w-7 shrink-0 rounded-full border-2 transition ${value === c ? "scale-110 border-indigo-500" : "border-slate-200"}`}
          style={{ background: c }}
        />
      ))}
    </div>
  );

  const pageW = fitW * zoom;

  return (
    <div className="fixed inset-0 z-30 flex flex-col bg-slate-200">
      {/* header */}
      <header className="flex items-center gap-1 bg-white px-2 pb-2 pt-[calc(0.5rem+env(safe-area-inset-top))] shadow-sm">
        <button onClick={onExit} className="rounded-full p-2.5 text-slate-700 active:bg-slate-100" aria-label="Back">
          <Icon name="back" />
        </button>
        <div className="min-w-0 flex-1 px-1">
          <p className="truncate text-[15px] font-semibold text-slate-900">{init.name}</p>
          <p className="text-xs text-slate-400">
            {pages.length} page{pages.length === 1 ? "" : "s"}
          </p>
        </div>
        <button
          onClick={undo}
          disabled={!undoN}
          className="rounded-full p-2.5 text-slate-700 active:bg-slate-100 disabled:opacity-30"
          aria-label="Undo"
        >
          <Icon name="undo" />
        </button>
        <button
          onClick={() => setSheet("export")}
          className="ml-1 flex items-center gap-1.5 rounded-full bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-indigo-600/30 active:bg-indigo-700"
        >
          <Icon name="download" size={18} /> Save
        </button>
      </header>

      {/* pages */}
      <div className="relative min-h-0 flex-1">
        <div ref={scroller} onScroll={handleScroll} className="h-full overflow-auto overscroll-contain">
          <div
            className="mx-auto space-y-3 py-3"
            style={{ width: Math.max(boxW, pageW + 24), paddingLeft: 12, paddingRight: 12 }}
          >
            {pages.map((p) => (
              <PageView
                key={p.id}
                page={p}
                sources={sources}
                width={pageW}
                anns={byPage.get(p.id) ?? EMPTY}
                tool={tool}
                selectedId={selectedId}
                inkColor={color}
                inkWidth={inkWidth}
                rectPreview={rectPreview}
                onSelect={setSelectedId}
                onPatch={patch}
                onBegin={begin}
                onTextAt={onTextAt}
                onRectDone={onRectDone}
                onInkDone={onInkDone}
              />
            ))}
          </div>
        </div>
        <div className="pointer-events-none absolute inset-x-0 bottom-3 flex items-end justify-between px-3">
          <div className="rounded-full bg-slate-900/70 px-3 py-1 text-xs font-medium text-white backdrop-blur">
            {Math.min(cur + 1, pages.length)} / {pages.length}
          </div>
          <div className="pointer-events-auto flex overflow-hidden rounded-full bg-white shadow-lg">
            <button
              onClick={() => setZoom((z) => Math.max(1, +(z - 0.5).toFixed(1)))}
              className="p-2.5 text-slate-700 active:bg-slate-100 disabled:opacity-30"
              disabled={zoom <= 1}
              aria-label="Zoom out"
            >
              <Icon name="zoomout" size={20} />
            </button>
            <button
              onClick={() => setZoom((z) => Math.min(3, +(z + 0.5).toFixed(1)))}
              className="p-2.5 text-slate-700 active:bg-slate-100 disabled:opacity-30"
              disabled={zoom >= 3}
              aria-label="Zoom in"
            >
              <Icon name="zoomin" size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* context panel */}
      <div className="border-t border-slate-200 bg-white px-3 py-2.5">
        {selected ? (
          <div className="space-y-2.5">
            {selected.type === "text" && (
              <>
                <textarea
                  ref={textRef}
                  value={selected.text}
                  onFocus={begin}
                  onChange={(e) => patch(selected.id, { text: e.target.value })}
                  rows={2}
                  className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-[15px] outline-none focus:border-indigo-400 focus:ring-4 focus:ring-indigo-100"
                />
                <div className="flex items-center gap-2">
                  <div className="flex items-center rounded-xl bg-slate-100">
                    <button
                      onClick={() => (begin(), patch(selected.id, { size: Math.max(6, selected.size - 2) }))}
                      className="p-2 text-slate-700 active:bg-slate-200"
                      aria-label="Smaller"
                    >
                      <Icon name="minus" size={18} />
                    </button>
                    <span className="w-8 text-center text-sm font-semibold tabular-nums">{selected.size}</span>
                    <button
                      onClick={() => (begin(), patch(selected.id, { size: Math.min(120, selected.size + 2) }))}
                      className="p-2 text-slate-700 active:bg-slate-200"
                      aria-label="Larger"
                    >
                      <Icon name="plus" size={18} />
                    </button>
                  </div>
                  <button
                    onClick={() => (begin(), patch(selected.id, { bold: !selected.bold }))}
                    className={`h-9 w-9 rounded-xl text-sm font-extrabold ${selected.bold ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-700"}`}
                    aria-label="Bold"
                  >
                    B
                  </button>
                  <button
                    onClick={() => {
                      begin();
                      const order = ["sans", "serif", "mono"] as const;
                      patch(selected.id, { font: order[(order.indexOf(selected.font) + 1) % 3] });
                    }}
                    className="h-9 rounded-xl bg-slate-100 px-3 text-xs font-semibold capitalize text-slate-700"
                  >
                    {selected.font}
                  </button>
                  <div className="ml-auto flex">
                    <button onClick={() => duplicate(selected)} className="rounded-xl p-2 text-slate-600 active:bg-slate-100" aria-label="Duplicate">
                      <Icon name="copy" size={20} />
                    </button>
                    <button onClick={() => remove(selected.id)} className="rounded-xl p-2 text-rose-500 active:bg-rose-50" aria-label="Delete">
                      <Icon name="trash" size={20} />
                    </button>
                  </div>
                </div>
                <div className="no-scrollbar overflow-x-auto">
                  <Swatches value={selected.color} onPick={(c) => (begin(), patch(selected.id, { color: c }))} />
                </div>
              </>
            )}
            {selected.type === "rect" && (
              <div className="flex items-center gap-3">
                <div className="no-scrollbar min-w-0 flex-1 overflow-x-auto">
                  <Swatches
                    value={(selected.fill ?? selected.stroke) || ""}
                    onPick={(c) =>
                      (begin(), patch(selected.id, selected.fill ? { fill: c } : { stroke: c }))
                    }
                  />
                </div>
                <button onClick={() => duplicate(selected)} className="rounded-xl p-2 text-slate-600 active:bg-slate-100" aria-label="Duplicate">
                  <Icon name="copy" size={20} />
                </button>
                <button onClick={() => remove(selected.id)} className="rounded-xl p-2 text-rose-500 active:bg-rose-50" aria-label="Delete">
                  <Icon name="trash" size={20} />
                </button>
              </div>
            )}
            {selected.type === "ink" && (
              <div className="flex items-center gap-3">
                <div className="no-scrollbar min-w-0 flex-1 overflow-x-auto">
                  <Swatches value={selected.color} onPick={(c) => (begin(), patch(selected.id, { color: c }))} />
                </div>
                <button onClick={() => remove(selected.id)} className="rounded-xl p-2 text-rose-500 active:bg-rose-50" aria-label="Delete">
                  <Icon name="trash" size={20} />
                </button>
              </div>
            )}
            {selected.type === "image" && (
              <div className="flex items-center justify-between">
                <p className="text-sm text-slate-500">Drag to move · drag the corner dot to resize</p>
                <div className="flex">
                  <button onClick={() => duplicate(selected)} className="rounded-xl p-2 text-slate-600 active:bg-slate-100" aria-label="Duplicate">
                    <Icon name="copy" size={20} />
                  </button>
                  <button onClick={() => remove(selected.id)} className="rounded-xl p-2 text-rose-500 active:bg-rose-50" aria-label="Delete">
                    <Icon name="trash" size={20} />
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            <p className="text-center text-xs text-slate-400">{hint[tool]}</p>
            {(tool === "draw" || tool === "shape" || tool === "text") && (
              <div className="flex items-center gap-3">
                <div className="no-scrollbar min-w-0 flex-1 overflow-x-auto">
                  <Swatches value={color} onPick={setColor} />
                </div>
                {tool === "draw" && (
                  <div className="flex shrink-0 gap-1">
                    {[2, 4, 7].map((w) => (
                      <button
                        key={w}
                        onClick={() => setInkWidth(w)}
                        className={`grid h-8 w-8 place-items-center rounded-lg ${inkWidth === w ? "bg-indigo-100" : "bg-slate-100"}`}
                        aria-label={`Width ${w}`}
                      >
                        <span className="rounded-full bg-slate-700" style={{ width: w + 3, height: w + 3 }} />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* toolbar */}
      <nav className="no-scrollbar flex overflow-x-auto border-t border-slate-100 bg-white px-1 pb-[calc(0.25rem+env(safe-area-inset-bottom))] pt-1">
        {tools.map((t) => {
          const active = t.id === tool && !selected;
          return (
            <button
              key={t.id}
              onClick={() => pickTool(t.id)}
              className={`flex min-w-[64px] flex-1 flex-col items-center gap-0.5 rounded-xl px-1 py-1.5 text-[11px] font-medium transition ${active ? "bg-indigo-50 text-indigo-700" : "text-slate-500 active:bg-slate-50"}`}
            >
              <Icon name={t.icon} size={22} />
              {t.label}
            </button>
          );
        })}
      </nav>

      <input
        ref={imgInput}
        type="file"
        accept="image/*"
        hidden
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) addImage(f);
          e.target.value = "";
        }}
      />
      <input
        ref={pdfInput}
        type="file"
        accept="application/pdf,.pdf"
        multiple
        hidden
        onChange={(e) => {
          mergePdfs(e.target.files);
          e.target.value = "";
        }}
      />

      <SignatureSheet open={sheet === "sign"} onClose={() => setSheet(null)} onUse={addSignature} />
      <StampSheet open={sheet === "stamp"} onClose={() => setSheet(null)} onPick={addStamp} />
      <PagesSheet
        open={sheet === "pages"}
        onClose={() => setSheet(null)}
        pages={pages}
        sources={sources}
        onRotate={rotatePage}
        onMove={movePage}
        onDelete={deletePage}
        onAddBlank={addBlank}
        onAddPdf={() => pdfInput.current?.click()}
        onGoto={scrollToPage}
      />
      <ExportSheet
        open={sheet === "export"}
        onClose={() => setSheet(null)}
        initialName={defaultName}
        busy={saving}
        onSave={doSave}
      />
    </div>
  );
}
