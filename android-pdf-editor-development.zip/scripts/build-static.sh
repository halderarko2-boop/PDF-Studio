#!/usr/bin/env bash
# Builds the fully static, offline-capable web bundle (./out) that gets packaged into the Android app.
# The /api/health route is only needed for the web preview, so it is moved aside during this build.
set -euo pipefail
cd "$(dirname "$0")/.."
BAK="$(mktemp -d)"
if [ -d src/app/api ]; then mv src/app/api "$BAK/api"; fi
restore() { if [ -d "$BAK/api" ]; then mv "$BAK/api" src/app/api; fi; }
trap restore EXIT
rm -rf out
BUILD_TARGET=static npx next build
