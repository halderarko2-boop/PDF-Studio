"use client";

import { memo, useEffect, useRef, useState } from "react";
import type { RenderTask } from "pdfjs-dist";
import type { Ann, PageState, Source, Tool } from "@/lib/types";
import { pageDims } from "@/lib/types";
import { renderPage } from "@/lib/pdf";

export type RectStyle = { fill: string | null; stroke: string | null; opacity: number };

type Props = {
  page: PageState;
  sources: Source[];
  width: number;
  anns: Ann[];
  tool: Tool;
  selectedId: string | null;
  inkColor: string;
  inkWidth: number;
  rectPreview: RectStyle;
  onSelect: (id: string | null) => void;
  onPatch: (id: string, patch: Partial<Ann>) => void;
  onBegin: () => void;
  onTextAt: (pageId: string, x: number, y: number) => void;
  onRectDone: (pageId: string, x: number, y: number, w: number, h: number) => void;
  onInkDone: (pageId: string, pts: [number, number][]) => void;
};

const FONT_CSS = {
  sans: "Helvetica, Arial, sans-serif",
  serif: "'Times New Roman', Times, serif",
  mono: "'Courier New', Courier, monospace",
} as const;

function PageViewInner(p: Props) {
  const { page, sources, width, anns, tool, selectedId } = p;
  const [dw, dh] = pageDims(page);
  const s = width / dw;
  const height = dh * s;

  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [visible, setVisible] = useState(false);
  const [rendered, setRendered] = useState(false);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting), {
      rootMargin: "1400px 0px",
    });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!page.src || !canvas) return;
    if (!visible) {
      canvas.width = 1;
      canvas.height = 1;
      setRendered(false);
      return;
    }
    let task: RenderTask | null = null;
    let dead = false;
    const t = setTimeout(() => {
      renderPage(sources[page.src!.doc], page.src!.index, page.rot, width, canvas, (tk) => (task = tk))
        .then(() => !dead && setRendered(true))
        .catch(() => {});
    }, 80);
    return () => {
      dead = true;
      clearTimeout(t);
      task?.cancel();
    };
  }, [visible, width, page.rot, page.src, sources]);

  const toPt = (e: { clientX: number; clientY: number }): [number, number] => {
    const r = wrapRef.current!.getBoundingClientRect();
    return [((e.clientX - r.left) / r.width) * dw, ((e.clientY - r.top) / r.height) * dh];
  };

  /* ---- drawing / rect creation ---- */
  const [ink, setInk] = useState<[number, number][] | null>(null);
  const [rect, setRect] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
  const isRectTool = tool === "highlight" || tool === "whiteout" || tool === "shape";
  const creating = tool === "draw" || isRectTool;

  const down = (e: React.PointerEvent) => {
    if (!creating) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    const [x, y] = toPt(e);
    if (tool === "draw") setInk([[x, y]]);
    else setRect({ x0: x, y0: y, x1: x, y1: y });
  };
  const move = (e: React.PointerEvent) => {
    if (!creating) return;
    const [x, y] = toPt(e);
    if (ink) setInk((cur) => (cur ? [...cur, [x, y]] : cur));
    else if (rect) setRect({ ...rect, x1: x, y1: y });
  };
  const up = () => {
    if (ink) {
      p.onInkDone(page.id, ink);
      setInk(null);
    } else if (rect) {
      const x = Math.min(rect.x0, rect.x1);
      const y = Math.min(rect.y0, rect.y1);
      const w = Math.abs(rect.x1 - rect.x0);
      const h = Math.abs(rect.y1 - rect.y0);
      if (w > 4 && h > 4) p.onRectDone(page.id, x, y, w, h);
      setRect(null);
    }
  };

  /* ---- dragging existing items ---- */
  const drag = useRef<{
    id: string;
    mode: "move" | "resize";
    sx: number;
    sy: number;
    a: Ann;
    began: boolean;
  } | null>(null);

  const itemDown = (e: React.PointerEvent, a: Ann, mode: "move" | "resize" = "move") => {
    if (tool !== "select") return;
    e.stopPropagation();
    if (selectedId !== a.id) {
      p.onSelect(a.id);
      return;
    }
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { id: a.id, mode, sx: e.clientX, sy: e.clientY, a, began: false };
  };
  const itemMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const dx = (e.clientX - d.sx) / s;
    const dy = (e.clientY - d.sy) / s;
    if (!d.began) {
      if (Math.abs(dx) + Math.abs(dy) < 2) return;
      d.began = true;
      p.onBegin();
    }
    const a = d.a;
    if (d.mode === "move" && (a.type === "text" || a.type === "rect" || a.type === "image")) {
      p.onPatch(a.id, { x: a.x + dx, y: a.y + dy });
    } else if (d.mode === "resize" && (a.type === "rect" || a.type === "image")) {
      if (a.type === "image") {
        const ratio = a.h / a.w;
        const w = Math.max(16, a.w + dx);
        p.onPatch(a.id, { w, h: w * ratio });
      } else {
        p.onPatch(a.id, { w: Math.max(6, a.w + dx), h: Math.max(2, a.h + dy) });
      }
    }
  };
  const itemUp = () => {
    drag.current = null;
  };

  const sel = (a: Ann) => a.id === selectedId && tool === "select";
  const outline = "0 0 0 2px #6366f1";

  return (
    <div
      ref={wrapRef}
      data-page={page.id}
      className="relative mx-auto overflow-hidden bg-white shadow-[0_4px_18px_rgba(15,23,42,0.18)]"
      style={{
        width,
        height,
        touchAction: creating ? "none" : "auto",
        cursor: tool === "text" ? "text" : creating ? "crosshair" : "default",
      }}
      onPointerDown={down}
      onPointerMove={move}
      onPointerUp={up}
      onPointerCancel={up}
      onClick={(e) => {
        if (tool === "text") {
          const [x, y] = toPt(e);
          p.onTextAt(page.id, x, y);
        } else if (tool === "select") p.onSelect(null);
      }}
    >
      {page.src && (
        <canvas
          ref={canvasRef}
          className="absolute left-0 top-0 select-none"
          style={{ width, height, opacity: rendered ? 1 : 0, transition: "opacity .2s" }}
        />
      )}
      {page.src && !rendered && visible && (
        <div className="absolute inset-0 grid place-items-center">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-indigo-200 border-t-indigo-600" />
        </div>
      )}

      {anns.map((a) => {
        if (a.type === "text") {
          return (
            <div
              key={a.id}
              onPointerDown={(e) => itemDown(e, a)}
              onPointerMove={itemMove}
              onPointerUp={itemUp}
              onClick={(e) => e.stopPropagation()}
              className="absolute select-none"
              style={{
                left: a.x * s,
                top: a.y * s,
                fontSize: a.size * s,
                lineHeight: 1.2,
                color: a.color,
                fontWeight: a.bold ? 700 : 400,
                fontFamily: FONT_CSS[a.font],
                whiteSpace: "pre",
                minWidth: 10 * s,
                minHeight: a.size * 1.2 * s,
                boxShadow: sel(a) ? outline : undefined,
                borderRadius: 2,
                touchAction: sel(a) ? "none" : "auto",
                pointerEvents: creating ? "none" : "auto",
              }}
            >
              {a.text}
            </div>
          );
        }
        if (a.type === "rect") {
          return (
            <div
              key={a.id}
              onPointerDown={(e) => itemDown(e, a)}
              onPointerMove={itemMove}
              onPointerUp={itemUp}
              onClick={(e) => e.stopPropagation()}
              className="absolute"
              style={{
                left: a.x * s,
                top: a.y * s,
                width: a.w * s,
                height: a.h * s,
                background: a.fill ?? "transparent",
                opacity: a.fill ? a.opacity : 1,
                border: a.stroke ? `${Math.max(1, a.strokeWidth * s)}px solid ${a.stroke}` : undefined,
                boxSizing: "border-box",
                boxShadow: sel(a) ? outline : undefined,
                touchAction: sel(a) ? "none" : "auto",
                pointerEvents: creating ? "none" : a.h < 3 && !sel(a) ? "none" : "auto",
              }}
            >
              {sel(a) && (
                <div
                  onPointerDown={(e) => itemDown(e, a, "resize")}
                  onPointerMove={itemMove}
                  onPointerUp={itemUp}
                  className="absolute -bottom-3 -right-3 grid h-7 w-7 place-items-center"
                  style={{ touchAction: "none" }}
                >
                  <div className="h-4 w-4 rounded-full border-2 border-white bg-indigo-500 shadow" />
                </div>
              )}
            </div>
          );
        }
        if (a.type === "image") {
          return (
            <div
              key={a.id}
              onPointerDown={(e) => itemDown(e, a)}
              onPointerMove={itemMove}
              onPointerUp={itemUp}
              onClick={(e) => e.stopPropagation()}
              className="absolute"
              style={{
                left: a.x * s,
                top: a.y * s,
                width: a.w * s,
                height: a.h * s,
                boxShadow: sel(a) ? outline : undefined,
                touchAction: sel(a) ? "none" : "auto",
                pointerEvents: creating ? "none" : "auto",
              }}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={a.dataUrl} alt="" draggable={false} className="h-full w-full select-none" />
              {sel(a) && (
                <div
                  onPointerDown={(e) => itemDown(e, a, "resize")}
                  onPointerMove={itemMove}
                  onPointerUp={itemUp}
                  className="absolute -bottom-3 -right-3 grid h-7 w-7 place-items-center"
                  style={{ touchAction: "none" }}
                >
                  <div className="h-4 w-4 rounded-full border-2 border-white bg-indigo-500 shadow" />
                </div>
              )}
            </div>
          );
        }
        return null;
      })}

      <svg
        className="pointer-events-none absolute left-0 top-0"
        width={width}
        height={height}
        viewBox={`0 0 ${dw} ${dh}`}
      >
        {anns.map((a) => {
          if (a.type !== "ink") return null;
          const d = "M" + a.points.map((q) => `${q[0].toFixed(1)} ${q[1].toFixed(1)}`).join(" L");
          const dot = a.points.length === 1 ? `${d} l0.1 0` : d;
          const selected = sel(a);
          return (
            <g key={a.id}>
              {selected && (
                <path d={dot} fill="none" stroke="#6366f1" strokeOpacity={0.35} strokeWidth={a.width + 6} strokeLinecap="round" strokeLinejoin="round" />
              )}
              <path d={dot} fill="none" stroke={a.color} strokeWidth={a.width} strokeLinecap="round" strokeLinejoin="round" />
              {tool === "select" && (
                <path
                  d={dot}
                  fill="none"
                  stroke="transparent"
                  strokeWidth={Math.max(a.width, 16)}
                  strokeLinecap="round"
                  style={{ pointerEvents: "stroke" }}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    p.onSelect(a.id);
                  }}
                  onClick={(e) => e.stopPropagation()}
                />
              )}
            </g>
          );
        })}
        {ink && (
          <path
            d={"M" + ink.map((q) => `${q[0].toFixed(1)} ${q[1].toFixed(1)}`).join(" L") + (ink.length === 1 ? " l0.1 0" : "")}
            fill="none"
            stroke={p.inkColor}
            strokeWidth={p.inkWidth}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}
        {rect && (
          <rect
            x={Math.min(rect.x0, rect.x1)}
            y={Math.min(rect.y0, rect.y1)}
            width={Math.abs(rect.x1 - rect.x0)}
            height={Math.abs(rect.y1 - rect.y0)}
            fill={p.rectPreview.fill ?? "none"}
            fillOpacity={p.rectPreview.opacity}
            stroke={p.rectPreview.stroke ?? (p.rectPreview.fill ? "none" : "#6366f1")}
            strokeWidth={p.rectPreview.stroke ? 2 : 1}
            strokeDasharray={p.rectPreview.fill ? undefined : "4 3"}
          />
        )}
      </svg>
    </div>
  );
}

export const PageView = memo(PageViewInner);

export function Thumb({ source, index, rot, w, h }: { source: Source | null; index: number; rot: number; w: number; h: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const width = 64;
  useEffect(() => {
    const c = ref.current;
    if (!c || !source) return;
    let task: RenderTask | null = null;
    renderPage(source, index, rot, width, c, (t) => (task = t)).catch(() => {});
    return () => {
      task?.cancel();
    };
  }, [source, index, rot]);
  const dh = (w > 0 ? h / w : 1.4) * width;
  return source ? (
    <canvas ref={ref} className="rounded border border-slate-200 bg-white" style={{ width, height: dh }} />
  ) : (
    <div className="rounded border border-slate-200 bg-white" style={{ width, height: dh }} />
  );
}
