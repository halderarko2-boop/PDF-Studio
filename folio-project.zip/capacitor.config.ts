import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.folio.pdfeditor",
  appName: "Folio PDF",
  webDir: "dist",
  backgroundColor: "#f4f5fb",
  android: {
    allowMixedContent: false,
  },
};

export default config;
