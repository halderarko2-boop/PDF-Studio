import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, Camera, Check, ChevronLeft, Crop, FileText, ImagePlus, Loader2, RefreshCw, RotateCcw, RotateCw, Trash2, Zap, ZapOff } from "lucide-react";
import { Sheet, toast } from "./ui";
import { Crop as CropT, Filter, IMAGE_ACCEPT, loadImageFiles, processScan } from "../lib/images";
import { useBack } from "../lib/nav";
import { uid } from "../lib/types";

export interface ScanOut { src: string; w: number; h: number }
interface Shot { id: string; original: string; filter: Filter; rot: number; crop: CropT | null; out: ScanOut }

const FILTERS: { id: Filter; label: string }[] = [
  { id: "original", label: "Original" },
  { id: "enhanced", label: "Enhanced" },
  { id: "gray", label: "Grayscale" },
  { id: "bw", label: "B & W" },
];

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

function CropBox({ src, w, h, value, onChange }: { src: string; w: number; h: number; value: CropT; onChange: (c: CropT) => void }) {
  const box = useRef<HTMLDivElement>(null);
  const maxW = Math.min(window.innerWidth - 40, 480), maxH = window.innerHeight * 0.5;
  const k = Math.min(maxW / w, maxH / h);
  const dw = w * k, dh = h * k;
  const drag = (corner: string) => (e: React.PointerEvent) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    const move = (ev: PointerEvent) => {
      const r = box.current!.getBoundingClientRect();
      const fx = clamp((ev.clientX - r.left) / r.width, 0, 1), fy = clamp((ev.clientY - r.top) / r.height, 0, 1);
      let { x, y } = value;
      let x2 = value.x + value.w, y2 = value.y + value.h;
      if (corner.includes("l")) x = Math.min(fx, x2 - 0.08); else x2 = Math.max(fx, x + 0.08);
      if (corner.includes("t")) y = Math.min(fy, y2 - 0.08); else y2 = Math.max(fy, y + 0.08);
      onChange({ x, y, w: x2 - x, h: y2 - y });
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };
  const H = (corner: string, left: number, top: number) => (
    <div key={corner} onPointerDown={drag(corner)} className="absolute w-11 h-11 -ml-[22px] -mt-[22px] flex items-center justify-center touch-none" style={{ left: `${left * 100}%`, top: `${top * 100}%` }}>
      <div className="w-5 h-5 rounded-full bg-white border-[3px] border-indigo-500 shadow" />
    </div>
  );
  return (
    <div className="mx-auto relative select-none touch-none" style={{ width: dw, height: dh }} ref={box}>
      <img src={src} alt="" className="w-full h-full" draggable={false} />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute border-2 border-indigo-500" style={{ left: `${value.x * 100}%`, top: `${value.y * 100}%`, width: `${value.w * 100}%`, height: `${value.h * 100}%`, boxShadow: "0 0 0 9999px rgba(15,23,42,.55)" }} />
      </div>
      {H("tl", value.x, value.y)}
      {H("tr", value.x + value.w, value.y)}
      {H("bl", value.x, value.y + value.h)}
      {H("br", value.x + value.w, value.y + value.h)}
    </div>
  );
}

export default function Scanner({ startMode, onClose, onCreate }: { startMode: "camera" | "gallery"; onClose: () => void; onCreate: (pages: ScanOut[], name: string) => void }) {
  const [stage, setStage] = useState<"camera" | "review">(startMode === "camera" ? "camera" : "review");
  const [shots, setShots] = useState<Shot[]>([]);
  const [globalFilter, setGlobalFilter] = useState<Filter>("original");
  const gf = useRef(globalFilter);
  gf.current = globalFilter;
  const [name, setName] = useState(() => "Scan " + new Date().toLocaleDateString([], { month: "short", day: "numeric" }) + " " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }).replace(/[: ]/g, ""));
  const [busy, setBusy] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [cropMode, setCropMode] = useState(false);
  const [cropPrev, setCropPrev] = useState<ScanOut | null>(null);
  const [cr, setCr] = useState<CropT>({ x: 0.05, y: 0.05, w: 0.9, h: 0.9 });

  const video = useRef<HTMLVideoElement>(null);
  const stream = useRef<MediaStream | null>(null);
  const [err, setErr] = useState("");
  const [facing, setFacing] = useState<"environment" | "user">("environment");
  const [torch, setTorch] = useState<boolean | null>(null);
  const [flash, setFlash] = useState(false);
  const galleryIn = useRef<HTMLInputElement>(null);
  const camIn = useRef<HTMLInputElement>(null);

  const stop = () => {
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
  };

  useEffect(() => {
    if (stage !== "camera") return stop();
    let dead = false;
    (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera is not available here");
        const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: facing }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false });
        if (dead) return s.getTracks().forEach((t) => t.stop());
        stream.current = s;
        if (video.current) {
          video.current.srcObject = s;
          await video.current.play().catch(() => {});
        }
        const caps = (s.getVideoTracks()[0].getCapabilities?.() ?? {}) as { torch?: boolean };
        setTorch(caps.torch ? false : null);
        setErr("");
      } catch (e) {
        setErr(e instanceof Error && e.message ? e.message : "Camera permission was denied");
      }
    })();
    return () => {
      dead = true;
      stop();
    };
  }, [stage, facing]);

  const toggleTorch = async () => {
    const t = stream.current?.getVideoTracks()[0];
    if (!t) return;
    try {
      await t.applyConstraints({ advanced: [{ torch: !torch } as MediaTrackConstraintSet] });
      setTorch(!torch);
    } catch {
      toast("Flash not supported");
    }
  };

  const addOriginals = useCallback(async (srcs: string[]) => {
    const made: Shot[] = [];
    for (const original of srcs) {
      const out = await processScan(original, { rot: 0, crop: null, filter: gf.current });
      made.push({ id: uid(), original, filter: gf.current, rot: 0, crop: null, out });
    }
    setShots((x) => [...x, ...made]);
  }, []);

  const capture = async () => {
    const v = video.current;
    if (!v || !v.videoWidth) return;
    const c = document.createElement("canvas");
    const k = Math.min(1, 2200 / Math.max(v.videoWidth, v.videoHeight));
    c.width = v.videoWidth * k;
    c.height = v.videoHeight * k;
    c.getContext("2d")!.drawImage(v, 0, 0, c.width, c.height);
    setFlash(true);
    setTimeout(() => setFlash(false), 140);
    setBusy(true);
    await addOriginals([c.toDataURL("image/jpeg", 0.92)]);
    setBusy(false);
  };

  const importFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    const { out, failed } = await loadImageFiles(files);
    await addOriginals(out.map((o) => o.src));
    setBusy(false);
    if (failed.length) toast(`Couldn't read: ${failed.join(", ")}`);
    if (out.length) setStage("review");
  };

  const redo = async (id: string, patch: Partial<Shot>) => {
    const cur = shots.find((s) => s.id === id);
    if (!cur) return;
    const n = { ...cur, ...patch };
    setBusy(true);
    n.out = await processScan(n.original, { rot: n.rot, crop: n.crop, filter: n.filter });
    setShots((x) => x.map((s) => (s.id === id ? n : s)));
    setBusy(false);
  };

  const applyAll = async (f: Filter) => {
    setGlobalFilter(f);
    setBusy(true);
    const next: Shot[] = [];
    for (const s of shots) next.push({ ...s, filter: f, out: await processScan(s.original, { rot: s.rot, crop: s.crop, filter: f }) });
    setShots(next);
    setBusy(false);
  };

  const edit = shots.find((s) => s.id === editId) ?? null;
  const idx = edit ? shots.indexOf(edit) : -1;

  const startCrop = async () => {
    if (!edit) return;
    setBusy(true);
    setCropPrev(await processScan(edit.original, { rot: edit.rot, crop: null, filter: edit.filter }));
    setCr({ x: 0.04, y: 0.04, w: 0.92, h: 0.92 });
    setCropMode(true);
    setBusy(false);
  };

  const move = (d: number) =>
    setShots((x) => {
      const j = idx + d;
      if (idx < 0 || j < 0 || j >= x.length) return x;
      const c = [...x];
      [c[idx], c[j]] = [c[j], c[idx]];
      return c;
    });

  useBack(() => {
    if (stage === "camera" && shots.length) setStage("review");
    else onClose();
  });

  const hiddenInputs = (
    <>
      <input ref={galleryIn} type="file" multiple accept={IMAGE_ACCEPT} className="hidden" onChange={(e) => { importFiles(e.target.files); e.target.value = ""; }} />
      <input ref={camIn} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => { importFiles(e.target.files); e.target.value = ""; }} />
    </>
  );

  /* ---------------- camera stage ---------------- */
  if (stage === "camera") {
    return (
      <div className="fixed inset-0 z-40 bg-black flex flex-col safe-top">
        {hiddenInputs}
        <div className="flex items-center justify-between px-3 h-14 text-white">
          <button onClick={() => (shots.length ? setStage("review") : onClose())} className="w-10 h-10 rounded-full bg-white/15 flex items-center justify-center"><ChevronLeft /></button>
          <div className="text-sm font-medium">{shots.length ? `${shots.length} page${shots.length > 1 ? "s" : ""} captured` : "Point at your document"}</div>
          <div className="flex gap-2">
            {torch !== null && <button onClick={toggleTorch} className="w-10 h-10 rounded-full bg-white/15 flex items-center justify-center">{torch ? <Zap size={18} className="text-yellow-300" /> : <ZapOff size={18} />}</button>}
            <button onClick={() => setFacing(facing === "environment" ? "user" : "environment")} className="w-10 h-10 rounded-full bg-white/15 flex items-center justify-center"><RefreshCw size={18} /></button>
          </div>
        </div>
        <div className="flex-1 relative overflow-hidden">
          {err ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center text-white px-8 gap-4">
              <Camera size={40} className="opacity-60" />
              <div className="font-semibold">Can't open the live camera</div>
              <div className="text-sm text-white/60">{err}. You can still use your phone's camera app instead.</div>
              <button onClick={() => camIn.current?.click()} className="h-12 px-6 rounded-2xl grad font-semibold">Open camera app</button>
            </div>
          ) : (
            <video ref={video} playsInline muted autoPlay className="absolute inset-0 w-full h-full object-cover" />
          )}
          {!err && <div className="absolute inset-8 border-2 border-white/40 rounded-2xl pointer-events-none" />}
          {flash && <div className="absolute inset-0 bg-white/80" />}
        </div>
        <div className="h-32 flex items-center justify-around px-6 safe-bottom bg-black/90">
          <button onClick={() => galleryIn.current?.click()} className="w-14 h-14 rounded-2xl bg-white/15 text-white flex items-center justify-center"><ImagePlus /></button>
          <button onClick={err ? () => camIn.current?.click() : capture} disabled={busy} className="w-[76px] h-[76px] rounded-full border-4 border-white flex items-center justify-center active:scale-95 transition">
            <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center">{busy && <Loader2 className="animate-spin text-slate-500" />}</div>
          </button>
          <button onClick={() => setStage("review")} disabled={!shots.length} className="w-14 h-14 rounded-2xl overflow-hidden bg-white/15 text-white flex items-center justify-center disabled:opacity-40 relative">
            {shots.length ? <><img src={shots[shots.length - 1].out.src} className="w-full h-full object-cover" alt="" /><span className="absolute -top-0 -right-0 min-w-5 h-5 px-1 rounded-full bg-indigo-500 text-[11px] flex items-center justify-center font-bold">{shots.length}</span></> : <Check />}
          </button>
        </div>
      </div>
    );
  }

  /* ---------------- review stage ---------------- */
  return (
    <div className="fixed inset-0 z-40 bg-[#f4f5fb] flex flex-col safe-top">
      {hiddenInputs}
      <div className="flex items-center gap-2 px-3 h-14 bg-white shadow-sm shrink-0">
        <button onClick={onClose} className="w-10 h-10 rounded-full flex items-center justify-center active:bg-slate-100"><ChevronLeft /></button>
        <input value={name} onChange={(e) => setName(e.target.value)} className="flex-1 min-w-0 font-semibold bg-transparent outline-none truncate" aria-label="Document name" />
        {busy && <Loader2 className="animate-spin text-indigo-500" size={18} />}
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        {shots.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center gap-3 px-6">
            <div className="w-20 h-20 rounded-3xl grad text-white flex items-center justify-center shadow-lg shadow-indigo-200"><FileText size={36} /></div>
            <h2 className="text-xl font-bold">Pictures to PDF</h2>
            <p className="text-sm text-slate-500 max-w-xs">Pick photos from your gallery or snap them with the camera. Pages can be cropped, rotated and cleaned up before saving.</p>
            <button onClick={() => galleryIn.current?.click()} className="h-12 px-6 rounded-2xl grad text-white font-semibold flex items-center gap-2 mt-2">{busy ? <Loader2 className="animate-spin" size={18} /> : <ImagePlus size={18} />} Choose pictures</button>
            <button onClick={() => setStage("camera")} className="h-12 px-6 rounded-2xl bg-white text-indigo-600 font-semibold flex items-center gap-2 shadow-sm"><Camera size={18} /> Use camera</button>
          </div>
        ) : (
          <>
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-3">
              {FILTERS.map((f) => (
                <button key={f.id} onClick={() => applyAll(f.id)} className={"px-4 h-9 rounded-full text-sm font-medium shrink-0 " + (globalFilter === f.id ? "bg-indigo-600 text-white" : "bg-white text-slate-600 shadow-sm")}>{f.label}</button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3 pb-40">
              {shots.map((s, i) => (
                <button key={s.id} onClick={() => setEditId(s.id)} className="relative rounded-2xl bg-white p-2 shadow-sm active:scale-[.98] transition text-left">
                  <div className="aspect-[3/4] flex items-center justify-center bg-slate-100 rounded-xl overflow-hidden"><img src={s.out.src} alt="" className="max-w-full max-h-full object-contain" /></div>
                  <div className="absolute top-3 left-3 w-6 h-6 rounded-full bg-slate-900/80 text-white text-xs font-bold flex items-center justify-center">{i + 1}</div>
                  <div className="text-[11px] text-slate-500 mt-1.5 px-1">Tap to crop / rotate</div>
                </button>
              ))}
            </div>
          </>
        )}
      </div>
      {shots.length > 0 && (
        <div className="absolute bottom-0 left-0 right-0 p-4 safe-bottom bg-gradient-to-t from-[#f4f5fb] via-[#f4f5fb] to-transparent pt-8">
          <div className="max-w-xl mx-auto flex gap-3">
            <button onClick={() => setStage("camera")} className="w-14 h-14 rounded-2xl bg-white shadow text-indigo-600 flex items-center justify-center"><Camera /></button>
            <button onClick={() => galleryIn.current?.click()} className="w-14 h-14 rounded-2xl bg-white shadow text-indigo-600 flex items-center justify-center"><ImagePlus /></button>
            <button onClick={() => onCreate(shots.map((s) => s.out), name.trim() || "Scan")} className="flex-1 h-14 rounded-2xl grad text-white font-semibold flex items-center justify-center gap-2 shadow-lg shadow-indigo-300">
              <FileText size={20} /> Create PDF ({shots.length})
            </button>
          </div>
        </div>
      )}

      <Sheet open={!!edit} onClose={() => { setEditId(null); setCropMode(false); }} title={cropMode ? "Drag the corners" : `Page ${idx + 1}`} tall>
        {edit && (
          <div className="flex flex-col gap-4">
            <div className="rounded-2xl bg-slate-100 p-2 min-h-[200px] flex items-center justify-center">
              {cropMode && cropPrev ? (
                <CropBox src={cropPrev.src} w={cropPrev.w} h={cropPrev.h} value={cr} onChange={setCr} />
              ) : (
                <img src={edit.out.src} alt="" className="max-h-[48dvh] max-w-full object-contain" />
              )}
            </div>
            {cropMode ? (
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => setCropMode(false)} className="h-12 rounded-2xl bg-slate-100 font-semibold">Cancel</button>
                <button onClick={async () => { setCropMode(false); await redo(edit.id, { crop: cr }); }} className="h-12 rounded-2xl grad text-white font-semibold">Apply crop</button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-5 gap-2 text-[11px] font-medium text-slate-600">
                  {[
                    { l: "Left", i: <RotateCcw size={20} />, f: () => redo(edit.id, { rot: edit.rot - 90, crop: null }) },
                    { l: "Right", i: <RotateCw size={20} />, f: () => redo(edit.id, { rot: edit.rot + 90, crop: null }) },
                    { l: "Crop", i: <Crop size={20} />, f: startCrop },
                    { l: "Reset", i: <RefreshCw size={20} />, f: () => redo(edit.id, { crop: null, rot: 0 }) },
                    { l: "Delete", i: <Trash2 size={20} />, f: () => { setShots((x) => x.filter((s) => s.id !== edit.id)); setEditId(null); } },
                  ].map((b) => (
                    <button key={b.l} onClick={b.f} className={"h-16 rounded-2xl bg-slate-100 flex flex-col items-center justify-center gap-1 active:scale-95 " + (b.l === "Delete" ? "text-red-500" : "")}>{b.i}{b.l}</button>
                  ))}
                </div>
                <div className="flex gap-2 overflow-x-auto no-scrollbar">
                  {FILTERS.map((f) => (
                    <button key={f.id} onClick={() => redo(edit.id, { filter: f.id })} className={"px-4 h-10 rounded-full text-sm font-medium shrink-0 " + (edit.filter === f.id ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-700")}>{f.label}</button>
                  ))}
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex gap-2">
                    <button disabled={idx === 0} onClick={() => move(-1)} className="h-11 px-4 rounded-xl bg-slate-100 disabled:opacity-30 flex items-center gap-1 text-sm"><ArrowLeft size={16} /> Earlier</button>
                    <button disabled={idx === shots.length - 1} onClick={() => move(1)} className="h-11 px-4 rounded-xl bg-slate-100 disabled:opacity-30 flex items-center gap-1 text-sm">Later <ArrowRight size={16} /></button>
                  </div>
                  <button onClick={() => setEditId(null)} className="h-11 px-6 rounded-xl grad text-white font-semibold">Done</button>
                </div>
              </>
            )}
          </div>
        )}
      </Sheet>
    </div>
  );
}
