import { useEffect, useRef } from "react";

const stack: { current: (() => void) | null }[] = [];

/** Android back-button stack: the newest mounted handler wins */
export function useBack(handler: (() => void) | null) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    stack.push(ref);
    return () => {
      const i = stack.lastIndexOf(ref);
      if (i >= 0) stack.splice(i, 1);
    };
  }, []);
}

export function triggerBack(): boolean {
  for (let i = stack.length - 1; i >= 0; i--) {
    const h = stack[i].current;
    if (h) {
      h();
      return true;
    }
  }
  return false;
}
