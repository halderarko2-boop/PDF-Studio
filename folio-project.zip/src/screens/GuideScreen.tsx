import { useState } from "react";
import { ChevronLeft, Copy, Download, Check } from "lucide-react";
import workflow from "../../.github/workflows/build-apk.yml?raw";
import { saveBytes } from "../lib/pdf";
import { toast } from "../components/ui";

const zips = import.meta.glob("../assets/*.zip", { query: "?url", import: "default", eager: true }) as Record<string, string>;
const zipUrl = Object.values(zips)[0];

const STEPS: { t: string; items: React.ReactNode[] }[] = [
  {
    t: "1. Get the project file",
    items: [
      <>Tap <b>Download project ZIP</b> above. You get one file called <b>folio-project.zip</b> (it lands in your phone's <b>Downloads</b> folder).</>,
      "Do NOT unzip it. GitHub will unzip it for you later.",
    ],
  },
  {
    t: "2. Make a free GitHub account",
    items: [
      <>Open <b>github.com</b> in Chrome and tap <b>Sign up</b>. Use your email, make a password and verify the email code.</>,
      <>In Chrome tap the <b>⋮</b> menu and tick <b>Desktop site</b>. GitHub's buttons are easier to find that way.</>,
    ],
  },
  {
    t: "3. Create a repository (a folder online)",
    items: [
      <>Tap the <b>+</b> at the top → <b>New repository</b>.</>,
      <>Repository name: <b>folio-pdf</b>. Choose <b>Public</b>. Tick <b>Add a README file</b>. Tap <b>Create repository</b>.</>,
    ],
  },
  {
    t: "4. Upload the ZIP",
    items: [
      <>Inside your new repository tap <b>Add file</b> → <b>Upload files</b>.</>,
      <>Tap <b>choose your files</b>, pick <b>folio-project.zip</b> from Downloads, wait for the upload bar to finish.</>,
      <>Scroll down and tap <b>Commit changes</b>.</>,
    ],
  },
  {
    t: "5. Add the build recipe",
    items: [
      <>Tap <b>Add file</b> → <b>Create new file</b>.</>,
      <>In the name box type exactly: <b>.github/workflows/build-apk.yml</b> (typing each "/" makes a folder automatically).</>,
      <>Tap <b>Copy build recipe</b> above, long-press in the big text box and <b>Paste</b>.</>,
      <>Tap <b>Commit changes…</b> → <b>Commit changes</b>. The build starts by itself.</>,
    ],
  },
  {
    t: "6. Wait for the build",
    items: [
      <>Tap the <b>Actions</b> tab. You'll see <b>Build Android APK</b> running with a yellow dot.</>,
      "It takes about 6–12 minutes. A green tick means success. Grab a coffee.",
      <>Red cross? Tap it, open the step with the red mark and read the message. See "If something goes wrong" below.</>,
    ],
  },
  {
    t: "7. Download your APK",
    items: [
      <>Go back to the repository main page (the <b>Code</b> tab). On the right (or lower down on phones) tap <b>Releases</b>.</>,
      <>Open the newest release <b>Folio PDF APK</b> and tap <b>Folio-PDF.apk</b> under Assets. Chrome downloads it.</>,
    ],
  },
  {
    t: "8. Install it on your phone",
    items: [
      "Open the downloaded file (Chrome shows it at the bottom, or open your Files app → Downloads).",
      <>Android says it's blocked: tap <b>Settings</b> → turn on <b>Allow from this source</b> → press back.</>,
      <>Tap <b>Install</b>. If Play Protect warns you, tap <b>More details</b> → <b>Install anyway</b> (it's your own app).</>,
      <>Open <b>Folio PDF</b>. The first time you scan, tap <b>Allow</b> for camera access. Saved PDFs go to <b>Documents/Folio</b> (or a Share menu appears so you can pick where).</>,
    ],
  },
];

const TROUBLE = [
  [<>Nothing happens after the commit</>, <>Open <b>Actions</b>. If it asks to enable workflows, tap <b>I understand my workflows, go ahead and enable them</b>. Then open <b>Build Android APK</b> → <b>Run workflow</b> → <b>Run workflow</b>.</>],
  [<>"Resource not accessible by integration"</>, <>Repository <b>Settings</b> → <b>Actions</b> → <b>General</b> → <b>Workflow permissions</b> → choose <b>Read and write permissions</b> → <b>Save</b>. Then open the failed run and tap <b>Re-run all jobs</b>.</>],
  [<>Build says it can't find package.json</>, <>The ZIP wasn't uploaded to the main folder. Upload <b>folio-project.zip</b> again so it sits next to README.md.</>],
  [<>Can't see Releases</>, <>The build must be green first. You can also open the finished run under <b>Actions</b> and download <b>Folio-PDF-apk</b> from Artifacts at the bottom (it is a zip containing the APK).</>],
  [<>Updating the app later</>, <>Upload a new ZIP with the same name (Add file → Upload files, it replaces the old one) and commit. A new build starts and a new release appears. Install it over the old app.</>],
] as const;

export default function GuideScreen({ onBack }: { onBack: () => void }) {
  const [copied, setCopied] = useState(false);
  const [showYml, setShowYml] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(workflow);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = workflow;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    toast("Build recipe copied");
    setTimeout(() => setCopied(false), 2500);
  };

  const download = async () => {
    if (!zipUrl) return toast("ZIP not found in this build");
    const buf = new Uint8Array(await (await fetch(zipUrl)).arrayBuffer());
    toast("Saved to " + (await saveBytes(buf, "folio-project.zip", "application/zip")));
  };

  return (
    <div className="px-5 pt-4 pb-32 max-w-xl mx-auto safe-top">
      <button onClick={onBack} className="flex items-center gap-1 text-sm font-semibold text-slate-600 -ml-1 mb-3"><ChevronLeft size={18} /> Back</button>
      <h1 className="text-2xl font-extrabold tracking-tight">Make the Android app</h1>
      <p className="text-sm text-slate-500 mt-1">Turn Folio into an installable APK for Android 8.0+ using only your phone. No computer, no cost.</p>

      <div className="grid grid-cols-2 gap-3 mt-5">
        <button onClick={download} className="h-14 rounded-2xl grad text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-200 active:scale-95"><Download size={18} /> Download project ZIP</button>
        <button onClick={copy} className="h-14 rounded-2xl bg-white text-indigo-600 font-semibold text-sm flex items-center justify-center gap-2 shadow-sm active:scale-95">{copied ? <Check size={18} /> : <Copy size={18} />} Copy build recipe</button>
      </div>
      <button onClick={() => setShowYml(!showYml)} className="text-xs text-slate-400 mt-3 underline">{showYml ? "Hide" : "Show"} build recipe text</button>
      {showYml && <pre className="mt-2 bg-slate-900 text-slate-100 text-[10px] leading-relaxed rounded-2xl p-4 overflow-x-auto max-h-72">{workflow}</pre>}

      <div className="mt-6 space-y-4">
        {STEPS.map((s) => (
          <div key={s.t} className="bg-white rounded-3xl p-5 shadow-sm">
            <div className="font-bold text-slate-900 mb-2">{s.t}</div>
            <ul className="space-y-2 text-sm text-slate-600 leading-relaxed">
              {s.items.map((it, i) => <li key={i} className="flex gap-2"><span className="mt-2 w-1.5 h-1.5 rounded-full bg-indigo-400 shrink-0" /><span>{it}</span></li>)}
            </ul>
          </div>
        ))}
      </div>

      <h2 className="font-bold text-lg mt-8 mb-3">If something goes wrong</h2>
      <div className="space-y-3">
        {TROUBLE.map(([q, a], i) => (
          <div key={i} className="bg-white rounded-2xl p-4 shadow-sm">
            <div className="font-semibold text-sm text-slate-800">{q}</div>
            <div className="text-sm text-slate-500 mt-1 leading-relaxed">{a}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
