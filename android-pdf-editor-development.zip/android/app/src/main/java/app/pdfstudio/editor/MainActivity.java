package app.pdfstudio.editor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
