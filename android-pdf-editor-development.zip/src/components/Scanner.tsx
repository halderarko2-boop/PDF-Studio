"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Btn, Icon, Sheet, Spinner } from "./ui";
import {
  prepareImage,
  processPage,
  rotatedCanvas,
  scansToPdf,
  thumbUrl,
  type PageFit,
  type ScanFilter,
  type ScanPage,
} from "@/lib/scan";
import { uid } from "@/lib/types";
import { savePdf } from "@/lib/files";
import { addHistory } from "@/lib/history";

const FILTERS: { id: ScanFilter; label: string }[] = [
  { id: "original", label: "Original" },
  { id: "enhance", label: "Enhanced" },
  { id: "gray", label: "Grey" },
  { id: "bw", label: "B & W" },
];
const FULL = { x: 0, y: 0, w: 1, h: 1 };

/* ------------------------------ camera ------------------------------ */

function Camera({
  count,
  onShot,
  onClose,
  onFallback,
}: {
  count: number;
  onShot: (b: Blob) => void;
  onClose: () => void;
  onFallback: () => void;
}) {
  const video = useRef<HTMLVideoElement>(null);
  const stream = useRef<MediaStream | null>(null);
  const [ready, setReady] = useState(false);
  const [flash, setFlash] = useState(false);

  useEffect(() => {
    let dead = false;
    (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error("no camera api");
        const s = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" }, width: { ideal: 2560 }, height: { ideal: 1440 } },
          audio: false,
        });
        if (dead) {
          s.getTracks().forEach((t) => t.stop());
          return;
        }
        stream.current = s;
        if (video.current) {
          video.current.srcObject = s;
          await video.current.play();
          setReady(true);
        }
      } catch {
        onFallback();
      }
    })();
    return () => {
      dead = true;
      stream.current?.getTracks().forEach((t) => t.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const shoot = () => {
    const v = video.current;
    if (!v || !v.videoWidth) return;
    const c = document.createElement("canvas");
    c.width = v.videoWidth;
    c.height = v.videoHeight;
    c.getContext("2d")!.drawImage(v, 0, 0);
    setFlash(true);
    setTimeout(() => setFlash(false), 120);
    c.toBlob((b) => b && onShot(b), "image/jpeg", 0.92);
  };

  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-black">
      <div className="relative flex-1 overflow-hidden">
        <video ref={video} playsInline muted className="h-full w-full object-cover" />
        {!ready && <div className="absolute inset-0 grid place-items-center text-sm text-white/70">Starting camera…</div>}
        {/* framing guide */}
        <div className="pointer-events-none absolute inset-6 rounded-3xl border-2 border-white/40" />
        {flash && <div className="absolute inset-0 bg-white/70" />}
        <div className="absolute inset-x-0 top-0 flex items-center justify-between p-4 pt-[calc(1rem+env(safe-area-inset-top))] text-white">
          <button onClick={onClose} className="rounded-full bg-black/40 p-2.5 backdrop-blur" aria-label="Close camera">
            <Icon name="close" />
          </button>
          <span className="rounded-full bg-black/40 px-3 py-1 text-xs backdrop-blur">Fit the document inside the frame</span>
          <span className="w-10" />
        </div>
      </div>
      <div className="flex items-center justify-between bg-black px-8 pb-[calc(1.5rem+env(safe-area-inset-bottom))] pt-5">
        <div className="w-16 text-sm text-white/70">{count > 0 ? `${count} scanned` : ""}</div>
        <button
          onClick={shoot}
          disabled={!ready}
          className="grid h-[72px] w-[72px] place-items-center rounded-full border-4 border-white disabled:opacity-40"
          aria-label="Capture"
        >
          <span className="h-14 w-14 rounded-full bg-white active:scale-90 transition" />
        </button>
        <button
          onClick={onClose}
          className="w-16 rounded-full bg-indigo-600 py-2 text-sm font-semibold text-white"
        >
          {count > 0 ? "Done" : "Cancel"}
        </button>
      </div>
    </div>
  );
}

/* ------------------------------ crop ------------------------------ */

type Crop = ScanPage["crop"];

function CropView({
  page,
  onApply,
  onCancel,
}: {
  page: ScanPage;
  onApply: (c: Crop) => void;
  onCancel: () => void;
}) {
  const [src, setSrc] = useState<string>("");
  const [c, setC] = useState<Crop>(page.crop);
  const box = useRef<HTMLDivElement>(null);
  const drag = useRef<{ mode: string; sx: number; sy: number; c0: Crop } | null>(null);

  useEffect(() => {
    rotatedCanvas({ ...page, crop: FULL }, 1000).then((cv) => setSrc(cv.toDataURL("image/jpeg", 0.8)));
  }, [page]);

  const down = (e: React.PointerEvent, mode: string) => {
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { mode, sx: e.clientX, sy: e.clientY, c0: c };
  };
  const move = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d || !box.current) return;
    const r = box.current.getBoundingClientRect();
    const dx = (e.clientX - d.sx) / r.width;
    const dy = (e.clientY - d.sy) / r.height;
    let { x, y, w, h } = d.c0;
    const min = 0.08;
    if (d.mode === "move") {
      x = Math.min(1 - w, Math.max(0, x + dx));
      y = Math.min(1 - h, Math.max(0, y + dy));
    } else {
      let x0 = x,
        y0 = y,
        x1 = x + w,
        y1 = y + h;
      if (d.mode.includes("w")) x0 = Math.min(x1 - min, Math.max(0, x0 + dx));
      if (d.mode.includes("e")) x1 = Math.max(x0 + min, Math.min(1, x1 + dx));
      if (d.mode.includes("n")) y0 = Math.min(y1 - min, Math.max(0, y0 + dy));
      if (d.mode.includes("s")) y1 = Math.max(y0 + min, Math.min(1, y1 + dy));
      x = x0;
      y = y0;
      w = x1 - x0;
      h = y1 - y0;
    }
    setC({ x, y, w, h });
  };
  const up = () => (drag.current = null);

  const corners = [
    { m: "nw", s: { left: -14, top: -14 } },
    { m: "ne", s: { right: -14, top: -14 } },
    { m: "sw", s: { left: -14, bottom: -14 } },
    { m: "se", s: { right: -14, bottom: -14 } },
  ];

  return (
    <div className="fixed inset-0 z-[70] flex flex-col bg-slate-900">
      <div className="flex items-center justify-between p-3 pt-[calc(0.75rem+env(safe-area-inset-top))] text-white">
        <button onClick={onCancel} className="rounded-full px-3 py-2 text-sm text-white/80">
          Cancel
        </button>
        <span className="text-sm font-semibold">Crop</span>
        <button onClick={() => setC(FULL)} className="rounded-full px-3 py-2 text-sm text-white/80">
          Reset
        </button>
      </div>
      <div className="grid min-h-0 flex-1 place-items-center p-8">
        {src ? (
          <div ref={box} className="relative max-h-full max-w-full select-none" style={{ touchAction: "none" }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={src} alt="" draggable={false} className="block max-h-[68dvh] max-w-full" />
            <div
              className="absolute border-2 border-white"
              style={{
                left: `${c.x * 100}%`,
                top: `${c.y * 100}%`,
                width: `${c.w * 100}%`,
                height: `${c.h * 100}%`,
                boxShadow: "0 0 0 9999px rgba(15,23,42,0.6)",
              }}
              onPointerDown={(e) => down(e, "move")}
              onPointerMove={move}
              onPointerUp={up}
            >
              {corners.map((k) => (
                <div
                  key={k.m}
                  className="absolute grid h-9 w-9 place-items-center"
                  style={k.s}
                  onPointerDown={(e) => down(e, k.m)}
                  onPointerMove={move}
                  onPointerUp={up}
                >
                  <div className="h-5 w-5 rounded-full border-[3px] border-white bg-indigo-500 shadow" />
                </div>
              ))}
            </div>
          </div>
        ) : (
          <Spinner />
        )}
      </div>
      <div className="p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
        <Btn className="w-full" onClick={() => onApply(c)}>
          <Icon name="check" size={18} /> Apply crop
        </Btn>
      </div>
    </div>
  );
}

/* ------------------------------ page editor ------------------------------ */

function PageEditor({
  page,
  index,
  total,
  onChange,
  onDelete,
  onClose,
}: {
  page: ScanPage;
  index: number;
  total: number;
  onChange: (p: Partial<ScanPage>) => void;
  onDelete: () => void;
  onClose: () => void;
}) {
  const [preview, setPreview] = useState("");
  const [cropping, setCropping] = useState(false);
  const key = `${page.rot}|${page.filter}|${page.crop.x}|${page.crop.y}|${page.crop.w}|${page.crop.h}`;

  useEffect(() => {
    let dead = false;
    processPage(page, 1300).then((c) => !dead && setPreview(c.toDataURL("image/jpeg", 0.85)));
    return () => {
      dead = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, page.url]);

  return (
    <div className="fixed inset-0 z-[65] flex flex-col bg-slate-900">
      <div className="flex items-center justify-between p-3 pt-[calc(0.75rem+env(safe-area-inset-top))] text-white">
        <button onClick={onClose} className="rounded-full p-2 active:bg-white/10" aria-label="Back">
          <Icon name="back" />
        </button>
        <span className="text-sm font-semibold">
          Page {index + 1} of {total}
        </span>
        <button onClick={onClose} className="rounded-full bg-indigo-600 px-4 py-2 text-sm font-semibold">
          Done
        </button>
      </div>
      <div className="grid min-h-0 flex-1 place-items-center p-4">
        {preview ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={preview} alt="Scan preview" className="max-h-full max-w-full rounded-lg object-contain shadow-2xl" />
        ) : (
          <Spinner />
        )}
      </div>
      <div className="space-y-3 bg-slate-900 p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
        <div className="flex justify-center gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => onChange({ filter: f.id })}
              className={`rounded-full px-3.5 py-2 text-xs font-semibold ${page.filter === f.id ? "bg-white text-slate-900" : "bg-white/10 text-white/80"}`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-2 text-white">
          {[
            { icon: "rotate", label: "Rotate", fn: () => onChange({ rot: (page.rot + 90) % 360, crop: FULL }) },
            { icon: "crop", label: "Crop", fn: () => setCropping(true) },
            { icon: "trash", label: "Delete", fn: onDelete },
          ].map((b) => (
            <button
              key={b.label}
              onClick={b.fn}
              className="flex flex-col items-center gap-1 rounded-2xl bg-white/10 py-3 text-xs font-medium active:bg-white/20"
            >
              <Icon name={b.icon} size={22} />
              {b.label}
            </button>
          ))}
        </div>
      </div>
      {cropping && (
        <CropView
          page={page}
          onCancel={() => setCropping(false)}
          onApply={(c) => {
            onChange({ crop: c });
            setCropping(false);
          }}
        />
      )}
    </div>
  );
}

/* ------------------------------ main ------------------------------ */

export default function Scanner({
  onEdit,
  toast,
  autoOpen,
}: {
  onEdit: (bytes: Uint8Array, name: string) => void;
  toast: (m: string) => void;
  autoOpen?: { mode: "camera" | "gallery"; n: number } | null;
}) {
  const [pages, setPages] = useState<ScanPage[]>([]);
  const [thumbs, setThumbs] = useState<Record<string, string>>({});
  const [camera, setCamera] = useState(false);
  const [editing, setEditing] = useState<number | null>(null);
  const [exportOpen, setExportOpen] = useState(false);
  const [name, setName] = useState("");
  const [fit, setFit] = useState<PageFit>("a4");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ bytes: Uint8Array; name: string } | null>(null);
  const [loading, setLoading] = useState(false);

  const gallery = useRef<HTMLInputElement>(null);
  const captureInput = useRef<HTMLInputElement>(null);
  const pagesRef = useRef<ScanPage[]>([]);
  pagesRef.current = pages;
  const thumbKeys = useRef<Record<string, string>>({});

  useEffect(
    () => () => {
      pagesRef.current.forEach((p) => URL.revokeObjectURL(p.url));
    },
    [],
  );

  // thumbnails
  useEffect(() => {
    pages.forEach((p) => {
      const k = `${p.rot}|${p.filter}|${p.crop.x}|${p.crop.y}|${p.crop.w}|${p.crop.h}`;
      if (thumbKeys.current[p.id] === k) return;
      thumbKeys.current[p.id] = k;
      thumbUrl(p).then((u) => setThumbs((t) => ({ ...t, [p.id]: u })));
    });
  }, [pages]);

  const addBlobs = useCallback(
    async (blobs: Blob[]) => {
      setLoading(true);
      try {
        const added: ScanPage[] = [];
        for (const b of blobs) {
          const { url, w, h } = await prepareImage(b);
          added.push({ id: uid(), url, w, h, rot: 0, crop: FULL, filter: "enhance" });
        }
        setPages((cur) => [...cur, ...added]);
      } catch {
        toast("Couldn't read that image");
      } finally {
        setLoading(false);
      }
    },
    [toast],
  );

  useEffect(() => {
    if (!autoOpen) return;
    if (autoOpen.mode === "camera") setCamera(true);
    else setTimeout(() => gallery.current?.click(), 50);
  }, [autoOpen]);

  const openExport = () => {
    const d = new Date();
    setName(
      `Scan ${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")} ${String(d.getHours()).padStart(2, "0")}${String(d.getMinutes()).padStart(2, "0")}`,
    );
    setDone(null);
    setExportOpen(true);
  };

  const create = async () => {
    setBusy(true);
    try {
      const bytes = await scansToPdf(pages, fit);
      const finalName = (name.trim() || "Scan") + ".pdf";
      const res = await savePdf(bytes, finalName);
      const filters = [...new Set(pages.map((p) => FILTERS.find((f) => f.id === p.filter)!.label))];
      await addHistory(
        {
          name: finalName,
          action: "scanned",
          pages: pages.length,
          details: [
            `Scanned ${pages.length} page${pages.length === 1 ? "" : "s"} into a PDF`,
            `Filter: ${filters.join(", ")}`,
            pages.some((p) => p.crop.w < 1 || p.crop.h < 1) ? "Pages were cropped" : "Full-frame pages",
          ],
        },
        bytes,
      );
      setDone({ bytes, name: finalName });
      toast(`Saved to ${res.where}`);
    } catch (e) {
      console.error(e);
      toast("Couldn't create the PDF");
    } finally {
      setBusy(false);
    }
  };

  const reset = () => {
    pages.forEach((p) => URL.revokeObjectURL(p.url));
    setPages([]);
    setThumbs({});
    thumbKeys.current = {};
    setExportOpen(false);
    setDone(null);
  };

  const update = (i: number, p: Partial<ScanPage>) =>
    setPages((cur) => cur.map((x, k) => (k === i ? { ...x, ...p } : x)));

  return (
    <div className="px-5 pb-40 pt-[calc(1.25rem+env(safe-area-inset-top))]">
      <h1 className="text-2xl font-bold tracking-tight">Scan to PDF</h1>
      <p className="mt-1 text-sm text-slate-500">Snap a document or pick photos. No ads, no sign-up, no watermark.</p>

      {pages.length === 0 ? (
        <div className="mt-8 rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-100">
          <div className="mx-auto grid h-24 w-24 place-items-center rounded-3xl bg-gradient-to-br from-indigo-500 to-violet-500 text-white shadow-lg shadow-indigo-500/30">
            <Icon name="scan" size={44} strokeWidth={1.6} />
          </div>
          <p className="mt-5 font-semibold">Nothing scanned yet</p>
          <p className="mt-1 text-sm text-slate-500">Take a photo or upload images to turn them into a PDF.</p>
          <div className="mt-6 grid gap-3">
            <Btn onClick={() => setCamera(true)}>
              <Icon name="camera" size={20} /> Open camera
            </Btn>
            <Btn variant="soft" onClick={() => gallery.current?.click()}>
              <Icon name="image" size={20} /> Upload from gallery
            </Btn>
          </div>
        </div>
      ) : (
        <>
          <div className="mt-5 grid grid-cols-2 gap-3">
            {pages.map((p, i) => (
              <button
                key={p.id}
                onClick={() => setEditing(i)}
                className="group relative aspect-[3/4] overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 active:scale-[0.98] transition"
              >
                {thumbs[p.id] ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={thumbs[p.id]} alt={`Page ${i + 1}`} className="h-full w-full object-contain" />
                ) : (
                  <div className="grid h-full place-items-center">
                    <div className="h-6 w-6 animate-spin rounded-full border-2 border-indigo-200 border-t-indigo-600" />
                  </div>
                )}
                <span className="absolute left-2 top-2 rounded-full bg-slate-900/70 px-2 py-0.5 text-xs font-medium text-white">
                  {i + 1}
                </span>
                <span className="absolute bottom-2 right-2 rounded-full bg-white/90 p-1.5 text-slate-700 shadow">
                  <Icon name="edit" size={14} />
                </span>
              </button>
            ))}
            <button
              onClick={() => setCamera(true)}
              className="grid aspect-[3/4] place-items-center rounded-2xl border-2 border-dashed border-indigo-200 bg-indigo-50/60 text-indigo-600 active:bg-indigo-50"
            >
              <span className="flex flex-col items-center gap-1 text-sm font-semibold">
                <Icon name="camera" size={28} /> Add page
              </span>
            </button>
          </div>
          <button
            onClick={() => gallery.current?.click()}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold text-indigo-700 active:bg-indigo-50"
          >
            <Icon name="image" size={18} /> Add from gallery
          </button>
          <div className="fixed inset-x-0 bottom-[calc(4.5rem+env(safe-area-inset-bottom))] z-30 mx-auto flex max-w-xl gap-3 px-5">
            <Btn variant="ghost" className="bg-white shadow-lg" onClick={reset}>
              <Icon name="trash" size={18} />
            </Btn>
            <Btn className="flex-1" onClick={openExport}>
              <Icon name="file" size={18} /> Create PDF · {pages.length} page{pages.length === 1 ? "" : "s"}
            </Btn>
          </div>
        </>
      )}

      {loading && (
        <div className="fixed inset-0 z-[80] grid place-items-center bg-white/60 backdrop-blur-sm">
          <Spinner label="Processing…" />
        </div>
      )}

      <input
        ref={gallery}
        type="file"
        accept="image/*"
        multiple
        hidden
        onChange={(e) => {
          const files = Array.from(e.target.files ?? []);
          if (files.length) addBlobs(files);
          e.target.value = "";
        }}
      />
      <input
        ref={captureInput}
        type="file"
        accept="image/*"
        capture="environment"
        hidden
        onChange={(e) => {
          const files = Array.from(e.target.files ?? []);
          if (files.length) addBlobs(files);
          e.target.value = "";
        }}
      />

      {camera && (
        <Camera
          count={pages.length}
          onShot={(b) => addBlobs([b])}
          onClose={() => setCamera(false)}
          onFallback={() => {
            setCamera(false);
            toast("Live camera isn't available — using the system camera");
            setTimeout(() => captureInput.current?.click(), 100);
          }}
        />
      )}

      {editing !== null && pages[editing] && (
        <PageEditor
          page={pages[editing]}
          index={editing}
          total={pages.length}
          onChange={(p) => update(editing, p)}
          onDelete={() => {
            URL.revokeObjectURL(pages[editing].url);
            setPages((cur) => cur.filter((_, k) => k !== editing));
            setEditing(null);
          }}
          onClose={() => setEditing(null)}
        />
      )}

      <Sheet open={exportOpen} onClose={() => !busy && setExportOpen(false)} title={done ? "PDF ready" : "Create PDF"}>
        {done ? (
          <div className="space-y-3 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-emerald-100 text-emerald-600">
              <Icon name="check" size={28} strokeWidth={2.4} />
            </div>
            <p className="font-semibold">{done.name}</p>
            <p className="text-sm text-slate-500">Saved and added to your History.</p>
            <div className="grid grid-cols-2 gap-2.5 pt-2">
              <Btn variant="soft" onClick={reset}>
                New scan
              </Btn>
              <Btn
                onClick={() => {
                  onEdit(done.bytes, done.name);
                  reset();
                }}
              >
                <Icon name="edit" size={18} /> Edit PDF
              </Btn>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-400">File name</label>
              <div className="flex items-center rounded-2xl border border-slate-200 bg-slate-50 px-4 focus-within:border-indigo-400 focus-within:ring-4 focus-within:ring-indigo-100">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-transparent py-3.5 outline-none"
                />
                <span className="text-sm text-slate-400">.pdf</span>
              </div>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-400">Page size</label>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    ["a4", "A4 page"],
                    ["fit", "Fit to photo"],
                  ] as const
                ).map(([id, label]) => (
                  <button
                    key={id}
                    onClick={() => setFit(id)}
                    className={`rounded-2xl border-2 py-3 text-sm font-semibold ${fit === id ? "border-indigo-500 bg-indigo-50 text-indigo-700" : "border-slate-200 text-slate-600"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
            <Btn className="w-full" onClick={create} disabled={busy}>
              <Icon name="download" size={18} /> {busy ? "Creating…" : "Create & download"}
            </Btn>
          </div>
        )}
      </Sheet>
    </div>
  );
}
