# Folio – PDF editor, scanner & templates

React + Vite + Tailwind app, packaged for Android with Capacitor.

* Open & edit PDFs (text, images, drawing, signature, highlight, whiteout, shapes, page management)
* 48 templates: Resume, Certificate, Invoice, Letter, Flyer, Report Cover (8 each)
* Camera scanner + images → PDF (crop, rotate, filters), ad-free
* "My images" library for logos / client photos, history of every action

See **APK_GUIDE.md** for the step-by-step guide to build the APK from a phone using GitHub Actions.

```bash
npm install
npm run dev     # develop
npm run build   # production build -> dist/
```
