import type { PDFDocumentProxy } from "pdfjs-dist";

export type FontKey = "helv" | "times" | "cour";

interface Base {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  locked?: boolean;
}
export interface TextEl extends Base {
  type: "text";
  text: string;
  size: number;
  color: string;
  font: FontKey;
  bold?: boolean;
  italic?: boolean;
  align: "left" | "center" | "right";
  opacity?: number;
}
export interface ShapeEl extends Base {
  type: "rect" | "ellipse";
  fill: string | null;
  stroke: string | null;
  strokeW: number;
  opacity: number;
}
export interface ImageEl extends Base {
  type: "image";
  src?: string;
  placeholder?: string;
  shape: "rect" | "circle";
  opacity: number;
  lockAspect?: boolean;
  ratio?: number; // h / w of the original picture
}
export interface DrawEl extends Base {
  type: "draw";
  points: [number, number][]; // normalised 0..1 inside the box
  color: string;
  width: number;
  opacity: number;
}
export type El = TextEl | ShapeEl | ImageEl | DrawEl;

export interface Page {
  id: string;
  srcIndex: number | null;
  width: number;
  height: number;
  bg: string;
  elements: El[];
}

export interface DocSource {
  bytes: Uint8Array;
  pdf: PDFDocumentProxy;
}

export interface Session {
  id: string;
  name: string;
  kind: "pdf" | "template" | "scan" | "blank";
  pages: Page[];
  source: DocSource | null;
}

export interface LoadedImage {
  src: string;
  w: number;
  h: number;
  name: string;
}

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
