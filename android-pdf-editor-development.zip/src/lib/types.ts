import type { PDFDocumentProxy } from "pdfjs-dist";

export type FontKey = "sans" | "serif" | "mono";

export type AnnLabel =
  | "Text"
  | "Drawing"
  | "Highlight"
  | "White-out"
  | "Shape"
  | "Image"
  | "Signature"
  | "Stamp";

type Base = {
  id: string;
  pageId: string;
  label: AnnLabel;
  /** original text of a template field – used to detect "filled" fields */
  tplText?: string;
};

export type TextAnn = Base & {
  type: "text";
  x: number;
  y: number;
  text: string;
  size: number;
  color: string;
  bold: boolean;
  font: FontKey;
};

export type RectAnn = Base & {
  type: "rect";
  x: number;
  y: number;
  w: number;
  h: number;
  fill: string | null;
  stroke: string | null;
  strokeWidth: number;
  opacity: number;
};

export type InkAnn = Base & {
  type: "ink";
  points: [number, number][];
  color: string;
  width: number;
};

export type ImageAnn = Base & {
  type: "image";
  x: number;
  y: number;
  w: number;
  h: number;
  dataUrl: string;
};

export type Ann = TextAnn | RectAnn | InkAnn | ImageAnn;

export type Tool = "select" | "text" | "draw" | "highlight" | "whiteout" | "shape";

/** A loaded PDF file we can pull pages from. */
export type Source = {
  name: string;
  bytes: Uint8Array;
  doc: PDFDocumentProxy;
  dims: [number, number][]; // displayed size (pt) of each page at rotation 0
};

export type PageState = {
  id: string;
  /** null = blank page */
  src: { doc: number; index: number } | null;
  /** extra user rotation (0/90/180/270), added on top of the page's own rotation */
  rot: number;
  /** displayed size at user rotation 0 */
  bw: number;
  bh: number;
};

export type EditorInit = {
  name: string;
  sources: Source[];
  pages: PageState[];
  anns: Ann[];
  templateName?: string;
};

export type HistoryEntry = {
  id: string;
  ts: number;
  name: string;
  action: "edited" | "created" | "scanned" | "merged";
  details: string[];
  pages: number;
  size: number;
};

export const uid = () =>
  Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);

export const pageDims = (p: PageState): [number, number] =>
  p.rot % 180 === 0 ? [p.bw, p.bh] : [p.bh, p.bw];
