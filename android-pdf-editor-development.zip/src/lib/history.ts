import type { HistoryEntry } from "./types";
import { uid } from "./types";

const KEY = "pdfstudio.history.v1";
const DB = "pdfstudio";
const STORE = "files";

/* History entries live in localStorage; the PDF files themselves in IndexedDB
 * so a past version can be re-opened or downloaded again. Everything stays on
 * the device. */

export function listHistory(): HistoryEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    const arr = raw ? (JSON.parse(raw) as HistoryEntry[]) : [];
    return arr.sort((a, b) => b.ts - a.ts);
  } catch {
    return [];
  }
}

function write(list: HistoryEntry[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
  } catch {
    /* storage full */
  }
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idb<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, mode);
    const req = fn(tx.objectStore(STORE));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function addHistory(
  entry: Omit<HistoryEntry, "id" | "ts" | "size">,
  bytes: Uint8Array,
): Promise<HistoryEntry> {
  const full: HistoryEntry = { ...entry, id: uid(), ts: Date.now(), size: bytes.length };
  write([full, ...listHistory()].slice(0, 200));
  try {
    await idb("readwrite", (s) => s.put(new Blob([bytes as BlobPart]), full.id));
  } catch {
    /* file copy is optional */
  }
  return full;
}

export async function getHistoryFile(id: string): Promise<Uint8Array | null> {
  try {
    const blob = await idb<Blob | undefined>("readonly", (s) => s.get(id));
    if (!blob) return null;
    return new Uint8Array(await blob.arrayBuffer());
  } catch {
    return null;
  }
}

export async function removeHistory(id: string) {
  write(listHistory().filter((h) => h.id !== id));
  try {
    await idb("readwrite", (s) => s.delete(id));
  } catch {
    /* ignore */
  }
}

export async function clearHistory() {
  write([]);
  try {
    await idb("readwrite", (s) => s.clear());
  } catch {
    /* ignore */
  }
}
