import type { Ann, EditorInit, PageState, TextAnn, RectAnn } from "./types";
import { uid } from "./types";

export type Template = {
  id: string;
  name: string;
  desc: string;
  accent: string; // card tint
  w: number;
  h: number;
  build: (pageId: string) => Ann[];
};

const A4: [number, number] = [595, 842];
const A4L: [number, number] = [842, 595];

type TOpts = Partial<Pick<TextAnn, "size" | "color" | "bold" | "font">>;

function maker(pageId: string) {
  const text = (x: number, y: number, t: string, o: TOpts = {}): TextAnn => ({
    id: uid(),
    pageId,
    type: "text",
    label: "Text",
    x,
    y,
    text: t,
    size: o.size ?? 12,
    color: o.color ?? "#1f2937",
    bold: o.bold ?? false,
    font: o.font ?? "sans",
    tplText: t,
  });
  const rect = (
    x: number,
    y: number,
    w: number,
    h: number,
    fill: string | null,
    stroke: string | null = null,
  ): RectAnn => ({
    id: uid(),
    pageId,
    type: "rect",
    label: "Shape",
    x,
    y,
    w,
    h,
    fill,
    stroke,
    strokeWidth: 1,
    opacity: 1,
    tplText: "",
  });
  const line = (x: number, y: number, w: number, color = "#cbd5e1") => rect(x, y, w, 1, color);
  return { text, rect, line };
}

const INDIGO = "#4f46e5";

export const templates: Template[] = [
  {
    id: "invoice",
    name: "Invoice",
    desc: "Bill a client",
    accent: "from-indigo-500 to-violet-500",
    w: A4[0],
    h: A4[1],
    build(pid) {
      const { text, rect, line } = maker(pid);
      const a: Ann[] = [
        rect(0, 0, 595, 110, INDIGO),
        text(40, 36, "INVOICE", { size: 34, bold: true, color: "#ffffff" }),
        text(400, 40, "Invoice #  0001", { size: 12, color: "#e0e7ff" }),
        text(400, 58, "Date  DD / MM / YYYY", { size: 12, color: "#e0e7ff" }),
        text(40, 140, "FROM", { size: 10, bold: true, color: "#6b7280" }),
        text(40, 156, "Your Company Name\nStreet address\nCity, Country\nemail@company.com", { size: 12 }),
        text(330, 140, "BILL TO", { size: 10, bold: true, color: "#6b7280" }),
        text(330, 156, "Client Name\nClient address\nCity, Country", { size: 12 }),
        rect(40, 260, 515, 26, "#eef2ff"),
        text(50, 267, "Description", { size: 11, bold: true, color: INDIGO }),
        text(330, 267, "Qty", { size: 11, bold: true, color: INDIGO }),
        text(400, 267, "Price", { size: 11, bold: true, color: INDIGO }),
        text(490, 267, "Total", { size: 11, bold: true, color: INDIGO }),
      ];
      for (let i = 0; i < 6; i++) {
        const y = 298 + i * 32;
        a.push(text(50, y, i === 0 ? "Item or service" : "", { size: 12 }));
        a.push(line(40, y + 24, 515));
      }
      a.push(
        text(400, 510, "Subtotal", { size: 12, color: "#6b7280" }),
        text(490, 510, "0.00", { size: 12 }),
        text(400, 532, "Tax", { size: 12, color: "#6b7280" }),
        text(490, 532, "0.00", { size: 12 }),
        rect(390, 556, 165, 32, INDIGO),
        text(400, 565, "TOTAL", { size: 13, bold: true, color: "#ffffff" }),
        text(490, 565, "0.00", { size: 13, bold: true, color: "#ffffff" }),
        text(40, 640, "NOTES", { size: 10, bold: true, color: "#6b7280" }),
        text(40, 656, "Payment due within 14 days.\nBank details / payment instructions here.", { size: 12 }),
        text(40, 780, "Thank you for your business!", { size: 12, bold: true, color: INDIGO }),
      );
      return a;
    },
  },
  {
    id: "resume",
    name: "Resume",
    desc: "Clean one-pager",
    accent: "from-sky-500 to-cyan-500",
    w: A4[0],
    h: A4[1],
    build(pid) {
      const { text, rect, line } = maker(pid);
      const sec = (y: number, t: string) => [
        text(40, y, t, { size: 12, bold: true, color: "#0369a1" }),
        line(40, y + 18, 515, "#7dd3fc"),
      ];
      return [
        rect(0, 0, 595, 8, "#0ea5e9"),
        text(40, 36, "Your Name", { size: 32, bold: true, color: "#0f172a" }),
        text(40, 78, "Professional Title", { size: 15, color: "#0369a1" }),
        text(40, 102, "email@example.com  •  +00 000 000 000  •  City, Country", { size: 10.5, color: "#64748b" }),
        ...sec(140, "SUMMARY"),
        text(40, 168, "Two or three lines about who you are and what you do best.", { size: 11 }),
        ...sec(220, "EXPERIENCE"),
        text(40, 248, "Job Title — Company", { size: 12, bold: true }),
        text(430, 249, "2022 – Present", { size: 10.5, color: "#64748b" }),
        text(40, 268, "•  Key achievement with a measurable result\n•  Another responsibility or project", { size: 11 }),
        text(40, 332, "Job Title — Company", { size: 12, bold: true }),
        text(430, 333, "2019 – 2022", { size: 10.5, color: "#64748b" }),
        text(40, 352, "•  Key achievement with a measurable result\n•  Another responsibility or project", { size: 11 }),
        ...sec(430, "EDUCATION"),
        text(40, 458, "Degree — University", { size: 12, bold: true }),
        text(430, 459, "2015 – 2019", { size: 10.5, color: "#64748b" }),
        ...sec(520, "SKILLS"),
        text(40, 548, "Skill one  •  Skill two  •  Skill three  •  Skill four", { size: 11 }),
        ...sec(600, "LANGUAGES"),
        text(40, 628, "English  •  Another language", { size: 11 }),
      ];
    },
  },
  {
    id: "letter",
    name: "Letter",
    desc: "Formal letter",
    accent: "from-amber-400 to-orange-500",
    w: A4[0],
    h: A4[1],
    build(pid) {
      const { text } = maker(pid);
      return [
        text(60, 60, "Your Name\nYour address\nCity, Country", { size: 12, bold: false }),
        text(400, 60, "DD Month YYYY", { size: 12 }),
        text(60, 160, "Recipient Name\nRecipient address\nCity, Country", { size: 12 }),
        text(60, 250, "Subject: Write the subject here", { size: 12, bold: true }),
        text(60, 290, "Dear Recipient,", { size: 12 }),
        text(
          60,
          320,
          "Write the opening of your letter here.\n\nUse a new text box for each paragraph\nor edit this one to fit your message.",
          { size: 12 },
        ),
        text(60, 560, "Sincerely,", { size: 12 }),
        text(60, 640, "Your Name", { size: 12, bold: true }),
      ];
    },
  },
  {
    id: "meeting",
    name: "Meeting Notes",
    desc: "Agenda & actions",
    accent: "from-emerald-500 to-teal-500",
    w: A4[0],
    h: A4[1],
    build(pid) {
      const { text, rect, line } = maker(pid);
      const a: Ann[] = [
        text(40, 36, "Meeting Notes", { size: 28, bold: true, color: "#065f46" }),
        line(40, 80, 515, "#6ee7b7"),
        text(40, 94, "Topic:  ", { size: 12, bold: true }),
        text(40, 114, "Date:  DD / MM / YYYY", { size: 12 }),
        text(300, 114, "Attendees:  Name, Name", { size: 12 }),
        rect(40, 154, 515, 24, "#d1fae5"),
        text(50, 159, "AGENDA", { size: 11, bold: true, color: "#065f46" }),
        text(50, 190, "1.  \n2.  \n3.  ", { size: 12 }),
        rect(40, 280, 515, 24, "#d1fae5"),
        text(50, 285, "NOTES", { size: 11, bold: true, color: "#065f46" }),
      ];
      for (let i = 0; i < 7; i++) a.push(line(50, 340 + i * 28, 495));
      a.push(
        rect(40, 560, 515, 24, "#d1fae5"),
        text(50, 565, "ACTION ITEMS", { size: 11, bold: true, color: "#065f46" }),
        text(50, 596, "☐".replace("☐", "[ ]") + "  Task — owner — due date", { size: 12 }),
        text(50, 624, "[ ]  Task — owner — due date", { size: 12 }),
        text(50, 652, "[ ]  Task — owner — due date", { size: 12 }),
      );
      return a;
    },
  },
  {
    id: "receipt",
    name: "Receipt",
    desc: "Proof of payment",
    accent: "from-pink-500 to-rose-500",
    w: A4[0],
    h: A4[1],
    build(pid) {
      const { text, rect, line } = maker(pid);
      const a: Ann[] = [
        text(40, 40, "RECEIPT", { size: 30, bold: true, color: "#be123c" }),
        text(40, 80, "Your Business Name", { size: 13, bold: true }),
        text(40, 98, "Address  •  Phone  •  Email", { size: 10.5, color: "#6b7280" }),
        text(400, 44, "Receipt No.  0001", { size: 12 }),
        text(400, 62, "Date  DD / MM / YYYY", { size: 12 }),
        line(40, 130, 515, "#fecdd3"),
        text(40, 148, "Received from:", { size: 12, bold: true }),
        text(150, 148, "Customer name", { size: 12 }),
        text(40, 176, "Payment method:", { size: 12, bold: true }),
        text(150, 176, "Cash / Card / Transfer", { size: 12 }),
        rect(40, 220, 515, 26, "#ffe4e6"),
        text(50, 227, "Item", { size: 11, bold: true, color: "#be123c" }),
        text(470, 227, "Amount", { size: 11, bold: true, color: "#be123c" }),
      ];
      for (let i = 0; i < 5; i++) {
        a.push(text(50, 258 + i * 30, i === 0 ? "Description" : "", { size: 12 }));
        a.push(text(470, 258 + i * 30, i === 0 ? "0.00" : "", { size: 12 }));
        a.push(line(40, 280 + i * 30, 515, "#ffe4e6"));
      }
      a.push(
        rect(380, 430, 175, 34, "#be123c"),
        text(392, 440, "TOTAL PAID   0.00", { size: 13, bold: true, color: "#ffffff" }),
        text(40, 520, "Signature", { size: 11, color: "#6b7280" }),
        line(40, 515, 200, "#9ca3af"),
      );
      return a;
    },
  },
  {
    id: "certificate",
    name: "Certificate",
    desc: "Award or thanks",
    accent: "from-yellow-400 to-amber-600",
    w: A4L[0],
    h: A4L[1],
    build(pid) {
      const { text, rect, line } = maker(pid);
      return [
        rect(20, 20, 802, 555, null, "#b45309"),
        rect(32, 32, 778, 531, null, "#f59e0b"),
        text(421 - 215, 90, "CERTIFICATE", { size: 52, bold: true, font: "serif", color: "#92400e" }),
        text(421 - 105, 156, "OF ACHIEVEMENT", { size: 22, font: "serif", color: "#b45309" }),
        text(421 - 100, 225, "This certificate is proudly presented to", { size: 14, font: "serif", color: "#57534e" }),
        text(421 - 140, 265, "Recipient Name", { size: 42, font: "serif", bold: true, color: "#1c1917" }),
        line(221, 322, 400, "#b45309"),
        text(421 - 215, 345, "for outstanding performance and dedication.", { size: 16, font: "serif", color: "#57534e" }),
        text(110, 470, "DD / MM / YYYY", { size: 13, font: "serif" }),
        line(90, 462, 200, "#78716c"),
        text(110, 485, "Date", { size: 11, color: "#78716c" }),
        text(560, 470, "Authorised Name", { size: 13, font: "serif" }),
        line(540, 462, 210, "#78716c"),
        text(560, 485, "Signature", { size: 11, color: "#78716c" }),
      ];
    },
  },
  {
    id: "checklist",
    name: "Checklist",
    desc: "To-do list",
    accent: "from-fuchsia-500 to-purple-600",
    w: A4[0],
    h: A4[1],
    build(pid) {
      const { text, rect, line } = maker(pid);
      const a: Ann[] = [
        text(40, 40, "Checklist", { size: 30, bold: true, color: "#6b21a8" }),
        text(40, 84, "Date:  DD / MM / YYYY", { size: 12, color: "#6b7280" }),
        line(40, 112, 515, "#e9d5ff"),
      ];
      for (let i = 0; i < 16; i++) {
        const y = 134 + i * 42;
        a.push(rect(44, y, 18, 18, null, "#a855f7"));
        a.push(text(78, y + 1, i === 0 ? "First task" : "", { size: 14 }));
        a.push(line(78, y + 24, 477, "#f3e8ff"));
      }
      return a;
    },
  },
  {
    id: "blank",
    name: "Blank A4",
    desc: "Start from scratch",
    accent: "from-slate-400 to-slate-600",
    w: A4[0],
    h: A4[1],
    build: () => [],
  },
];

export function editorInitFromTemplate(t: Template): EditorInit {
  const id = uid();
  const page: PageState = { id, src: null, rot: 0, bw: t.w, bh: t.h };
  return {
    name: t.id === "blank" ? "Untitled" : t.name,
    sources: [],
    pages: [page],
    anns: t.build(id),
    templateName: t.id === "blank" ? undefined : t.name,
  };
}
