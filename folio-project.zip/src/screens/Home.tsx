import { useRef } from "react";
import { Award, BookOpen, Camera, ChevronRight, FilePlus2, FileText, FolderOpen, ImagePlus, Mail, Megaphone, Receipt, Smartphone, Sparkles, UserSquare2 } from "lucide-react";
import { Thumb } from "./TemplatesScreen";
import { CATEGORIES, CatKey, TEMPLATES } from "../lib/templates";
import { HistoryItem, useHistory } from "../lib/storage";
import { fmtDay, fmtTime } from "../components/ui";
import { isNative } from "../lib/pdf";

export const CAT_ICON: Record<CatKey, React.ReactNode> = {
  resume: <UserSquare2 size={18} />,
  certificate: <Award size={18} />,
  invoice: <Receipt size={18} />,
  letter: <Mail size={18} />,
  flyer: <Megaphone size={18} />,
  report: <BookOpen size={18} />,
};

export const ACTION_META: Record<HistoryItem["action"], { label: string; color: string }> = {
  opened: { label: "Opened", color: "bg-sky-100 text-sky-700" },
  created: { label: "Created from template", color: "bg-violet-100 text-violet-700" },
  scanned: { label: "Scanned", color: "bg-amber-100 text-amber-700" },
  edited: { label: "Edited", color: "bg-indigo-100 text-indigo-700" },
  exported: { label: "Saved PDF", color: "bg-emerald-100 text-emerald-700" },
};

export default function Home({ onOpenPdf, onScan, onBlank, onCategory, onGuide, onHistory }: {
  onOpenPdf: (f: File) => void; onScan: (m: "camera" | "gallery") => void; onBlank: () => void; onCategory: (c: CatKey) => void; onGuide: () => void; onHistory: () => void;
}) {
  const file = useRef<HTMLInputElement>(null);
  const history = useHistory().slice(0, 3);
  return (
    <div className="px-5 pt-5 pb-32 max-w-xl mx-auto safe-top">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl grad shadow-lg shadow-indigo-200 flex items-center justify-center text-white"><FileText size={22} /></div>
          <div>
            <div className="text-xl font-extrabold tracking-tight leading-none">Folio</div>
            <div className="text-xs text-slate-500 mt-1">PDF editor & scanner · no ads</div>
          </div>
        </div>
        {!isNative() && (
          <button onClick={onGuide} className="h-10 px-3.5 rounded-full bg-white shadow-sm text-xs font-semibold text-indigo-600 flex items-center gap-1.5"><Smartphone size={15} /> Get APK</button>
        )}
      </div>

      <input ref={file} type="file" accept="application/pdf,.pdf" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onOpenPdf(f); e.target.value = ""; }} />

      <button onClick={() => file.current?.click()} className="mt-6 w-full text-left rounded-[28px] grad text-white p-6 shadow-xl shadow-indigo-200 relative overflow-hidden active:scale-[.99] transition">
        <div className="absolute -right-8 -top-10 w-44 h-44 rounded-full bg-white/10" />
        <div className="absolute right-10 -bottom-16 w-40 h-40 rounded-full bg-white/10" />
        <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center mb-4"><FolderOpen /></div>
        <div className="text-2xl font-bold">Open a PDF</div>
        <div className="text-white/80 text-sm mt-1 max-w-[16rem]">Add text, pictures, signatures, highlights and more. Then save it.</div>
        <div className="mt-4 inline-flex items-center gap-1 text-sm font-semibold bg-white text-indigo-600 rounded-full px-4 h-9">Choose file <ChevronRight size={16} /></div>
      </button>

      <div className="grid grid-cols-3 gap-3 mt-4">
        {[
          { l: "Scan", i: <Camera />, c: "bg-amber-100 text-amber-600", f: () => onScan("camera") },
          { l: "Images → PDF", i: <ImagePlus />, c: "bg-sky-100 text-sky-600", f: () => onScan("gallery") },
          { l: "Blank page", i: <FilePlus2 />, c: "bg-emerald-100 text-emerald-600", f: onBlank },
        ].map((a) => (
          <button key={a.l} onClick={a.f} className="bg-white rounded-3xl p-3.5 shadow-sm flex flex-col items-center gap-2 text-xs font-semibold text-slate-700 active:scale-95 transition">
            <div className={"w-12 h-12 rounded-2xl flex items-center justify-center " + a.c}>{a.i}</div>
            {a.l}
          </button>
        ))}
      </div>

      <div className="flex items-center justify-between mt-8 mb-3">
        <h2 className="font-bold text-lg flex items-center gap-2"><Sparkles size={18} className="text-violet-500" /> Templates</h2>
        <span className="text-xs text-slate-400">{TEMPLATES.length} designs</span>
      </div>
      <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-5 px-5 pb-2">
        {CATEGORIES.map((c) => {
          const t = TEMPLATES.find((x) => x.cat === c.key)!;
          return (
            <button key={c.key} onClick={() => onCategory(c.key)} className="w-36 shrink-0 bg-white rounded-3xl p-2.5 shadow-sm text-left active:scale-95 transition">
              <div className="rounded-2xl overflow-hidden bg-slate-100 ring-1 ring-black/5 h-36 relative"><Thumb t={t} /></div>
              <div className="flex items-center gap-1.5 mt-2.5 px-1 font-semibold text-sm text-slate-800">{CAT_ICON[c.key]} {c.label}</div>
              <div className="text-[11px] text-slate-400 px-1 pb-1">{TEMPLATES.filter((x) => x.cat === c.key).length} templates</div>
            </button>
          );
        })}
      </div>

      <div className="flex items-center justify-between mt-8 mb-3">
        <h2 className="font-bold text-lg">Recent activity</h2>
        {history.length > 0 && <button onClick={onHistory} className="text-sm font-semibold text-indigo-600">See all</button>}
      </div>
      {history.length === 0 ? (
        <div className="bg-white rounded-3xl p-6 text-center text-sm text-slate-400 shadow-sm">Nothing yet. Everything you open, scan, edit and save shows up here.</div>
      ) : (
        <div className="space-y-2.5">
          {history.map((h) => (
            <button key={h.id} onClick={onHistory} className="w-full bg-white rounded-2xl p-3.5 shadow-sm flex items-center gap-3 text-left">
              <div className={"text-[10px] font-bold uppercase tracking-wide px-2 py-1 rounded-lg shrink-0 " + ACTION_META[h.action].color}>{h.action}</div>
              <div className="min-w-0 flex-1">
                <div className="font-semibold text-sm truncate">{h.doc}</div>
                <div className="text-xs text-slate-400 truncate">{fmtDay(h.ts)}, {fmtTime(h.ts)} · {h.details.slice(0, 2).join(", ")}</div>
              </div>
              <ChevronRight size={16} className="text-slate-300" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
