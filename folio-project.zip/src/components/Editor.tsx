import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlignCenter, AlignLeft, AlignRight, ArrowDown, ArrowUp, Bold, ChevronDown, ChevronLeft, ChevronUp, Circle, Copy, Download, Eraser, FilePlus2,
  Highlighter, ImagePlus, Italic, Layers, Loader2, Minus, MousePointer2, Pencil, PenLine, Plus, Redo2, Share2, Square, Trash2, Type, Undo2, CheckCircle2, Replace,
} from "lucide-react";
import { FitPage, PageView, Tool } from "./PageView";
import { ImagePicker } from "./ImagePicker";
import { Sheet, Swatches, toast } from "./ui";
import { fitTextHeight } from "../lib/fonts";
import { exportPdf, safeName, saveBytes, shareBytes, blankPage } from "../lib/pdf";
import { addHistory, addToLibrary, storeFile } from "../lib/storage";
import { useBack } from "../lib/nav";
import { DrawEl, El, ImageEl, LoadedImage, Page, Session, ShapeEl, TextEl, uid } from "../lib/types";

const norm = (e: El): El => (e.type === "text" ? { ...e, h: fitTextHeight(e) } : e);
const mapEl = (pages: Page[], pageId: string, id: string, patch: Partial<El>) =>
  pages.map((p) => (p.id !== pageId ? p : { ...p, elements: p.elements.map((e) => (e.id !== id ? e : norm({ ...e, ...patch } as El))) }));

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

function Chip({ active, onClick, children, title, className = "" }: { active?: boolean; onClick: () => void; children: React.ReactNode; title?: string; className?: string }) {
  return (
    <button title={title} onClick={onClick} className={`h-10 min-w-10 px-2.5 rounded-xl flex items-center justify-center text-sm font-semibold shrink-0 active:scale-95 transition ${active ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-700"} ${className}`}>
      {children}
    </button>
  );
}

function Slider({ label, value, min, max, onChange, onEnd }: { label: string; value: number; min: number; max: number; onChange: (v: number) => void; onEnd: () => void }) {
  return (
    <label className="flex items-center gap-2 text-xs shrink-0 opacity-90">
      {label}
      <input type="range" min={min} max={max} value={value} className="w-28 accent-indigo-600" onChange={(e) => onChange(+e.target.value)} onPointerUp={onEnd} onTouchEnd={onEnd} onKeyUp={onEnd} />
    </label>
  );
}

const TOOLS: { id: Tool | "image" | "sign" | "pages"; label: string; icon: React.ReactNode }[] = [
  { id: "select", label: "Select", icon: <MousePointer2 size={20} /> },
  { id: "text", label: "Text", icon: <Type size={20} /> },
  { id: "image", label: "Image", icon: <ImagePlus size={20} /> },
  { id: "draw", label: "Draw", icon: <Pencil size={20} /> },
  { id: "sign", label: "Sign", icon: <PenLine size={20} /> },
  { id: "rect", label: "Box", icon: <Square size={20} /> },
  { id: "ellipse", label: "Circle", icon: <Circle size={20} /> },
  { id: "line", label: "Line", icon: <Minus size={20} /> },
  { id: "highlight", label: "Highlight", icon: <Highlighter size={20} /> },
  { id: "whiteout", label: "Whiteout", icon: <Eraser size={20} /> },
  { id: "pages", label: "Pages", icon: <Layers size={20} /> },
];

const HINTS: Partial<Record<Tool, string>> = {
  text: "Tap on the page where the text should go",
  rect: "Tap on the page to place a box",
  ellipse: "Tap on the page to place a circle",
  line: "Tap on the page to place a line",
  highlight: "Tap on the page to place a highlight",
  whiteout: "Tap over old text to cover it, then add new text",
  draw: "Draw with your finger. Tap Done when finished",
};

function SignaturePad({ open, onClose, onDone }: { open: boolean; onClose: () => void; onDone: (src: string, w: number, h: number) => void }) {
  const cv = useRef<HTMLCanvasElement>(null);
  const st = useRef<{ drawing: boolean; last: [number, number] | null; box: [number, number, number, number] }>({ drawing: false, last: null, box: [1e9, 1e9, -1, -1] });
  const [ink, setInk] = useState("#111827");
  const [has, setHas] = useState(false);
  const pos = (e: React.PointerEvent): [number, number] => {
    const r = cv.current!.getBoundingClientRect();
    return [((e.clientX - r.left) / r.width) * cv.current!.width, ((e.clientY - r.top) / r.height) * cv.current!.height];
  };
  const clear = () => {
    const c = cv.current;
    c?.getContext("2d")!.clearRect(0, 0, c.width, c.height);
    st.current.box = [1e9, 1e9, -1, -1];
    setHas(false);
  };
  return (
    <Sheet open={open} onClose={onClose} title="Draw your signature">
      <canvas
        ref={cv}
        width={900}
        height={380}
        className="w-full rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50 touch-none"
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          st.current.drawing = true;
          st.current.last = pos(e);
        }}
        onPointerMove={(e) => {
          const s = st.current;
          if (!s.drawing || !s.last) return;
          const c = cv.current!.getContext("2d")!;
          const p = pos(e);
          c.strokeStyle = ink;
          c.lineWidth = 7;
          c.lineCap = "round";
          c.beginPath();
          c.moveTo(...s.last);
          c.lineTo(...p);
          c.stroke();
          s.last = p;
          s.box = [Math.min(s.box[0], p[0]), Math.min(s.box[1], p[1]), Math.max(s.box[2], p[0]), Math.max(s.box[3], p[1])];
          if (!has) setHas(true);
        }}
        onPointerUp={() => {
          st.current.drawing = false;
          st.current.last = null;
        }}
      />
      <div className="flex items-center justify-between mt-3">
        <div className="flex gap-2">
          {["#111827", "#1d4ed8", "#b91c1c"].map((c) => (
            <button key={c} onClick={() => setInk(c)} style={{ background: c }} className={"w-8 h-8 rounded-full border-2 " + (ink === c ? "border-indigo-400 scale-110" : "border-white shadow")} />
          ))}
        </div>
        <button onClick={clear} className="text-sm text-slate-500 px-3 py-2">Clear</button>
      </div>
      <button
        disabled={!has}
        onClick={() => {
          const c = cv.current!;
          const [x0, y0, x1, y1] = st.current.box;
          const pad = 8;
          const sx = Math.max(0, x0 - pad), sy = Math.max(0, y0 - pad);
          const w = Math.min(c.width, x1 + pad) - sx, h = Math.min(c.height, y1 + pad) - sy;
          const o = document.createElement("canvas");
          o.width = w;
          o.height = h;
          o.getContext("2d")!.drawImage(c, sx, sy, w, h, 0, 0, w, h);
          onDone(o.toDataURL("image/png"), w, h);
          clear();
        }}
        className="mt-3 w-full h-12 rounded-2xl grad text-white font-semibold disabled:opacity-40"
      >
        Add signature
      </button>
    </Sheet>
  );
}

export default function Editor({ session, onClose }: { session: Session; onClose: () => void }) {
  const { source } = session;
  const [name, setName] = useState(session.name);
  const [st, setSt] = useState<{ pages: Page[]; past: Page[][]; future: Page[][] }>({ pages: session.pages, past: [], future: [] });
  const pages = st.pages;
  const pagesRef = useRef(pages);
  pagesRef.current = pages;
  const base = useRef<Page[] | null>(null);
  const ops = useRef<string[]>([]);

  const [selected, setSelected] = useState<{ pageId: string; id: string } | null>(null);
  const [tool, setTool] = useState<Tool>("select");
  const toolRef = useRef(tool);
  toolRef.current = tool;
  const [zoom, setZoom] = useState(1);
  const [activeId, setActiveId] = useState(session.pages[0]?.id ?? "");
  const activeRef = useRef(activeId);
  activeRef.current = activeId;
  const [drawColor, setDrawColor] = useState("#111827");
  const [drawWidth, setDrawWidth] = useState(3);
  const drawColorRef = useRef(drawColor);
  drawColorRef.current = drawColor;
  const drawWidthRef = useRef(drawWidth);
  drawWidthRef.current = drawWidth;
  const shapeColor = "#4f46e5";
  const [panelOpen, setPanelOpen] = useState(true);
  const [sheet, setSheet] = useState<null | "pages" | "image" | "sign" | "pagepic">(null);
  const [target, setTarget] = useState<{ pageId: string; id: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ bytes: Uint8Array; filename: string; where: string } | null>(null);
  const [cw, setCw] = useState(360);
  const scroller = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLTextAreaElement>(null);
  const [focusText, setFocusText] = useState(0);

  useEffect(() => {
    const el = scroller.current!;
    const ro = new ResizeObserver(() => setCw(el.clientWidth));
    ro.observe(el);
    setCw(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const baseW = useMemo(() => Math.max(...pages.map((p) => p.width)), [pages]);
  const s = Math.max(0.2, ((cw - 40) / baseW) * zoom);

  /* ---------- history ---------- */
  const live = useCallback((pageId: string, id: string, patch: Partial<El>) => {
    if (!base.current) base.current = pagesRef.current;
    setSt((x) => ({ ...x, pages: mapEl(x.pages, pageId, id, patch) }));
  }, []);
  const commit = useCallback((label: string) => {
    const b = base.current;
    base.current = null;
    if (!b) return;
    ops.current.push(label);
    setSt((x) => (b === x.pages ? x : { pages: x.pages, past: [...x.past.slice(-60), b], future: [] }));
  }, []);
  const apply = useCallback((fn: (p: Page[]) => Page[], label: string) => {
    base.current = null;
    ops.current.push(label);
    setSt((x) => ({ pages: fn(x.pages), past: [...x.past.slice(-60), x.pages], future: [] }));
  }, []);
  const undo = () => setSt((x) => (x.past.length ? { pages: x.past[x.past.length - 1], past: x.past.slice(0, -1), future: [x.pages, ...x.future] } : x));
  const redo = () => setSt((x) => (x.future.length ? { pages: x.future[0], past: [...x.past, x.pages], future: x.future.slice(1) } : x));

  const sel = useMemo(() => {
    if (!selected) return null;
    const pg = pages.find((p) => p.id === selected.pageId);
    return pg?.elements.find((e) => e.id === selected.id) ?? null;
  }, [selected, pages]);

  const addEl = useCallback((pageId: string, el: El, label: string) => {
    apply((ps) => ps.map((p) => (p.id === pageId ? { ...p, elements: [...p.elements, el] } : p)), label);
    setSelected({ pageId, id: el.id });
  }, [apply]);

  /* ---------- callbacks passed to pages ---------- */
  const onSelect = useCallback((id: string | null) => {
    if (!id) return setSelected(null);
    const pg = pagesRef.current.find((p) => p.elements.some((e) => e.id === id));
    if (pg) {
      setSelected({ pageId: pg.id, id });
      setActiveId(pg.id);
    }
  }, []);

  const onTap = useCallback((pageId: string, x: number, y: number) => {
    const pg = pagesRef.current.find((p) => p.id === pageId);
    if (!pg) return;
    const t = toolRef.current;
    const box = (w: number, h: number) => ({ x: clamp(x - w / 2, 0, Math.max(0, pg.width - w)), y: clamp(y - h / 2, 0, Math.max(0, pg.height - h)), w, h });
    let el: El | null = null;
    let label = "";
    if (t === "text") {
      const w = clamp(pg.width - x - 12, 80, 240);
      const e: TextEl = { id: uid(), type: "text", x: clamp(x, 0, pg.width - 80), y: clamp(y - 10, 0, pg.height - 20), w, h: 22, text: "Your text", size: 18, color: "#111827", font: "helv", align: "left" };
      el = norm(e);
      label = "Added text";
    } else if (t === "rect" || t === "ellipse") {
      el = { id: uid(), type: t, ...box(130, t === "rect" ? 80 : 110), fill: shapeColor, stroke: null, strokeW: 2, opacity: 1 } as ShapeEl;
      label = "Added shape";
    } else if (t === "line") {
      el = { id: uid(), type: "rect", ...box(170, 3), fill: "#111827", stroke: null, strokeW: 1, opacity: 1 } as ShapeEl;
      label = "Added line";
    } else if (t === "highlight") {
      el = { id: uid(), type: "rect", ...box(170, 22), fill: "#fde047", stroke: null, strokeW: 1, opacity: 0.45 } as ShapeEl;
      label = "Added highlight";
    } else if (t === "whiteout") {
      el = { id: uid(), type: "rect", ...box(150, 28), fill: "#ffffff", stroke: null, strokeW: 1, opacity: 1 } as ShapeEl;
      label = "Whiteout (covered old content)";
    }
    if (!el) return;
    addEl(pageId, el, label);
    setTool("select");
    if (t === "text") setFocusText((n) => n + 1);
  }, [addEl]);

  const onDraw = useCallback((pageId: string, pts: [number, number][]) => {
    const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
    const x0 = Math.min(...xs), y0 = Math.min(...ys);
    const w = Math.max(1, Math.max(...xs) - x0), h = Math.max(1, Math.max(...ys) - y0);
    const el: DrawEl = { id: uid(), type: "draw", x: x0, y: y0, w, h, points: pts.map(([a, b]) => [(a - x0) / w, (b - y0) / h]), color: drawColorRef.current, width: drawWidthRef.current, opacity: 1 };
    apply((ps) => ps.map((p) => (p.id === pageId ? { ...p, elements: [...p.elements, el] } : p)), "Drew with pen");
  }, [apply]);

  const onPlaceholder = useCallback((pageId: string, id: string) => {
    setTarget({ pageId, id });
    setSheet("image");
  }, []);
  const onActive = useCallback((id: string) => setActiveId(id), []);

  /* ---------- images ---------- */
  const placeNew = (src: string, iw: number, ih: number, label: string, width = 0) => {
    const pg = pages.find((p) => p.id === (selected?.pageId ?? activeRef.current)) ?? pages[0];
    const ratio = ih / iw;
    let w = width || Math.min(220, pg.width * 0.45);
    let h = w * ratio;
    if (h > pg.height * 0.6) {
      h = pg.height * 0.6;
      w = h / ratio;
    }
    const el: ImageEl = { id: uid(), type: "image", x: (pg.width - w) / 2, y: Math.max(20, (pg.height - h) / 3), w, h, src, shape: "rect", opacity: 1, lockAspect: true, ratio };
    addEl(pg.id, el, label);
  };
  const pickImage = (img: LoadedImage) => {
    const mode = sheet;
    setSheet(null);
    if (mode === "pagepic") {
      const long = 842;
      const [w, h] = img.w >= img.h ? [long, (long * img.h) / img.w] : [(long * img.w) / img.h, long];
      const pg: Page = { ...blankPage(w, h), elements: [{ id: uid(), type: "image", x: 0, y: 0, w, h, src: img.src, shape: "rect", opacity: 1, lockAspect: true, ratio: h / w }] };
      apply((ps) => [...ps, pg], "Added a picture page");
      toast("Page added at the end");
      return;
    }
    if (target) {
      const t = target;
      setTarget(null);
      apply((ps) => mapEl(ps, t.pageId, t.id, { src: img.src, ratio: img.h / img.w } as Partial<ImageEl>), "Filled picture slot");
      setSelected(t);
      return;
    }
    placeNew(img.src, img.w, img.h, "Added image");
  };

  /* ---------- selected element helpers ---------- */
  const upd = (patch: Partial<El>, label = "Changed style") => selected && apply((ps) => mapEl(ps, selected.pageId, selected.id, patch), label);
  const liveSel = (patch: Partial<El>) => selected && live(selected.pageId, selected.id, patch);
  const del = () => {
    if (!selected) return;
    const sl = selected;
    apply((ps) => ps.map((p) => (p.id === sl.pageId ? { ...p, elements: p.elements.filter((e) => e.id !== sl.id) } : p)), "Deleted an item");
    setSelected(null);
  };
  const dup = () => {
    if (!sel || !selected) return;
    const c = { ...sel, id: uid(), x: sel.x + 14, y: sel.y + 14, locked: false } as El;
    addEl(selected.pageId, c, "Duplicated an item");
  };
  const layer = (dir: 1 | -1) => {
    if (!selected) return;
    const sl = selected;
    apply((ps) => ps.map((p) => {
      if (p.id !== sl.pageId) return p;
      const i = p.elements.findIndex((e) => e.id === sl.id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= p.elements.length) return p;
      const els = [...p.elements];
      [els[i], els[j]] = [els[j], els[i]];
      return { ...p, elements: els };
    }), "Changed layer order");
  };

  useEffect(() => {
    if (focusText && textRef.current) {
      textRef.current.focus();
      textRef.current.select();
    }
  }, [focusText, sel?.id]);

  /* ---------- export ---------- */
  const summary = () => {
    const m = new Map<string, number>();
    ops.current.forEach((o) => m.set(o, (m.get(o) || 0) + 1));
    return Array.from(m.entries()).map(([k, n]) => (n > 1 ? `${k} ×${n}` : k));
  };
  const doExport = async () => {
    setBusy(true);
    setSelected(null);
    try {
      const bytes = await exportPdf(name, pages, source);
      const filename = safeName(name);
      const where = await saveBytes(bytes, filename);
      const key = "file:" + uid();
      await storeFile(key, bytes);
      const d = summary();
      addHistory({
        doc: filename,
        action: "exported",
        details: d.length ? d : [session.kind === "pdf" ? "Saved without changes" : session.kind === "scan" ? "Scanned document saved" : session.kind === "template" ? "Template document saved" : "Saved"],
        fileKey: key,
        pages: pages.length,
      });
      ops.current = [];
      setDone({ bytes, filename, where });
    } catch (e) {
      console.error(e);
      toast("Export failed: " + (e instanceof Error ? e.message : "unknown error"));
    }
    setBusy(false);
  };

  const close = () => {
    if (ops.current.length) {
      addHistory({ doc: safeName(name), action: "edited", details: [...summary(), "Not exported yet"], pages: pages.length });
      ops.current = [];
    }
    onClose();
  };
  const closeRef = useRef(close);
  closeRef.current = close;
  useBack(() => {
    if (tool !== "select") setTool("select");
    else if (selected) setSelected(null);
    else closeRef.current();
  });

  const activeIdx = Math.max(0, pages.findIndex((p) => p.id === activeId));
  const activePage = pages[activeIdx];

  /* ---------- page management ---------- */
  const movePage = (i: number, d: number) =>
    apply((ps) => {
      const j = i + d;
      if (j < 0 || j >= ps.length) return ps;
      const c = [...ps];
      [c[i], c[j]] = [c[j], c[i]];
      return c;
    }, "Reordered pages");
  const deletePage = (i: number) => {
    if (pages.length <= 1) return toast("A PDF needs at least one page");
    apply((ps) => ps.filter((_, k) => k !== i), "Deleted a page");
    setSelected(null);
  };
  const dupPage = (i: number) =>
    apply((ps) => {
      const p = ps[i];
      const c: Page = { ...p, id: uid(), elements: p.elements.map((e) => ({ ...e, id: uid() })) };
      return [...ps.slice(0, i + 1), c, ...ps.slice(i + 1)];
    }, "Duplicated a page");
  const addBlank = (i: number) =>
    apply((ps) => {
      const ref = ps[i] ?? ps[0];
      return [...ps.slice(0, i + 1), blankPage(ref.width, ref.height), ...ps.slice(i + 1)];
    }, "Added a blank page");

  const toolbar = TOOLS.map((t) => {
    const active = t.id === tool;
    return (
      <button
        key={t.id}
        onClick={() => {
          if (t.id === "image") { setTarget(null); setSheet("image"); }
          else if (t.id === "sign") setSheet("sign");
          else if (t.id === "pages") setSheet("pages");
          else { setTool(t.id as Tool); if (t.id !== "select") setSelected(null); }
        }}
        className={`flex flex-col items-center justify-center gap-0.5 w-[62px] h-14 rounded-2xl shrink-0 text-[11px] font-medium active:scale-95 transition ${active ? "bg-indigo-600 text-white shadow-md shadow-indigo-300" : "text-slate-600"}`}
      >
        {t.icon}
        {t.label}
      </button>
    );
  });

  const showPanel = sel && tool === "select";

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-slate-200 safe-top">
      {/* header */}
      <div className="flex items-center gap-1.5 px-2 h-14 bg-white shadow-sm shrink-0">
        <button onClick={close} className="w-10 h-10 rounded-full flex items-center justify-center text-slate-700 active:bg-slate-100"><ChevronLeft /></button>
        <input value={name} onChange={(e) => setName(e.target.value)} className="flex-1 min-w-0 font-semibold text-slate-900 bg-transparent outline-none truncate px-1" aria-label="File name" />
        <button onClick={undo} disabled={!st.past.length} className="w-9 h-10 flex items-center justify-center text-slate-700 disabled:opacity-25"><Undo2 size={20} /></button>
        <button onClick={redo} disabled={!st.future.length} className="w-9 h-10 flex items-center justify-center text-slate-700 disabled:opacity-25"><Redo2 size={20} /></button>
        <button onClick={doExport} disabled={busy} className="ml-1 h-10 px-3.5 rounded-full grad text-white text-sm font-semibold flex items-center gap-1.5 shadow-md shadow-indigo-200 active:scale-95">
          {busy ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} Save
        </button>
      </div>
      {/* sub bar */}
      <div className="flex items-center justify-between px-3 h-9 text-xs text-slate-600 bg-white/70 backdrop-blur shrink-0">
        <span className="font-medium">Page {activeIdx + 1} / {pages.length}</span>
        <div className="flex items-center gap-1">
          <button onClick={() => setZoom((z) => clamp(+(z - 0.25).toFixed(2), 0.5, 3))} className="w-8 h-7 rounded-lg bg-white flex items-center justify-center shadow-sm"><Minus size={14} /></button>
          <button onClick={() => setZoom(1)} className="w-12 h-7 rounded-lg bg-white shadow-sm font-semibold">{Math.round(zoom * 100)}%</button>
          <button onClick={() => setZoom((z) => clamp(+(z + 0.25).toFixed(2), 0.5, 3))} className="w-8 h-7 rounded-lg bg-white flex items-center justify-center shadow-sm"><Plus size={14} /></button>
        </div>
      </div>

      {/* pages */}
      <div ref={scroller} className="flex-1 overflow-auto" style={{ overscrollBehavior: "contain" }}>
        <div className="flex flex-col items-center gap-5 py-4 px-5 w-max min-w-full">
          {pages.map((pg, i) => (
            <div key={pg.id}>
              <div className="text-[11px] text-slate-500 mb-1 font-medium">Page {i + 1}</div>
              <div className={"shadow-xl " + (pg.id === activeId ? "ring-2 ring-indigo-300/70" : "ring-1 ring-black/5")}>
                <PageView
                  page={pg}
                  scale={s}
                  source={source}
                  interactive
                  lazy
                  tool={tool}
                  selectedId={selected?.pageId === pg.id ? selected.id : null}
                  drawColor={drawColor}
                  drawWidth={drawWidth}
                  onSelect={onSelect}
                  onLive={live}
                  onCommit={commit}
                  onTap={onTap}
                  onDraw={onDraw}
                  onPlaceholder={onPlaceholder}
                  onActive={onActive}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* hint / draw options */}
      {tool !== "select" && (
        <div className="bg-indigo-600 text-white px-4 py-2.5 shrink-0">
          <div className="flex items-center justify-between gap-3 text-sm">
            <span>{HINTS[tool]}</span>
            <button onClick={() => setTool("select")} className="px-3 h-8 rounded-full bg-white/20 font-semibold shrink-0">Done</button>
          </div>
          {tool === "draw" && (
            <div className="mt-2 flex items-center gap-3 overflow-x-auto no-scrollbar">
              <Swatches value={drawColor} onChange={(c) => setDrawColor(c ?? "#111827")} />
              <Slider label="Size" value={drawWidth} min={1} max={14} onChange={setDrawWidth} onEnd={() => {}} />
            </div>
          )}
        </div>
      )}

      {/* selection panel */}
      {showPanel && sel && (
        <div className="bg-white border-t border-slate-200 shrink-0 shadow-[0_-8px_24px_rgba(15,23,42,.08)]">
          <div className="flex items-center justify-between px-3 h-11">
            <button onClick={() => setPanelOpen(!panelOpen)} className="flex items-center gap-1 text-sm font-semibold text-slate-700 capitalize">
              {panelOpen ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
              {sel.type === "rect" ? "Box" : sel.type === "draw" ? "Drawing" : sel.type}
            </button>
            <div className="flex items-center gap-0.5 text-slate-600">
              <button onClick={() => layer(1)} className="w-9 h-9 flex items-center justify-center" title="Bring forward"><ArrowUp size={18} /></button>
              <button onClick={() => layer(-1)} className="w-9 h-9 flex items-center justify-center" title="Send back"><ArrowDown size={18} /></button>
              <button onClick={dup} className="w-9 h-9 flex items-center justify-center" title="Duplicate"><Copy size={18} /></button>
              <button onClick={del} className="w-9 h-9 flex items-center justify-center text-red-500" title="Delete"><Trash2 size={18} /></button>
            </div>
          </div>
          {panelOpen && (
            <div className="px-3 pb-3 space-y-2.5 max-h-[38dvh] overflow-y-auto">
              {sel.type === "text" && (
                <>
                  <textarea
                    ref={textRef}
                    value={sel.text}
                    rows={2}
                    onChange={(e) => liveSel({ text: e.target.value })}
                    onBlur={() => commit("Edited text")}
                    className="w-full rounded-xl bg-slate-100 px-3 py-2 text-[15px] outline-none focus:ring-2 ring-indigo-400 resize-none"
                    placeholder="Type here…"
                  />
                  <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                    <Chip onClick={() => upd({ size: Math.max(6, sel.size - 1) } as Partial<El>, "Changed text size")}>A−</Chip>
                    <span className="w-9 text-center text-sm font-semibold shrink-0">{Math.round(sel.size)}</span>
                    <Chip onClick={() => upd({ size: sel.size + 1 } as Partial<El>, "Changed text size")}>A+</Chip>
                    <Chip active={sel.bold} onClick={() => upd({ bold: !sel.bold } as Partial<El>)}><Bold size={17} /></Chip>
                    <Chip active={sel.italic} onClick={() => upd({ italic: !sel.italic } as Partial<El>)}><Italic size={17} /></Chip>
                    <Chip onClick={() => upd({ font: sel.font === "helv" ? "times" : sel.font === "times" ? "cour" : "helv" } as Partial<El>, "Changed font")} className="w-20">{sel.font === "helv" ? "Sans" : sel.font === "times" ? "Serif" : "Mono"}</Chip>
                    <Chip active={sel.align === "left"} onClick={() => upd({ align: "left" } as Partial<El>)}><AlignLeft size={17} /></Chip>
                    <Chip active={sel.align === "center"} onClick={() => upd({ align: "center" } as Partial<El>)}><AlignCenter size={17} /></Chip>
                    <Chip active={sel.align === "right"} onClick={() => upd({ align: "right" } as Partial<El>)}><AlignRight size={17} /></Chip>
                  </div>
                  <div className="overflow-x-auto no-scrollbar py-1"><Swatches value={sel.color} onChange={(c) => upd({ color: c ?? "#111827" } as Partial<El>, "Changed text colour")} /></div>
                </>
              )}
              {(sel.type === "rect" || sel.type === "ellipse") && (
                <>
                  <div className="text-xs text-slate-500">Fill</div>
                  <div className="overflow-x-auto no-scrollbar py-1"><Swatches none value={sel.fill} onChange={(c) => upd({ fill: c } as Partial<El>, "Changed fill")} /></div>
                  <div className="text-xs text-slate-500">Outline</div>
                  <div className="overflow-x-auto no-scrollbar py-1"><Swatches none value={sel.stroke} onChange={(c) => upd({ stroke: c } as Partial<El>, "Changed outline")} /></div>
                  <div className="flex items-center gap-4 overflow-x-auto no-scrollbar text-slate-500">
                    <Slider label="Opacity" value={Math.round(sel.opacity * 100)} min={5} max={100} onChange={(v) => liveSel({ opacity: v / 100 } as Partial<El>)} onEnd={() => commit("Changed opacity")} />
                    <Slider label="Outline" value={sel.strokeW} min={1} max={12} onChange={(v) => liveSel({ strokeW: v } as Partial<El>)} onEnd={() => commit("Changed outline")} />
                  </div>
                </>
              )}
              {sel.type === "image" && (
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar text-slate-500">
                  <Chip onClick={() => { setTarget(selected); setSheet("image"); }} className="gap-1.5"><Replace size={16} /> {sel.src ? "Replace" : "Add"}</Chip>
                  <Chip active={sel.shape === "rect"} onClick={() => upd({ shape: "rect" } as Partial<El>, "Changed picture shape")}><Square size={16} /></Chip>
                  <Chip active={sel.shape === "circle"} onClick={() => upd({ shape: "circle" } as Partial<El>, "Changed picture shape")}><Circle size={16} /></Chip>
                  <Chip active={!!sel.lockAspect} onClick={() => upd({ lockAspect: !sel.lockAspect, ratio: sel.ratio ?? sel.h / sel.w } as Partial<El>, "Changed picture")} className="text-xs whitespace-nowrap">Keep ratio</Chip>
                  <Slider label="Opacity" value={Math.round(sel.opacity * 100)} min={10} max={100} onChange={(v) => liveSel({ opacity: v / 100 } as Partial<El>)} onEnd={() => commit("Changed opacity")} />
                </div>
              )}
              {sel.type === "draw" && (
                <div className="text-slate-500">
                  <div className="overflow-x-auto no-scrollbar py-1"><Swatches value={sel.color} onChange={(c) => upd({ color: c ?? "#111827" } as Partial<El>, "Changed pen colour")} /></div>
                  <Slider label="Thickness" value={sel.width} min={1} max={14} onChange={(v) => liveSel({ width: v } as Partial<El>)} onEnd={() => commit("Changed pen size")} />
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* toolbar */}
      <div className="bg-white border-t border-slate-200 shrink-0 safe-bottom">
        <div className="flex overflow-x-auto no-scrollbar gap-1 px-2 py-1.5">{toolbar}</div>
      </div>

      {/* sheets */}
      <ImagePicker open={sheet === "image" || sheet === "pagepic"} onClose={() => { setSheet(null); setTarget(null); }} onPick={pickImage} title={sheet === "pagepic" ? "Pick a picture for a new page" : target ? "Choose a picture for this slot" : "Add a picture"} />
      <SignaturePad
        open={sheet === "sign"}
        onClose={() => setSheet(null)}
        onDone={(src, w, h) => {
          setSheet(null);
          addToLibrary({ name: "Signature", src, w, h });
          placeNew(src, w, h, "Added signature", 150);
        }}
      />
      <Sheet open={sheet === "pages"} onClose={() => setSheet(null)} title={`Pages (${pages.length})`} tall>
        <div className="grid grid-cols-2 gap-3">
          {pages.map((pg, i) => (
            <div key={pg.id} className={"rounded-2xl bg-slate-50 p-2 border " + (i === activeIdx ? "border-indigo-300" : "border-slate-100")}>
              <button className="block w-full rounded-lg overflow-hidden shadow ring-1 ring-black/5" onClick={() => { setActiveId(pg.id); setSheet(null); setTimeout(() => document.querySelector(`[data-page="${pg.id}"]`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 80); }}>
                <FitPage page={pg} source={source} />
              </button>
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs font-semibold text-slate-600 pl-1">{i + 1}</span>
                <div className="flex text-slate-600">
                  <button onClick={() => movePage(i, -1)} disabled={i === 0} className="w-8 h-8 flex items-center justify-center disabled:opacity-25"><ArrowUp size={16} /></button>
                  <button onClick={() => movePage(i, 1)} disabled={i === pages.length - 1} className="w-8 h-8 flex items-center justify-center disabled:opacity-25"><ArrowDown size={16} /></button>
                  <button onClick={() => addBlank(i)} className="w-8 h-8 flex items-center justify-center" title="Add blank page after"><FilePlus2 size={16} /></button>
                  <button onClick={() => dupPage(i)} className="w-8 h-8 flex items-center justify-center"><Copy size={16} /></button>
                  <button onClick={() => deletePage(i)} className="w-8 h-8 flex items-center justify-center text-red-500"><Trash2 size={16} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-3 mt-4">
          <button onClick={() => addBlank(pages.length - 1)} className="h-12 rounded-2xl bg-indigo-50 text-indigo-700 font-semibold flex items-center justify-center gap-2"><FilePlus2 size={18} /> Blank page</button>
          <button onClick={() => setSheet("pagepic")} className="h-12 rounded-2xl bg-violet-50 text-violet-700 font-semibold flex items-center justify-center gap-2"><ImagePlus size={18} /> Picture page</button>
        </div>
        {activePage && activePage.srcIndex === null && (
          <div className="mt-5">
            <div className="text-sm font-semibold text-slate-700 mb-2">Background colour of page {activeIdx + 1}</div>
            <div className="overflow-x-auto no-scrollbar py-1"><Swatches value={activePage.bg} onChange={(c) => apply((ps) => ps.map((p) => (p.id === activePage.id ? { ...p, bg: c ?? "#ffffff" } : p)), "Changed page colour")} /></div>
          </div>
        )}
      </Sheet>
      <Sheet open={!!done} onClose={() => setDone(null)} title="PDF saved">
        {done && (
          <div className="text-center pb-2">
            <div className="mx-auto w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3"><CheckCircle2 size={34} /></div>
            <div className="font-semibold text-slate-900 break-all">{done.filename}</div>
            <div className="text-sm text-slate-500 mt-1">Saved to {done.where}</div>
            <div className="text-xs text-slate-400 mt-1">Also added to your History tab so you can download it again.</div>
            <div className="grid grid-cols-2 gap-3 mt-5">
              <button onClick={() => shareBytes(done.bytes, done.filename).catch(() => {})} className="h-12 rounded-2xl bg-indigo-50 text-indigo-700 font-semibold flex items-center justify-center gap-2"><Share2 size={18} /> Share</button>
              <button onClick={() => setDone(null)} className="h-12 rounded-2xl grad text-white font-semibold">Keep editing</button>
            </div>
            <button onClick={() => { setDone(null); closeRef.current(); }} className="mt-3 text-sm text-slate-500 py-2">Close editor</button>
          </div>
        )}
      </Sheet>
    </div>
  );
}
