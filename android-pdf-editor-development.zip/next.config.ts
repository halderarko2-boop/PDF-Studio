import type { NextConfig } from "next";

// `BUILD_TARGET=static` produces a fully static bundle in /out that Capacitor
// packages into the Android app (works 100% offline, no server needed).
const isStatic = process.env.BUILD_TARGET === "static";

const nextConfig: NextConfig = {
  ...(isStatic ? { output: "export" as const, images: { unoptimized: true } } : {}),
  turbopack: {
    resolveAlias: {
      canvas: { browser: "./src/lib/empty.ts" },
    },
  },
};

export default nextConfig;
